package com.vinod.springsecurity.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class SpringSecurityController {
 
    @RequestMapping("/index")
    public String accessPublicPage(Model model) {
        model.addAttribute("message", "This page is publicly accessible. No authentication is required to view.");
 
        return "index";
    }
     
    @RequestMapping("/admin")
    public String accessSecuredPage(Model model) {
        model.addAttribute("message", "Only you are authenticated and authorized to view this page.");
 
        return "admin";
    }
    
    @RequestMapping("/access")
    public String accessLoginPage(Model model) {
        model.addAttribute("message", "access page...");
 
        return "access";
    }
    
    @RequestMapping("/welcome")
    public String accessWelcomePage(Model model) {
        model.addAttribute("message", "login page...");
 
        return "welcome";
    }
}