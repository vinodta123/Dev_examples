Download the NodeJS from https://nodejs.org/en/download/
And then download angularCLI from https://cli.angular.io/ through below commends
1. npm install -g @angular/cli



in order to start client nodejs server
open the cmd commond file
Go to SkyTeamChatbot\faqdatabase folder commond file
and then type ng server -o to start client server which will run localhost:4242

in order to start Server nodejs server
open the cmd commond file

open the cmd commond file 
Go to Go to SkyTeamChatbot\NodeServer folder commond file 
type npm install and node index.js
which will start running on 6555 port bydauflt.
