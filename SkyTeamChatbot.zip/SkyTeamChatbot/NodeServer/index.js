'use strict';
const express = require('express');
const bodyParser = require('body-parser');
const requestData = require('request');
// const cors = require('cors');
const app = express();
const apiaiApp = require('apiai')('0e41338c49d94c4d8d4374cfac1c83a8');
const uuidv1 = require('uuid/v1');

// app.use(cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));

const server = app.listen(process.env.PORT || 6555, () => {
    console.log('Express server listening on port %d in %s mode', server.address().port, app.settings.env);
});


app.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    if ('OPTIONS' == req.method) {
        res.sendStatus(200);
    } else {
        next();
    }
});

app.get('/node', function (req, res) {
    res.send('skyteam node server started...');
});

// Route that receives a POST request
app.post('/node', function (req, res) {
    let userMessage = req.body.message;
    let sessionId = req.body.sessionId;
    let errorCount = parseInt(req.body.errorCount);

    if (sessionId == '') {
        sessionId = uuidv1();
        console.log(sessionId);
    }
    //console.log(userMessage + '/' + sessionId +'/'+ errorCount);
    sendMessage(userMessage, sessionId);


    function sendMessage(userMessage, sessionId) {
        let text = userMessage; //request from frontend
        let error = false;
        let apiai = apiaiApp.textRequest(text, {
            sessionId: sessionId
        });

        apiai.on("response", function (response) {
            console.log("this is bot response");
            console.log(response);
            let botresponse;
            if (response.result.action == "input.unknown") {
                console.log("error count is " + errorCount);
                if (errorCount > 1) {
                    console.log('Error count reched the level 2');
                    let responseText = "Unfortunately, the SkyTeam chatbot was unable to fulfil your request. Please send your inquiry to website@skyteam.com";
                    botresponse = responseText;
                    console.log(botresponse);
                    res.send({
                        res: botresponse,
                        sessionId: sessionId,
                        error: true
                    });
                    // res.send(botresponse);
                } else {
                    console.log('you are in error');
                    let responseText = "Sorry, I am unable to identify your request. Could you rephrase the inquiry? ";
                    botresponse = responseText;
                    console.log(botresponse);
                    res.send({
                        res: botresponse,
                        sessionId: sessionId,
                        error: true
                    });
                    // console.log('Response from bot ' + botresponse);
                    errorCount = errorCount + 1;
                }
            } else if (response.result.action == "Get-Weather") {
                //make an api call with parameters
                let city = response.result.parameters.city;
                let url = "http://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=f690af32c575e46489d05cbb5ad1fbc3";
                console.log(url);
                requestData(url, function (error, response, body) {
                    console.log('The url is ' + url)
                    let temp = Math.round(JSON.parse(body).main.temp - 273.15);
                    let responseText = "Temperature in " + city + " is " + temp + " degree centigrade.";
                    // res.json({ "speech": responseText, "displayText": responseText })
                    botresponse = responseText;
                    console.log(botresponse);
                    res.send({
                        res: botresponse,
                        sessionId: sessionId,
                        error: false
                    });
                    // console.log('Response from bot ' + botresponse);
                })
            } else if (response.result.action == "Get-flightStatus") {
                if (response.result.actionIncomplete == false) {
                    let flightnumber = (response.result.parameters.flightnumber).replace(/\s/g, '');
                    let statusDate = response.result.parameters.statusDate;
                    let uri = 'https://api.skyteam.com/v1/flight?flightnumber=' + flightnumber + '&departuredate=' + statusDate;
                    let hearders = {
                        'api_key': 'yfunvneadwz62wywjvtgqc8a',
                        'Accpet': 'application/json'
                    }
                    let method = 'GET';
                    let options = {
                        method,
                        uri,
                        hearders
                    }
                    console.log(uri);
                    requestData(options, function (error, response, body) {
                        console.log(body);
                        console.log(error);
                        console.log(response);
                        //console.log(JSON.parse(body));
                    });
                } else {
                    botresponse = response.result.fulfillment["speech"];
                    console.log(botresponse);
                    res.send({
                        res: botresponse,
                        sessionId: sessionId,
                        error: false
                    });
                    // console.log('Response from bot ' + botresponse);
                }
            } else if (response.result.metadata.intentName && response.result.metadata.intentName != 'Default Welcome Intent' && response.result.metadata.intentName != 'Default Fallback Intent') {
                let str = response.result.metadata.intentName;
                let parameter = (str.split('-', 1));
                console.log(parameter[0]);
                let url = "https://api.skyteam.com/staging/v1/faq?seqId=" + parameter[0].trim() + '&api_key=5m49bjnak3nsrv5hdkf4aab6';
                // let url = "http://10.240.14.147:8080/frequentlyaskedquestion-1.0/v1/faq?seqId=" + parameter[0].trim() + '&api_key=5m49bjnak3nsrv5hdkf4aab6';

                console.log(url);
                requestData(url, function (error, response, body) {
                    console.log('The url is ' + url);
                    console.log(body);
                    let ans = JSON.parse(body).response[0].answer;
                    let responseText = ans;
                    // res.json({ "speech": responseText, "displayText": responseText })
                    botresponse = responseText;
                    console.log(botresponse);
                    res.send({
                        res: botresponse,
                        sessionId: sessionId,
                        error: false
                    });
                    // console.log('Response from bot ' + botresponse);
                });
            } else {
                botresponse = response.result.fulfillment["speech"];
                console.log(botresponse);
                res.send({
                    res: botresponse,
                    sessionId: sessionId,
                    error: false
                });
                // console.log('Response from bot ' + botresponse);
            }
        });

        apiai.on('error', (error) => {
            console.log(error);
        });

        apiai.end();
    }

});
//setTimeout(sendMessage, 2000);
