import { ApiAiClient } from 'api-ai-javascript';

// You'll get this access token from Your Agent Dashboard > Settings > General > API keys > Developer access token
export const client = new ApiAiClient({accessToken: '0e41338c49d94c4d8d4374cfac1c83a8'});
