export interface IMessage {
    avatar: string;
    from: string;
    content: string;
}
