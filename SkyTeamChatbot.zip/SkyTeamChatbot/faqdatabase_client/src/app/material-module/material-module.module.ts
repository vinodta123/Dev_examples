import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatToolbarModule,
  MatInputModule, MatProgressSpinnerModule, MatCardModule,
  MatExpansionModule, MatChipsModule, MatIconModule, MatListModule, MatDialogModule, MatButtonToggleModule } from '@angular/material';


@NgModule({
  imports: [MatButtonModule, MatToolbarModule, MatExpansionModule, MatButtonToggleModule,
    MatInputModule, MatProgressSpinnerModule, MatCardModule, MatChipsModule, MatIconModule, MatListModule, MatDialogModule],
  exports: [MatButtonModule, MatToolbarModule, MatExpansionModule, MatDialogModule, MatButtonToggleModule,
    MatInputModule, MatProgressSpinnerModule, MatCardModule, MatChipsModule, MatIconModule, MatListModule],
})
export class MaterialModuleModule { }
