import { Component, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IMessage } from './../../model/message';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent {
  @Input() showMePartially: boolean;
  //url = 'https://services.skyteam.com/node';
  // url = 'https://services.staging.skyteam.com/node';
  url = 'http://localhost:6555/node';
  showChat = true;
  conversation: IMessage[] = [];
  message = '';
  errorCount = 0;
  constructor(private http: HttpClient) {
    sessionStorage.setItem('errorCount', '0');
    sessionStorage.removeItem('sessionId');

    if (sessionStorage.getItem('sessionId') === '' || sessionStorage.getItem('sessionId') == null ) {

        if (this.showChat === true) {
          setTimeout(() => {
            this.conversation.pop();
            this.conversation.push({
              avatar: 'bot',
              from: 'bot',
              content: 'Hello! I am the SkyTeam support chatbot, here to help you with general queries regarding SkyTeam Airline Alliance.'
            });
        } , 2000);
          this.conversation.push({
            avatar: 'bot',
            from: 'bot',
            content: '<img class="animatedChatIcon" src="./assets/animatedchat.svg" width="50">'
            });
        } else {
          this.conversation.pop();
        }
      }


  }

  Linkify = function (inputText) {
    let replacedText: any;
    // URLs starting with http://, https://, or ftp://
    const replacePattern1 = /(\b(https?|ftp):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gim;
    replacedText = inputText.replace(replacePattern1, '<a href="$1" target="_blank">$1</a>');

    // URLs starting with www. (without // before it, or it'd re-link the ones done above)
    const replacePattern2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
    replacedText = replacedText.replace(replacePattern2, '$1<a href="http://$2" target="_blank">$2</a>');

    // Change email addresses to mailto:: links
    const replacePattern3 = /(\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,6})/gim;
    replacedText = replacedText.replace(replacePattern3, '<a href="mailto:$1">$1</a>');

    return replacedText;
  };

  callbot(message) {
    console.log(message);
    this.conversation.push({
      avatar: 'bot',
      from: 'bot',
      content: '<img class="animatedChatIcon" src="./assets/animatedchat.svg" width="50">'
    });
    const session = sessionStorage.getItem('sessionId');
    const postData = { message: message, errorCount: this.errorCount };
    if (session !== null && session !== '') {
      postData['sessionId'] = session;
    } else {
      postData['sessionId'] = '';
    }
    // tslint:disable-next-line:no-debugger
    // debugger;
    this.http.post(this.url, postData).subscribe(res => {
      console.log(res);
      let botmsg;
      if (res) {
        // tslint:disable-next-line:prefer-const
        let msg = res['res'];
        sessionStorage.setItem('sessionId', res['sessionId']);
        botmsg = this.Linkify(msg);
        // tslint:disable-next-line:no-debugger
      //  this.errorCount = parseInt(sessionStorage.getItem('errorCount'), 10);
        if (res['error']) {
          if (this.errorCount === 2) {
            console.log({conservation: this.conversation, sessionId: session});
          } else if (this.errorCount === 0) {
            // sessionStorage.setItem('errorCount', '1' );
            this.errorCount = 1;
          } else {
            this.errorCount = this.errorCount + 1;
          //  sessionStorage.setItem('errorCount', this.errorCount.toString());
          }
        } else {
          if (this.errorCount === 0) {
            // sessionStorage.setItem('errorCount', '0' );
          } else {
            this.errorCount = this.errorCount - 1;
           // sessionStorage.setItem('errorCount', this.errorCount.toString());
          }
        }
      }
      console.log(res);
      this.conversation.pop();
      this.conversation.push({
        avatar: 'bot',
        from: 'bot',
        content: botmsg
      });

    });
  }
  toggleClick() {
    // tslint:disable-next-line:no-debugger
    this.showChat = !this.showChat;
    console.log(this.showChat);

    // if (sessionStorage.getItem('sessionId') === '' || sessionStorage.getItem('sessionId') == null ) {

    //   if (this.showChat === true) {
    //     setTimeout(() => {
    //       this.conversation.pop();
    //       this.conversation.push({
    //         avatar: 'bot',
    //         from: 'bot',
    //         content: 'Hello! I am the SkyTeam support chatbot, here to help you with general queries regarding SkyTeam Airline Alliance.'
    //       });
    //   } , 2000);
    //     this.conversation.push({
    //       avatar: 'bot',
    //       from: 'bot',
    //       content: '<img class="animatedChatIcon" src="./assets/animatedchat.svg" width="50">'
    //       });
    //   } else {
    //     this.conversation.pop();
    //   }

    // }
  }

  addMessageFromUser() {
    if (this.message !== '') {
      console.log(this.message);
      this.conversation.push({
        avatar: 'user',
        from: 'user',
        content: this.message
      });
      this.callbot(this.message);
      this.message = '';
    } else {
      this.conversation.push({
        avatar: 'bot',
        from: 'bot',
        content: 'Please type a message'
      });
    }
  }
}
