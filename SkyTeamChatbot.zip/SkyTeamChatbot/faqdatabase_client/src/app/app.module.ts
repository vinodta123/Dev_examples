import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { OrderModule } from 'ngx-order-pipe';
import { MaterialModuleModule } from './material-module/material-module.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
// import {appRoutes} from './routerConfig';
import { QuestionsService } from './questions.service';
import { ChatComponent } from './chat/chat.component';
import { LinkifyPipe } from './pipes/linkify.pipe';
import { SanitizeHtmlPipe } from './pipes/sanitize-html.pipe';


@NgModule({
  declarations: [
    AppComponent,
    ChatComponent,
    LinkifyPipe,
    SanitizeHtmlPipe
  ],
  imports: [
    BrowserModule, RouterModule,
    // RouterModule.forRoot(appRoutes),
    HttpClientModule, ReactiveFormsModule, OrderModule, FormsModule,
    NgbModule.forRoot(), BrowserAnimationsModule, MaterialModuleModule
  ],
  providers: [QuestionsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
