import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class QuestionsService {

  constructor(private http: HttpClient) { }

  addQuestion(category, question, answer) {
    const uri = 'https://services.staging.skyteam.com/v1/faq';
    // const httpHeaders = new HttpHeaders().set('Content-Type', 'application/json');
    const obj = {
      'category': category,
      'question': question,
      'answer': answer
    };
    this.http.put(uri, obj)
      .subscribe(res => console.log('Done'));
  }
  getQuestions() {
    const uri = 'https://services.staging.skyteam.com/v1/faq';
    return this
      .http
      .get(uri)
      .map(res => {
        return res;
      });
  }

  editQuestion(id) {
    const uri = 'https://services.staging.skyteam.com/v1/faq?seqId=' + id;
    return this
      .http
      .get(uri)
      .map(res => {
        console.log(res);
        return res;
      });
  }

  updateQuestion(category, question, answer, id) {
    const uri = 'https://services.staging.skyteam.com/v1/faq';
    const obj = {
      'seqId' : id,
      'category' : category,
      'question' : question,
      'answer' : answer
    };
    this.http.post(uri, obj).subscribe(res => console.log('udpated'));
  }

deleteQuestion(id) {
  // const httpHeaders = new HttpHeaders().set('Content-Type', 'application/json');
  const uri = 'https://services.staging.skyteam.com/v1/faq/' + id;
  return this
          .http
          .delete(uri)
          .map(res => {
            console.log(res);
            return res;
          });
        }

}
