// // routerConfig.ts

// import { Routes } from '@angular/router';
// import { QuestionsComponent } from './questions/questions.component';
// import { CreateQuestionsComponent } from './create-questions/create-questions.component';
// import { EditQuestionComponent } from './edit-question/edit-question.component';

// export const appRoutes: Routes = [
//   { path: 'create',
//     component: CreateQuestionsComponent
//   },
//   {
//     path: 'edit/:id',
//     component: EditQuestionComponent
//   },
//   { path: '',
//     component: QuestionsComponent
//   }
// ];
