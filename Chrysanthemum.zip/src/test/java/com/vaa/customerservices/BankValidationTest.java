package com.vaa.customerservices;



import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.apache.log4j.Logger;
import org.junit.Test;

import com.vaa.customerservices.model.AddBankDetailsModel;
import com.vaa.customerservices.model.GuidInfoModel;
import com.vaa.customerservices.model.ValidateGuIdModel;
import com.vaa.customerservices.service.BankDetailsService;
import com.vaa.customerservices.serviceImpl.BankDetailsServiceImpl;
import com.vaa.customerservices.util.CustomerServicesException;

public class BankValidationTest {
	private static final Logger log = Logger.getLogger(BankValidationTest.class);

	BankDetailsService bankDetailsService = new BankDetailsServiceImpl();
	ValidateGuIdModel validateGuidRQ = new ValidateGuIdModel();
	AddBankDetailsModel addBankDetailsModel = new AddBankDetailsModel();
	
	

	/**
	 * Test receiveGuidInfo call - positive test
	 */
	@Test
	public void receiveGuidInfoTest(){
		GuidInfoModel GuidInfoModel_RS=null;
		try{
			String guid = "7E16BAAD-E527-4FCE-B3B1-7E6137848723";
			GuidInfoModel_RS= bankDetailsService.receiveGuidInfo(guid);
		    assertTrue(GuidInfoModel_RS.getName()!=null);			
		}catch(CustomerServicesException er){ 
			log.info("BankValidationTest :: Exception in receiveGuidInfoTest method " + er);			
		}catch (Exception e) {
			log.info("BankValidationTest :: Exception in receiveGuidInfoTest method " + e);	
			
		}	
	}
	
	/**
	 * Test receiveGuidInfo call - negative test
	 */
	@Test
	public void receiveGuidInfoFailedTest(){
		GuidInfoModel GuidInfoModel_RS=null;
		try{
			String guid = "1234567890";
			GuidInfoModel_RS = bankDetailsService.receiveGuidInfo(guid);
			assertFalse(GuidInfoModel_RS.getName()!=null);
			
		}catch(CustomerServicesException er){ 
			log.info("BankValidationTest :: Exception in receiveGuidInfoFailedTest method " + er);			
		}catch (Exception e) {
			log.info("BankValidationTest :: Exception in receiveGuidInfoFailedTest method " + e);	
			
		}	
	}

	/**
	 * Test validateGUID call - positive test
	 */
	@Test
	public void validateGUIDTest(){
		ValidateGuIdModel validateGUISRS=null;		
		try{
			
			validateGuidRQ.setGuid("7E16BAAD-E527-4FCE-B3B1-7E61317848723");
			validateGuidRQ.setReferenceNumber("1586031");
			validateGUISRS=bankDetailsService.validateGUID(validateGuidRQ);			
			assertTrue(validateGUISRS.isValid());
		}catch(CustomerServicesException er){ 
			log.info("BankValidationTest :: Exception in validateGUIDTest method " + er);			
		}catch (Exception e) {
			log.info("BankValidationTest :: Exception in validateGUIDTest method " + e);	
			
		}
	}
	
	/**
	 * Test validateGUID call - negative test
	 */
	@Test
	public void validateGUIDFailedTest(){
		ValidateGuIdModel validateGUISRS=null;
		try{
			
			validateGuidRQ.setGuid("C9842DE3-BCD0-4A15-8D82-FB81F43C3DF7123");
			validateGuidRQ.setReferenceNumber("1473420123");
			validateGUISRS=bankDetailsService.validateGUID(validateGuidRQ);

			assertFalse(validateGUISRS.isValid());
		
		}catch(CustomerServicesException er){ 
			log.info("BankValidationTest :: Exception in validateGUIDFailedTest method " + er);			
		}catch (Exception e) {
			log.info("BankValidationTest :: Exception in validateGUIDFailedTest method " + e);	
			
		}
	}
	
	/**
	 * This test can be enabled when database entries can be deleted which gets inserted with this testcase.
	 */
	/*@Test
	public void confirmBankDetailsTest(){
		
		try{
			//Adding the correct bank details 
			
			
			addBankDetailsModel.setGuid("C9842DE3-BCD0-4A15-8D82-FB81F43C3DF7");
			addBankDetailsModel.setReferenceNumber("1473420");
			addBankDetailsModel.setAccountNumber();
			addBankDetailsModel.setBankCode();
			addBankDetailsModel.setCountry();
			addBankDetailsModel.setBankName();
			addBankDetailsModel.setCurrency();
			addBankDetailsModel.setIbanNumber();
			addBankDetailsModel.setInvoiceAmount();
			addBankDetailsModel.setPayeeName();
			addBankDetailsModel.setSwiftCode();
			
			boolean detailsAdded=bankDetailsService.addBankDetails(addBankDetailsModel);	
			
			assertTrue(detailsAdded);
			
			//rollback here 
			
		}catch(Exception e){
			
		}
		
	}*/
	
	/**
	 * Test add bank details call - negative test
	 */
	@Test
	public void confirmBankDetailsNegativeTest(){
		boolean detailsAdded=false;
		AddBankDetailsModel addBankDetailsRS=null;
		try{
			//Add the incorrect bank details
			addBankDetailsModel.setGuid("C9842DE3-BCD0-4A15-8D82-FB81F43C3DF7123");
			addBankDetailsModel.setReferenceNumber("1473420");
			
			
			addBankDetailsRS=bankDetailsService.addBankDetails(addBankDetailsModel);
			
			assertFalse(addBankDetailsRS.isSuccess());
			
		}catch(CustomerServicesException er){ 
			log.info("BankValidationTest :: Exception in confirmBankDetailsNegativeTest method " + er);			
		}catch (Exception e) {
			log.info("BankValidationTest :: Exception in confirmBankDetailsNegativeTest method " + e);	
			
		}
		
	}
	
	
}
