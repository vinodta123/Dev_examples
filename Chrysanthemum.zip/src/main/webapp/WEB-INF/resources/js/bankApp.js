
    
var jqAn = jQuery.noConflict(true);


jqAn(function($){

			/*************Already registered section ************/
			   $(".slidingDiv").hide();

			   $('.show_hide').bind('click',function(){
				   $("#plus").toggleClass("minus");
				   $(".slidingDiv").toggle();  
			   });
			/*************************************************/
			/***********Address section details***********/
			function logErr(msg){
				if(typeof console.log !== 'undefind'){
					console.log(msg);
				}else{
					alert(msg);
				}
			}
        
        
			
              $('.group').hide();
              $('#option1').show();
              $('#selectMe').change(function () {
                $('.group').hide();
                $('#'+$(this).val()).show();
              });
            
             /****Tooltip****/
            
            /* $('.infoTip').tooltipster({
                animation: 'fade',
                position: 'top',
                theme: 'my-custom-theme',
                offsetY: -5,
                trigger:'hover'
            });   */
            
            
          
          /******************************************************/
            $script([
			'./resources/js/forms.js'
		], function() {
			angular.bootstrap(document, ['vaa.forms']);
		});	
    
			
		});
		
