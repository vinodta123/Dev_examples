
/*global  document, navigator, $, jQuery, require, define, carousel, DD_belatedPNG, LBI, DI, CCM, self, top, confirm, TMAN, tmParam, angular, VAA */

angular.module('vaa.forms', []).
	constant('modelSuffix', 'Data').
	constant('backupSuffix', 'Backup').
	constant('acceptedNodes', {
		INPUT: true,
		TEXTAREA: true,
		SELECT: true,
		BUTTON: true
	}).

  /**
  

   * @ngdoc directive
   * @name vaa.forms:vaaForm
   *
   * @description
   * A directive to automatically add angular's functionality to a legacy form - it creates a model and a controller
   * that can be used to keep track of the form values and allows other scripts to interact with the form.
   *
   * @example
      <doc:example>
        <doc:source>
         <form data-vaa-form name="myForm">
           ...
         </form>
        </doc:source>
        <doc:scenario>
          it('should have created a model', function() {
          form = angular.element('<form name="testForm" data-vaa-form>' +
			'<fieldset>' +
				'<input type="text" id="tf1" name="textField1" required="required" data-ng-minlength="5" />' +
				'<button type="submit" id="sb">Submit button</button>' +
			'</fieldset>' +
			'</form>');
            expect(scope.testFormData).toBeDefined();
          });
        </doc:scenario>
      </doc:example>
   */
	directive('vaaForm', ['acceptedNodes', 'modelSuffix', 'backupSuffix', function (acceptedNodes, modelSuffix, backupSuffix) {
		'use strict';

		return {
			requires: 'ngModel',
			restrict: 'A',
			controller: ['$scope', '$compile', function ($scope, $compile) {
				
				
				angular.element('input.clickToClear[type=checkbox]').on('change', function (e) {
					e.stopImmediatePropagation();

					var thisForm = angular.element(this).parents('form').attr('id');

					if (!angular.element('#'+thisForm+' input[type="text"]').hasClass('ng-dirty') && !angular.element('#'+thisForm+' select').hasClass('ng-dirty') && !angular.element('#'+thisForm+' input[type="radio"]').hasClass('ng-dirty') && !angular.element('#'+thisForm+' input[type="email"]').hasClass('ng-dirty') && !angular.element('#'+thisForm+' input[type="tel"]').hasClass('ng-dirty')) {
					    angular.element('#'+thisForm+' :input').each(function() {
							if(!angular.element(this).hasClass('doNotClear')) {
								if((angular.element(this).prop('type') === 'radio') || (angular.element(this).prop('type') === 'checkbox') || (angular.element(this).prop('type') === 'text') || (angular.element(this).prop('type') === 'email') || (angular.element(this).prop('type') === 'select-one') || (angular.element(this).prop('type') === 'tel')) {
									$scope.clearInput(this);
								}
							}
						});
					}
				});
			
                $scope.validate = function() {
					var ctrls = arguments;
					$scope.safeApply(function() {
						var i = ctrls.length;
						while (i--) {
							var ctrl = ctrls[i];
							ctrl.$modelValue = new Date().getTime();
							ctrl.$setViewValue(ctrl.$viewValue);
						}
					});
				};

				$scope.safeApply = function(fn) {
					var phase = this.$root.$$phase;
					if(phase === '$apply' || phase === '$digest') {
						if(fn && (typeof(fn) === 'function')) {
							fn();
						}
					} else {
						this.$apply(fn);
					}
				};

				$scope.compile = function(el) {
					$scope.safeApply(function() {
						$compile(el)($scope);
					});
				};

				$scope.clearInput = function(el) {
					if (el.type === 'checkbox') {
						var model = $scope[el.form.name + modelSuffix][el.name],
							checkboxes = el.form[el.name];

						$scope.$apply(function() {
							for (var i = 0, ii = checkboxes.length; i < ii; i++) {
								checkboxes[i].checked = false;
								model[checkboxes[i].value] = false;
							}
							model.$length = 0;
						});
					} else if (el.type === 'radio') {
                        $scope[el.form.name][el.name].$setViewValue(undefined);
                        el.form[el.name].checked = false;
					} else {
						$scope[el.form.name][el.name].$setViewValue(undefined);
						angular.element(el).val('');
					}
				};

				$scope.resetInput = function(el) {
					var ctrl = $scope[el.form.name][el.name],
						backupValue = $scope[el.form.name + backupSuffix][el.name];
						$scope.safeApply(function() {
							$scope[el.form.name + modelSuffix][el.name] = backupValue;
						});
					ctrl.$setPristine();
				};
			}],
			compile: function($element) {
				var form = $element[0];
				var formName = angular.element(form).attr('name');
				// Only process the form if it has a name - we need the name to use when
				// creating the model, also, Angular only processes forms with names.
				if (formName) {

					var PATTERN = 'pattern',
						MAXLENGTH = 'maxlength',
						NG_PATTERN = 'ng-pattern',
						NG_MAXLENGTH = 'ng-maxlength',
						formModelName = formName + modelSuffix;

					for (var i = 0, numElements = form.elements.length; i < numElements; i++) {
						var el = form.elements[i],
							elName = '[\'' + el.name + '\']';

						if (el.name && acceptedNodes[el.nodeName.toUpperCase()]){
							if (el.type === 'checkbox') {
								elName += '[\'' + el.value + '\']';
							}
							// Adds the ng-model attribute so Angular can create bindings
							el.setAttribute('ng-model', formModelName + elName);

							// Converts patterns into angular
							var pattern = el.getAttribute(PATTERN);
							if (pattern) {
								el.setAttribute(NG_PATTERN, pattern);
								el.removeAttribute(PATTERN);
							}

							// Convert the max length attribute into angular
							var maxlength = el.getAttribute(MAXLENGTH);
							if (maxlength) {
								el.setAttribute(NG_MAXLENGTH, maxlength);
								el.removeAttribute(MAXLENGTH);
							}
						}
					}

					// Disable html5's validation - use Angula's instead
					$element.attr('novalidate', 'novalidate');

					return {
						pre: function(scope, $element) {
							var elements = $element[0].elements,
								formModel = scope[formModelName] = {};

							for (var i = 0, numElements = elements.length; i < numElements; i++) {
								var el = elements[i];
								if ( el.name && acceptedNodes[el.nodeName.toUpperCase()]) {
									// Adds support for multiple checkboxes with the same name
									if (el.type === 'checkbox') {
										if (!formModel[el.name]) {
											formModel[el.name] = {
												$length: 0 // Keeps track of the number of checked checkboxes
											};
										}
										// Create a key in the model using the value attribute of the checkbox
										formModel[el.name][el.value] = el.checked;
										if (el.checked) {
											// Updates the checked counter
											formModel[el.name].$length++;
										}
									} else {
										var value = angular.element(el).val();
										// for any input which isn't an unselected radio button
										if (value && (el.type !== 'radio' || el.checked)) {
											// Create a key in the model using the name attribute
											formModel[el.name] = value;
										}
									}
								}
							}
							
							// Creates a copy of the model so the form can be reset to original values
							//scope[form.name + backupSuffix] = angular.copy(scope[formModelName]);
						},
						post: function(scope, $element) {
							var form = $element[0],
								formModel = scope[formModelName],
								formController = $element.data('$formController'),
								focusBlurSelector = 'input, select, textarea';

							/**********Function for region selection **************/
								var countryEle = angular.element('[name=country]');
								var countryVal = countryEle.val(),
								    countryTextEle = angular.element('#countryName'),
									countrytextVal = countryEle.find("option:selected").text();
								countryTextEle.val(countrytextVal);
								scope.region = (countryVal)?countryVal.split('_')[0]:'euro';
								countryEle.on('change', function (e, formModel, formController) {
									scope.region=true;
									var self = angular.element(this),
									    countryTextEle = angular.element('#countryName'),
									countrytextVal = self.find("option:selected").text(),
									countryVal = self.val().split('_');
									scope.region = countryVal[0];									
									countryTextEle.val(countrytextVal);
									self.blur();
									//scope.bankForm.$setPristine();
								});
								/*************************************************/
								
								
								/*************IBAN and Bank Ac*************/
								//scope.bankacc = true;	
								var radioEle = angular.element('[name=othersPayMethod]:checked'),
								  radioEleVal = radioEle.val();
								  if(radioEleVal == 'iban'){scope.iban = true;scope.bankacc = false;}
								  if(radioEleVal == 'bankacc' || radioEleVal == null || radioEleVal == 'undefind'){scope.iban = false;scope.bankacc = true;}
								angular.element('[name=othersPayMethod]').on('change', function (e) {
									var self = angular.element(this),
										selectedVal = self.attr('value');						
									if(selectedVal == 'iban'){scope.iban = true;scope.bankacc = false;}
									if(selectedVal == 'bankacc'){scope.iban = false;scope.bankacc = true;}
									
									
								});

								/********************************************************/	
								
							$element.
								on('focus', focusBlurSelector, function(event) {
									if (formController) {
										var el = formController[event.currentTarget.name];
										if (el) {
											scope.$apply(function() {
												el.hasFocus = true;
											});
										}
									}
								}).
								on('blur', focusBlurSelector, function(event) {
									if (formController) {
										var el = formController[event.currentTarget.name];
										if (el) {
											scope.$apply(function() {
												el.hasFocus = false;
											});
										}
									}
								}).
								on('click', ':checkbox', function(event) {
									/**
									 * Updates checkbox states on click - this is necessary because Angular doesn't
									 * support multiple checkboxes with the same name, but often we need multiple
									 * checkboxes with one name and many values.
									 */
									var cb = event.currentTarget,
										// cbController is the controller for the first checkbox -
										// Angular ignores additional checkboxes with the same name.
										cbController = formController[cb.name];
									if (cbController) {
										scope.$apply(function() {
											var model = formModel[cb.name];

											if (cb.checked) {
												model.$length++;
											} else {
												model.$length--;
											}
											// If there are more than one checkboxes and this checkbox is not the first, we need to set things manually
											if (form[cb.name].length && form[cb.name][0] !== cb) {
												cbController.$dirty = true;
												cbController.$pristine = false;
												cbController.$setValidity('required', !!model.$length);
											}
										});
									}
								}).
								on('keypress', ':input[data-server-invalid]', function(event) {
									var _self = angular.element(event.target);
									scope.$apply(function() {
										console.log('change');
										scope.showInvalidError = false;
										formController.showErrors = false;
										_self.removeClass('ng-invalid-reference-number');
										formController['referenceNumber'].$setValidity('reference-server',true);
									});
								}).
								on('reset', function(event) {
									scope.$apply(function() {
										scope[formModelName] = angular.copy(scope[formController.$name + backupSuffix]);
										formController.$setPristine();
									});
								}).
								on('submit', function formSubmitAction() {

									if (formController.$invalid) {
										scope.$apply(function() {
										   /* if(formController.referenceNumber.$invalid.referenceNumber){
												ctrl.$setValidity('referenceNumber', true); 
											}else*/
											formController.showErrors = true;
											$element.addClass('show-errors');
										});
										$element.find('.ng-invalid:first').focus();
										return false;
									}
								});
						}
					};
				}
			}
		};
	}]).
    
	directive('singleInput', function () {
		return {
						restrict:'A',
			require: 'ngModel',
			link: function(scope, $element, attr, ctrl) { 
				scope.$watch(function(){
					var ctrls = angular.element('[data-single-input]'),
					_self = angular.element($element),
					_selfVal = angular.element(ctrls[0]).val(),
					_otherVal = angular.element(ctrls[1]).val(),
					isValid = (!!_selfVal && !!_otherVal),
					ctrollerModel = $element.controller('ngModel');
					(isValid)?ctrollerModel.$setValidity('singleval',false):ctrollerModel.$setValidity('singleval',true);
				});
			}
		};
	}).

	directive('infotip', function () {
	    return {
	        /*require: 'ngModel',*/
	        link: function(scope, $element, attr, ctrl) {          
			   $element.tooltipster({
                animation: 'fade',
                position: 'top',
                theme: 'my-custom-theme',
                offsetY: -5,
                trigger:'hover'
            });   
	        }
	    };
	}).

	directive('serverInvalid', function () {
	    return {
	        require: 'ngModel',
	        link: function(scope, $element, attr, ctrl) {   
				var formElement = $element.parents('form[name="bankForm"]'),
					controllerModel = $element.controller('ngModel');
					formController = angular.element('form[name="bankForm"]').controller('ngModel');
					scope['bankForm'].showErrors =true;
                if($element.attr('data-server-invalid') == 'true')
					{	 
						$element.addClass('ng-invalid-reference-number');
						scope.showInvalidError = true;
						controllerModel.$setValidity('reference-server',false);
						$element.blur();
						setTimeout(function(){$element.focus();},100);
						
					}else{
						
						$element.removeClass('ng-invalid-reference-number');
						scope.showInvalidError = false;
						controllerModel.$setValidity('reference-server',true);
					}
	        }
	    };
	}).
	
	directive('serverValue', function () {
	    return {
		    restrict:'A',
	        require: 'ngModel',
	        link: function(scope, $element, attr, ctrl) {  
				//scope.$apply(function(){
					var _selfValue = $element.attr('data-server-value');
					if(_selfValue)
						{	
							
							$element.controller('ngModel').$setViewValue(_selfValue);
							$element.controller('ngModel').$render();
						}

				//});
	        }
	    };
	}).

	directive('fileinput', function () {
	    return {
	        require: 'ngModel',
	        link: function(scope, $element, attr, ctrl) {
	            ctrl.$render = function () {
	                ctrl.$setViewValue($element.val());
	            };

	            $element.bind('change', function(){
	                scope.$apply(function(){
	                    ctrl.$render();
	                });
	            });
	        }
	    };
	}).

	animation('show-error', [function() {
		return {
			start : function(element, done) {
				element.stop().fadeTo('slow', 1, function () {
					done();
				});
			}
		};
	}]).

	animation('hide-error', [function() {
		return {
			start : function(element, done) {
				element.stop().fadeOut('slow', function () {
					done();
				});
			}
		};
	}]).

	animation('show-input', [function() {
		return {
			setup: function(element) {
				element.hide();
			},
			start : function(element, done) {
				element.stop().slideDown('slow', function () {
					done();
				});
			}
		};
	}]).

	animation('hide-input', [function() {
		return {
			start : function(element, done) {
				element.stop().slideUp('slow', function () {
					done();
				});
			}
		};
	}])
;
