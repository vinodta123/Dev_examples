/**
 * AddBankDetails_RQEntities.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1;

public class AddBankDetails_RQEntities  implements java.io.Serializable {
    private java.lang.String randiId;

    private java.lang.String transactionId;

    private java.lang.String payeeName;

    private java.lang.String currencyCode;

    private java.lang.String bankCode;

    private java.lang.String bankAccountNumber;

    private java.lang.String IBAN;

    private java.lang.String swiftCode;

    private java.lang.String bankName;

    private java.lang.String bankCountrycode;

    private java.lang.String bankDetailsAddedBy;

    public AddBankDetails_RQEntities() {
    }

    public AddBankDetails_RQEntities(
           java.lang.String randiId,
           java.lang.String transactionId,
           java.lang.String payeeName,
           java.lang.String currencyCode,
           java.lang.String bankCode,
           java.lang.String bankAccountNumber,
           java.lang.String IBAN,
           java.lang.String swiftCode,
           java.lang.String bankName,
           java.lang.String bankCountrycode,
           java.lang.String bankDetailsAddedBy) {
           this.randiId = randiId;
           this.transactionId = transactionId;
           this.payeeName = payeeName;
           this.currencyCode = currencyCode;
           this.bankCode = bankCode;
           this.bankAccountNumber = bankAccountNumber;
           this.IBAN = IBAN;
           this.swiftCode = swiftCode;
           this.bankName = bankName;
           this.bankCountrycode = bankCountrycode;
           this.bankDetailsAddedBy = bankDetailsAddedBy;
    }


    /**
     * Gets the randiId value for this AddBankDetails_RQEntities.
     * 
     * @return randiId
     */
    public java.lang.String getRandiId() {
        return randiId;
    }


    /**
     * Sets the randiId value for this AddBankDetails_RQEntities.
     * 
     * @param randiId
     */
    public void setRandiId(java.lang.String randiId) {
        this.randiId = randiId;
    }


    /**
     * Gets the transactionId value for this AddBankDetails_RQEntities.
     * 
     * @return transactionId
     */
    public java.lang.String getTransactionId() {
        return transactionId;
    }


    /**
     * Sets the transactionId value for this AddBankDetails_RQEntities.
     * 
     * @param transactionId
     */
    public void setTransactionId(java.lang.String transactionId) {
        this.transactionId = transactionId;
    }


    /**
     * Gets the payeeName value for this AddBankDetails_RQEntities.
     * 
     * @return payeeName
     */
    public java.lang.String getPayeeName() {
        return payeeName;
    }


    /**
     * Sets the payeeName value for this AddBankDetails_RQEntities.
     * 
     * @param payeeName
     */
    public void setPayeeName(java.lang.String payeeName) {
        this.payeeName = payeeName;
    }


    /**
     * Gets the currencyCode value for this AddBankDetails_RQEntities.
     * 
     * @return currencyCode
     */
    public java.lang.String getCurrencyCode() {
        return currencyCode;
    }


    /**
     * Sets the currencyCode value for this AddBankDetails_RQEntities.
     * 
     * @param currencyCode
     */
    public void setCurrencyCode(java.lang.String currencyCode) {
        this.currencyCode = currencyCode;
    }


    /**
     * Gets the bankCode value for this AddBankDetails_RQEntities.
     * 
     * @return bankCode
     */
    public java.lang.String getBankCode() {
        return bankCode;
    }


    /**
     * Sets the bankCode value for this AddBankDetails_RQEntities.
     * 
     * @param bankCode
     */
    public void setBankCode(java.lang.String bankCode) {
        this.bankCode = bankCode;
    }


    /**
     * Gets the bankAccountNumber value for this AddBankDetails_RQEntities.
     * 
     * @return bankAccountNumber
     */
    public java.lang.String getBankAccountNumber() {
        return bankAccountNumber;
    }


    /**
     * Sets the bankAccountNumber value for this AddBankDetails_RQEntities.
     * 
     * @param bankAccountNumber
     */
    public void setBankAccountNumber(java.lang.String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }


    /**
     * Gets the IBAN value for this AddBankDetails_RQEntities.
     * 
     * @return IBAN
     */
    public java.lang.String getIBAN() {
        return IBAN;
    }


    /**
     * Sets the IBAN value for this AddBankDetails_RQEntities.
     * 
     * @param IBAN
     */
    public void setIBAN(java.lang.String IBAN) {
        this.IBAN = IBAN;
    }


    /**
     * Gets the swiftCode value for this AddBankDetails_RQEntities.
     * 
     * @return swiftCode
     */
    public java.lang.String getSwiftCode() {
        return swiftCode;
    }


    /**
     * Sets the swiftCode value for this AddBankDetails_RQEntities.
     * 
     * @param swiftCode
     */
    public void setSwiftCode(java.lang.String swiftCode) {
        this.swiftCode = swiftCode;
    }


    /**
     * Gets the bankName value for this AddBankDetails_RQEntities.
     * 
     * @return bankName
     */
    public java.lang.String getBankName() {
        return bankName;
    }


    /**
     * Sets the bankName value for this AddBankDetails_RQEntities.
     * 
     * @param bankName
     */
    public void setBankName(java.lang.String bankName) {
        this.bankName = bankName;
    }


    /**
     * Gets the bankCountrycode value for this AddBankDetails_RQEntities.
     * 
     * @return bankCountrycode
     */
    public java.lang.String getBankCountrycode() {
        return bankCountrycode;
    }


    /**
     * Sets the bankCountrycode value for this AddBankDetails_RQEntities.
     * 
     * @param bankCountrycode
     */
    public void setBankCountrycode(java.lang.String bankCountrycode) {
        this.bankCountrycode = bankCountrycode;
    }


    /**
     * Gets the bankDetailsAddedBy value for this AddBankDetails_RQEntities.
     * 
     * @return bankDetailsAddedBy
     */
    public java.lang.String getBankDetailsAddedBy() {
        return bankDetailsAddedBy;
    }


    /**
     * Sets the bankDetailsAddedBy value for this AddBankDetails_RQEntities.
     * 
     * @param bankDetailsAddedBy
     */
    public void setBankDetailsAddedBy(java.lang.String bankDetailsAddedBy) {
        this.bankDetailsAddedBy = bankDetailsAddedBy;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AddBankDetails_RQEntities)) return false;
        AddBankDetails_RQEntities other = (AddBankDetails_RQEntities) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.randiId==null && other.getRandiId()==null) || 
             (this.randiId!=null &&
              this.randiId.equals(other.getRandiId()))) &&
            ((this.transactionId==null && other.getTransactionId()==null) || 
             (this.transactionId!=null &&
              this.transactionId.equals(other.getTransactionId()))) &&
            ((this.payeeName==null && other.getPayeeName()==null) || 
             (this.payeeName!=null &&
              this.payeeName.equals(other.getPayeeName()))) &&
            ((this.currencyCode==null && other.getCurrencyCode()==null) || 
             (this.currencyCode!=null &&
              this.currencyCode.equals(other.getCurrencyCode()))) &&
            ((this.bankCode==null && other.getBankCode()==null) || 
             (this.bankCode!=null &&
              this.bankCode.equals(other.getBankCode()))) &&
            ((this.bankAccountNumber==null && other.getBankAccountNumber()==null) || 
             (this.bankAccountNumber!=null &&
              this.bankAccountNumber.equals(other.getBankAccountNumber()))) &&
            ((this.IBAN==null && other.getIBAN()==null) || 
             (this.IBAN!=null &&
              this.IBAN.equals(other.getIBAN()))) &&
            ((this.swiftCode==null && other.getSwiftCode()==null) || 
             (this.swiftCode!=null &&
              this.swiftCode.equals(other.getSwiftCode()))) &&
            ((this.bankName==null && other.getBankName()==null) || 
             (this.bankName!=null &&
              this.bankName.equals(other.getBankName()))) &&
            ((this.bankCountrycode==null && other.getBankCountrycode()==null) || 
             (this.bankCountrycode!=null &&
              this.bankCountrycode.equals(other.getBankCountrycode()))) &&
            ((this.bankDetailsAddedBy==null && other.getBankDetailsAddedBy()==null) || 
             (this.bankDetailsAddedBy!=null &&
              this.bankDetailsAddedBy.equals(other.getBankDetailsAddedBy())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getRandiId() != null) {
            _hashCode += getRandiId().hashCode();
        }
        if (getTransactionId() != null) {
            _hashCode += getTransactionId().hashCode();
        }
        if (getPayeeName() != null) {
            _hashCode += getPayeeName().hashCode();
        }
        if (getCurrencyCode() != null) {
            _hashCode += getCurrencyCode().hashCode();
        }
        if (getBankCode() != null) {
            _hashCode += getBankCode().hashCode();
        }
        if (getBankAccountNumber() != null) {
            _hashCode += getBankAccountNumber().hashCode();
        }
        if (getIBAN() != null) {
            _hashCode += getIBAN().hashCode();
        }
        if (getSwiftCode() != null) {
            _hashCode += getSwiftCode().hashCode();
        }
        if (getBankName() != null) {
            _hashCode += getBankName().hashCode();
        }
        if (getBankCountrycode() != null) {
            _hashCode += getBankCountrycode().hashCode();
        }
        if (getBankDetailsAddedBy() != null) {
            _hashCode += getBankDetailsAddedBy().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AddBankDetails_RQEntities.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "AddBankDetails_RQEntities"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("randiId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RandiId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "TransactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payeeName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "PayeeName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currencyCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CurrencyCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "BankCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankAccountNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "BankAccountNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IBAN");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "IBAN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("swiftCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "SwiftCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "BankName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankCountrycode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "BankCountrycode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankDetailsAddedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "BankDetailsAddedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
