/**
 * ValidateGUID_RQEntities.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1;

public class ValidateGUID_RQEntities  implements java.io.Serializable {
    private java.lang.String transactionId;

    private java.lang.String randiId;

    public ValidateGUID_RQEntities() {
    }

    public ValidateGUID_RQEntities(
           java.lang.String transactionId,
           java.lang.String randiId) {
           this.transactionId = transactionId;
           this.randiId = randiId;
    }


    /**
     * Gets the transactionId value for this ValidateGUID_RQEntities.
     * 
     * @return transactionId
     */
    public java.lang.String getTransactionId() {
        return transactionId;
    }


    /**
     * Sets the transactionId value for this ValidateGUID_RQEntities.
     * 
     * @param transactionId
     */
    public void setTransactionId(java.lang.String transactionId) {
        this.transactionId = transactionId;
    }


    /**
     * Gets the randiId value for this ValidateGUID_RQEntities.
     * 
     * @return randiId
     */
    public java.lang.String getRandiId() {
        return randiId;
    }


    /**
     * Sets the randiId value for this ValidateGUID_RQEntities.
     * 
     * @param randiId
     */
    public void setRandiId(java.lang.String randiId) {
        this.randiId = randiId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ValidateGUID_RQEntities)) return false;
        ValidateGUID_RQEntities other = (ValidateGUID_RQEntities) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transactionId==null && other.getTransactionId()==null) || 
             (this.transactionId!=null &&
              this.transactionId.equals(other.getTransactionId()))) &&
            ((this.randiId==null && other.getRandiId()==null) || 
             (this.randiId!=null &&
              this.randiId.equals(other.getRandiId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransactionId() != null) {
            _hashCode += getTransactionId().hashCode();
        }
        if (getRandiId() != null) {
            _hashCode += getRandiId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ValidateGUID_RQEntities.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateGUID_RQEntities"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "TransactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("randiId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RandiId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
