package com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1;

public class ICompensationWebServiceProxy implements com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ICompensationWebService {
  private String _endpoint = null;
  private com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ICompensationWebService iCompensationWebService = null;
  
  public ICompensationWebServiceProxy() {
    _initICompensationWebServiceProxy();
  }
  
  public ICompensationWebServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initICompensationWebServiceProxy();
  }
  
  private void _initICompensationWebServiceProxy() {
    try {
      iCompensationWebService = (new com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CompensationWebServiceLocator()).getBasicHttpBinding_ICompensationWebService();
      if (iCompensationWebService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iCompensationWebService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iCompensationWebService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iCompensationWebService != null)
      ((javax.xml.rpc.Stub)iCompensationWebService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ICompensationWebService getICompensationWebService() {
    if (iCompensationWebService == null)
      _initICompensationWebServiceProxy();
    return iCompensationWebService;
  }
  
  public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RS createTransaction(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RQEntities createTransaction_RQ) throws java.rmi.RemoteException{
    if (iCompensationWebService == null)
      _initICompensationWebServiceProxy();
    return iCompensationWebService.createTransaction(createTransaction_RQ);
  }
  
  public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RS receiveGUIDInfo(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RQEntities recieveGUIDInfo_RQ) throws java.rmi.RemoteException{
    if (iCompensationWebService == null)
      _initICompensationWebServiceProxy();
    return iCompensationWebService.receiveGUIDInfo(recieveGUIDInfo_RQ);
  }
  
  public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RS validateGUID(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RQEntities validateGUID_RQ) throws java.rmi.RemoteException{
    if (iCompensationWebService == null)
      _initICompensationWebServiceProxy();
    return iCompensationWebService.validateGUID(validateGUID_RQ);
  }
  
  public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RS addBankDetails(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RQEntities addBankDetails_RQ) throws java.rmi.RemoteException{
    if (iCompensationWebService == null)
      _initICompensationWebServiceProxy();
    return iCompensationWebService.addBankDetails(addBankDetails_RQ);
  }
  
  public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RS validateRANDIID(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RQEntities validateRANDIID_RQ) throws java.rmi.RemoteException{
    if (iCompensationWebService == null)
      _initICompensationWebServiceProxy();
    return iCompensationWebService.validateRANDIID(validateRANDIID_RQ);
  }
  
  public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RS getFilteredLines(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RQEntities getFilteredLines_RQ) throws java.rmi.RemoteException{
    if (iCompensationWebService == null)
      _initICompensationWebServiceProxy();
    return iCompensationWebService.getFilteredLines(getFilteredLines_RQ);
  }
  
  public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RS updateTransaction(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RQEntities updateTransaction_RQ) throws java.rmi.RemoteException{
    if (iCompensationWebService == null)
      _initICompensationWebServiceProxy();
    return iCompensationWebService.updateTransaction(updateTransaction_RQ);
  }
  
  public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RS sendEmail(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RQEntities sendEmail_RQ) throws java.rmi.RemoteException{
    if (iCompensationWebService == null)
      _initICompensationWebServiceProxy();
    return iCompensationWebService.sendEmail(sendEmail_RQ);
  }
  
  
}