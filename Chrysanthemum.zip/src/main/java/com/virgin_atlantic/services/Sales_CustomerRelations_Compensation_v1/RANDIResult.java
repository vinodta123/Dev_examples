/**
 * RANDIResult.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1;

public class RANDIResult  implements java.io.Serializable {
    private java.lang.String result;

    private int randiId;

    private java.lang.String randiSubId;

    private java.lang.String complainantName;

    private java.lang.String complainantEmail;

    private java.lang.String claimType;

    private java.lang.String currencyCode;

    private java.math.BigDecimal invoiceAmount;

    private java.lang.String costCode;

    private java.lang.String authorisedBy;

    private java.lang.String authorizedOn;

    private java.lang.String rejectedBy;

    private java.lang.String rejectedOn;

    private java.lang.String voidedBy;

    private java.lang.String voidedOn;

    private java.lang.String bankDetailsAddedBy;

    private java.lang.String bankDetailsAddedOn;

    private java.lang.String sentToFinanceOn;

    private java.lang.String randiAgent;

    private java.lang.String failedAttempts;

    private java.lang.String randiCreationDate;

    private java.lang.String status;

    private java.lang.String transactionId;

    public RANDIResult() {
    }

    public RANDIResult(
           java.lang.String result,
           int randiId,
           java.lang.String randiSubId,
           java.lang.String complainantName,
           java.lang.String complainantEmail,
           java.lang.String claimType,
           java.lang.String currencyCode,
           java.math.BigDecimal invoiceAmount,
           java.lang.String costCode,
           java.lang.String authorisedBy,
           java.lang.String authorizedOn,
           java.lang.String rejectedBy,
           java.lang.String rejectedOn,
           java.lang.String voidedBy,
           java.lang.String voidedOn,
           java.lang.String bankDetailsAddedBy,
           java.lang.String bankDetailsAddedOn,
           java.lang.String sentToFinanceOn,
           java.lang.String randiAgent,
           java.lang.String failedAttempts,
           java.lang.String randiCreationDate,
           java.lang.String status,
           java.lang.String transactionId) {
           this.result = result;
           this.randiId = randiId;
           this.randiSubId = randiSubId;
           this.complainantName = complainantName;
           this.complainantEmail = complainantEmail;
           this.claimType = claimType;
           this.currencyCode = currencyCode;
           this.invoiceAmount = invoiceAmount;
           this.costCode = costCode;
           this.authorisedBy = authorisedBy;
           this.authorizedOn = authorizedOn;
           this.rejectedBy = rejectedBy;
           this.rejectedOn = rejectedOn;
           this.voidedBy = voidedBy;
           this.voidedOn = voidedOn;
           this.bankDetailsAddedBy = bankDetailsAddedBy;
           this.bankDetailsAddedOn = bankDetailsAddedOn;
           this.sentToFinanceOn = sentToFinanceOn;
           this.randiAgent = randiAgent;
           this.failedAttempts = failedAttempts;
           this.randiCreationDate = randiCreationDate;
           this.status = status;
           this.transactionId = transactionId;
    }


    /**
     * Gets the result value for this RANDIResult.
     * 
     * @return result
     */
    public java.lang.String getResult() {
        return result;
    }


    /**
     * Sets the result value for this RANDIResult.
     * 
     * @param result
     */
    public void setResult(java.lang.String result) {
        this.result = result;
    }


    /**
     * Gets the randiId value for this RANDIResult.
     * 
     * @return randiId
     */
    public int getRandiId() {
        return randiId;
    }


    /**
     * Sets the randiId value for this RANDIResult.
     * 
     * @param randiId
     */
    public void setRandiId(int randiId) {
        this.randiId = randiId;
    }


    /**
     * Gets the randiSubId value for this RANDIResult.
     * 
     * @return randiSubId
     */
    public java.lang.String getRandiSubId() {
        return randiSubId;
    }


    /**
     * Sets the randiSubId value for this RANDIResult.
     * 
     * @param randiSubId
     */
    public void setRandiSubId(java.lang.String randiSubId) {
        this.randiSubId = randiSubId;
    }


    /**
     * Gets the complainantName value for this RANDIResult.
     * 
     * @return complainantName
     */
    public java.lang.String getComplainantName() {
        return complainantName;
    }


    /**
     * Sets the complainantName value for this RANDIResult.
     * 
     * @param complainantName
     */
    public void setComplainantName(java.lang.String complainantName) {
        this.complainantName = complainantName;
    }


    /**
     * Gets the complainantEmail value for this RANDIResult.
     * 
     * @return complainantEmail
     */
    public java.lang.String getComplainantEmail() {
        return complainantEmail;
    }


    /**
     * Sets the complainantEmail value for this RANDIResult.
     * 
     * @param complainantEmail
     */
    public void setComplainantEmail(java.lang.String complainantEmail) {
        this.complainantEmail = complainantEmail;
    }


    /**
     * Gets the claimType value for this RANDIResult.
     * 
     * @return claimType
     */
    public java.lang.String getClaimType() {
        return claimType;
    }


    /**
     * Sets the claimType value for this RANDIResult.
     * 
     * @param claimType
     */
    public void setClaimType(java.lang.String claimType) {
        this.claimType = claimType;
    }


    /**
     * Gets the currencyCode value for this RANDIResult.
     * 
     * @return currencyCode
     */
    public java.lang.String getCurrencyCode() {
        return currencyCode;
    }


    /**
     * Sets the currencyCode value for this RANDIResult.
     * 
     * @param currencyCode
     */
    public void setCurrencyCode(java.lang.String currencyCode) {
        this.currencyCode = currencyCode;
    }


    /**
     * Gets the invoiceAmount value for this RANDIResult.
     * 
     * @return invoiceAmount
     */
    public java.math.BigDecimal getInvoiceAmount() {
        return invoiceAmount;
    }


    /**
     * Sets the invoiceAmount value for this RANDIResult.
     * 
     * @param invoiceAmount
     */
    public void setInvoiceAmount(java.math.BigDecimal invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }


    /**
     * Gets the costCode value for this RANDIResult.
     * 
     * @return costCode
     */
    public java.lang.String getCostCode() {
        return costCode;
    }


    /**
     * Sets the costCode value for this RANDIResult.
     * 
     * @param costCode
     */
    public void setCostCode(java.lang.String costCode) {
        this.costCode = costCode;
    }


    /**
     * Gets the authorisedBy value for this RANDIResult.
     * 
     * @return authorisedBy
     */
    public java.lang.String getAuthorisedBy() {
        return authorisedBy;
    }


    /**
     * Sets the authorisedBy value for this RANDIResult.
     * 
     * @param authorisedBy
     */
    public void setAuthorisedBy(java.lang.String authorisedBy) {
        this.authorisedBy = authorisedBy;
    }


    /**
     * Gets the authorizedOn value for this RANDIResult.
     * 
     * @return authorizedOn
     */
    public java.lang.String getAuthorizedOn() {
        return authorizedOn;
    }


    /**
     * Sets the authorizedOn value for this RANDIResult.
     * 
     * @param authorizedOn
     */
    public void setAuthorizedOn(java.lang.String authorizedOn) {
        this.authorizedOn = authorizedOn;
    }


    /**
     * Gets the rejectedBy value for this RANDIResult.
     * 
     * @return rejectedBy
     */
    public java.lang.String getRejectedBy() {
        return rejectedBy;
    }


    /**
     * Sets the rejectedBy value for this RANDIResult.
     * 
     * @param rejectedBy
     */
    public void setRejectedBy(java.lang.String rejectedBy) {
        this.rejectedBy = rejectedBy;
    }


    /**
     * Gets the rejectedOn value for this RANDIResult.
     * 
     * @return rejectedOn
     */
    public java.lang.String getRejectedOn() {
        return rejectedOn;
    }


    /**
     * Sets the rejectedOn value for this RANDIResult.
     * 
     * @param rejectedOn
     */
    public void setRejectedOn(java.lang.String rejectedOn) {
        this.rejectedOn = rejectedOn;
    }


    /**
     * Gets the voidedBy value for this RANDIResult.
     * 
     * @return voidedBy
     */
    public java.lang.String getVoidedBy() {
        return voidedBy;
    }


    /**
     * Sets the voidedBy value for this RANDIResult.
     * 
     * @param voidedBy
     */
    public void setVoidedBy(java.lang.String voidedBy) {
        this.voidedBy = voidedBy;
    }


    /**
     * Gets the voidedOn value for this RANDIResult.
     * 
     * @return voidedOn
     */
    public java.lang.String getVoidedOn() {
        return voidedOn;
    }


    /**
     * Sets the voidedOn value for this RANDIResult.
     * 
     * @param voidedOn
     */
    public void setVoidedOn(java.lang.String voidedOn) {
        this.voidedOn = voidedOn;
    }


    /**
     * Gets the bankDetailsAddedBy value for this RANDIResult.
     * 
     * @return bankDetailsAddedBy
     */
    public java.lang.String getBankDetailsAddedBy() {
        return bankDetailsAddedBy;
    }


    /**
     * Sets the bankDetailsAddedBy value for this RANDIResult.
     * 
     * @param bankDetailsAddedBy
     */
    public void setBankDetailsAddedBy(java.lang.String bankDetailsAddedBy) {
        this.bankDetailsAddedBy = bankDetailsAddedBy;
    }


    /**
     * Gets the bankDetailsAddedOn value for this RANDIResult.
     * 
     * @return bankDetailsAddedOn
     */
    public java.lang.String getBankDetailsAddedOn() {
        return bankDetailsAddedOn;
    }


    /**
     * Sets the bankDetailsAddedOn value for this RANDIResult.
     * 
     * @param bankDetailsAddedOn
     */
    public void setBankDetailsAddedOn(java.lang.String bankDetailsAddedOn) {
        this.bankDetailsAddedOn = bankDetailsAddedOn;
    }


    /**
     * Gets the sentToFinanceOn value for this RANDIResult.
     * 
     * @return sentToFinanceOn
     */
    public java.lang.String getSentToFinanceOn() {
        return sentToFinanceOn;
    }


    /**
     * Sets the sentToFinanceOn value for this RANDIResult.
     * 
     * @param sentToFinanceOn
     */
    public void setSentToFinanceOn(java.lang.String sentToFinanceOn) {
        this.sentToFinanceOn = sentToFinanceOn;
    }


    /**
     * Gets the randiAgent value for this RANDIResult.
     * 
     * @return randiAgent
     */
    public java.lang.String getRandiAgent() {
        return randiAgent;
    }


    /**
     * Sets the randiAgent value for this RANDIResult.
     * 
     * @param randiAgent
     */
    public void setRandiAgent(java.lang.String randiAgent) {
        this.randiAgent = randiAgent;
    }


    /**
     * Gets the failedAttempts value for this RANDIResult.
     * 
     * @return failedAttempts
     */
    public java.lang.String getFailedAttempts() {
        return failedAttempts;
    }


    /**
     * Sets the failedAttempts value for this RANDIResult.
     * 
     * @param failedAttempts
     */
    public void setFailedAttempts(java.lang.String failedAttempts) {
        this.failedAttempts = failedAttempts;
    }


    /**
     * Gets the randiCreationDate value for this RANDIResult.
     * 
     * @return randiCreationDate
     */
    public java.lang.String getRandiCreationDate() {
        return randiCreationDate;
    }


    /**
     * Sets the randiCreationDate value for this RANDIResult.
     * 
     * @param randiCreationDate
     */
    public void setRandiCreationDate(java.lang.String randiCreationDate) {
        this.randiCreationDate = randiCreationDate;
    }


    /**
     * Gets the status value for this RANDIResult.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this RANDIResult.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the transactionId value for this RANDIResult.
     * 
     * @return transactionId
     */
    public java.lang.String getTransactionId() {
        return transactionId;
    }


    /**
     * Sets the transactionId value for this RANDIResult.
     * 
     * @param transactionId
     */
    public void setTransactionId(java.lang.String transactionId) {
        this.transactionId = transactionId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RANDIResult)) return false;
        RANDIResult other = (RANDIResult) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.result==null && other.getResult()==null) || 
             (this.result!=null &&
              this.result.equals(other.getResult()))) &&
            this.randiId == other.getRandiId() &&
            ((this.randiSubId==null && other.getRandiSubId()==null) || 
             (this.randiSubId!=null &&
              this.randiSubId.equals(other.getRandiSubId()))) &&
            ((this.complainantName==null && other.getComplainantName()==null) || 
             (this.complainantName!=null &&
              this.complainantName.equals(other.getComplainantName()))) &&
            ((this.complainantEmail==null && other.getComplainantEmail()==null) || 
             (this.complainantEmail!=null &&
              this.complainantEmail.equals(other.getComplainantEmail()))) &&
            ((this.claimType==null && other.getClaimType()==null) || 
             (this.claimType!=null &&
              this.claimType.equals(other.getClaimType()))) &&
            ((this.currencyCode==null && other.getCurrencyCode()==null) || 
             (this.currencyCode!=null &&
              this.currencyCode.equals(other.getCurrencyCode()))) &&
            ((this.invoiceAmount==null && other.getInvoiceAmount()==null) || 
             (this.invoiceAmount!=null &&
              this.invoiceAmount.equals(other.getInvoiceAmount()))) &&
            ((this.costCode==null && other.getCostCode()==null) || 
             (this.costCode!=null &&
              this.costCode.equals(other.getCostCode()))) &&
            ((this.authorisedBy==null && other.getAuthorisedBy()==null) || 
             (this.authorisedBy!=null &&
              this.authorisedBy.equals(other.getAuthorisedBy()))) &&
            ((this.authorizedOn==null && other.getAuthorizedOn()==null) || 
             (this.authorizedOn!=null &&
              this.authorizedOn.equals(other.getAuthorizedOn()))) &&
            ((this.rejectedBy==null && other.getRejectedBy()==null) || 
             (this.rejectedBy!=null &&
              this.rejectedBy.equals(other.getRejectedBy()))) &&
            ((this.rejectedOn==null && other.getRejectedOn()==null) || 
             (this.rejectedOn!=null &&
              this.rejectedOn.equals(other.getRejectedOn()))) &&
            ((this.voidedBy==null && other.getVoidedBy()==null) || 
             (this.voidedBy!=null &&
              this.voidedBy.equals(other.getVoidedBy()))) &&
            ((this.voidedOn==null && other.getVoidedOn()==null) || 
             (this.voidedOn!=null &&
              this.voidedOn.equals(other.getVoidedOn()))) &&
            ((this.bankDetailsAddedBy==null && other.getBankDetailsAddedBy()==null) || 
             (this.bankDetailsAddedBy!=null &&
              this.bankDetailsAddedBy.equals(other.getBankDetailsAddedBy()))) &&
            ((this.bankDetailsAddedOn==null && other.getBankDetailsAddedOn()==null) || 
             (this.bankDetailsAddedOn!=null &&
              this.bankDetailsAddedOn.equals(other.getBankDetailsAddedOn()))) &&
            ((this.sentToFinanceOn==null && other.getSentToFinanceOn()==null) || 
             (this.sentToFinanceOn!=null &&
              this.sentToFinanceOn.equals(other.getSentToFinanceOn()))) &&
            ((this.randiAgent==null && other.getRandiAgent()==null) || 
             (this.randiAgent!=null &&
              this.randiAgent.equals(other.getRandiAgent()))) &&
            ((this.failedAttempts==null && other.getFailedAttempts()==null) || 
             (this.failedAttempts!=null &&
              this.failedAttempts.equals(other.getFailedAttempts()))) &&
            ((this.randiCreationDate==null && other.getRandiCreationDate()==null) || 
             (this.randiCreationDate!=null &&
              this.randiCreationDate.equals(other.getRandiCreationDate()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.transactionId==null && other.getTransactionId()==null) || 
             (this.transactionId!=null &&
              this.transactionId.equals(other.getTransactionId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getResult() != null) {
            _hashCode += getResult().hashCode();
        }
        _hashCode += getRandiId();
        if (getRandiSubId() != null) {
            _hashCode += getRandiSubId().hashCode();
        }
        if (getComplainantName() != null) {
            _hashCode += getComplainantName().hashCode();
        }
        if (getComplainantEmail() != null) {
            _hashCode += getComplainantEmail().hashCode();
        }
        if (getClaimType() != null) {
            _hashCode += getClaimType().hashCode();
        }
        if (getCurrencyCode() != null) {
            _hashCode += getCurrencyCode().hashCode();
        }
        if (getInvoiceAmount() != null) {
            _hashCode += getInvoiceAmount().hashCode();
        }
        if (getCostCode() != null) {
            _hashCode += getCostCode().hashCode();
        }
        if (getAuthorisedBy() != null) {
            _hashCode += getAuthorisedBy().hashCode();
        }
        if (getAuthorizedOn() != null) {
            _hashCode += getAuthorizedOn().hashCode();
        }
        if (getRejectedBy() != null) {
            _hashCode += getRejectedBy().hashCode();
        }
        if (getRejectedOn() != null) {
            _hashCode += getRejectedOn().hashCode();
        }
        if (getVoidedBy() != null) {
            _hashCode += getVoidedBy().hashCode();
        }
        if (getVoidedOn() != null) {
            _hashCode += getVoidedOn().hashCode();
        }
        if (getBankDetailsAddedBy() != null) {
            _hashCode += getBankDetailsAddedBy().hashCode();
        }
        if (getBankDetailsAddedOn() != null) {
            _hashCode += getBankDetailsAddedOn().hashCode();
        }
        if (getSentToFinanceOn() != null) {
            _hashCode += getSentToFinanceOn().hashCode();
        }
        if (getRandiAgent() != null) {
            _hashCode += getRandiAgent().hashCode();
        }
        if (getFailedAttempts() != null) {
            _hashCode += getFailedAttempts().hashCode();
        }
        if (getRandiCreationDate() != null) {
            _hashCode += getRandiCreationDate().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getTransactionId() != null) {
            _hashCode += getTransactionId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RANDIResult.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RANDIResult"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("result");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "Result"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("randiId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RandiId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("randiSubId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RandiSubId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complainantName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ComplainantName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complainantEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ComplainantEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("claimType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ClaimType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currencyCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CurrencyCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("invoiceAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "InvoiceAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("costCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CostCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authorisedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "AuthorisedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authorizedOn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "AuthorizedOn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rejectedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RejectedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rejectedOn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RejectedOn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voidedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "VoidedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voidedOn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "VoidedOn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankDetailsAddedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "BankDetailsAddedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankDetailsAddedOn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "BankDetailsAddedOn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sentToFinanceOn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "SentToFinanceOn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("randiAgent");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RandiAgent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("failedAttempts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "FailedAttempts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("randiCreationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RandiCreationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "TransactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
