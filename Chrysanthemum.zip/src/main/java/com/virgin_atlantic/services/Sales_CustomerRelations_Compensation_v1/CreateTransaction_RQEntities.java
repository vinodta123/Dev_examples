/**
 * CreateTransaction_RQEntities.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1;

public class CreateTransaction_RQEntities  implements java.io.Serializable {
    private int randiId;

    private java.lang.String randiSubId;

    private java.lang.String complainantName;

    private java.lang.String complainantEmail;

    private java.lang.String claimType;

    private java.lang.String currencyCode;

    private java.math.BigDecimal invoiceAmount;

    private java.lang.String costCode;

    private java.lang.String authorisedBy;

    private java.lang.String rejectedBy;

    private java.lang.String status;

    private java.lang.String randiAgent;

    private java.lang.String randiCreationDate;

    private java.lang.String transactionGUID;

    public CreateTransaction_RQEntities() {
    }

    public CreateTransaction_RQEntities(
           int randiId,
           java.lang.String randiSubId,
           java.lang.String complainantName,
           java.lang.String complainantEmail,
           java.lang.String claimType,
           java.lang.String currencyCode,
           java.math.BigDecimal invoiceAmount,
           java.lang.String costCode,
           java.lang.String authorisedBy,
           java.lang.String rejectedBy,
           java.lang.String status,
           java.lang.String randiAgent,
           java.lang.String randiCreationDate,
           java.lang.String transactionGUID) {
           this.randiId = randiId;
           this.randiSubId = randiSubId;
           this.complainantName = complainantName;
           this.complainantEmail = complainantEmail;
           this.claimType = claimType;
           this.currencyCode = currencyCode;
           this.invoiceAmount = invoiceAmount;
           this.costCode = costCode;
           this.authorisedBy = authorisedBy;
           this.rejectedBy = rejectedBy;
           this.status = status;
           this.randiAgent = randiAgent;
           this.randiCreationDate = randiCreationDate;
           this.transactionGUID = transactionGUID;
    }


    /**
     * Gets the randiId value for this CreateTransaction_RQEntities.
     * 
     * @return randiId
     */
    public int getRandiId() {
        return randiId;
    }


    /**
     * Sets the randiId value for this CreateTransaction_RQEntities.
     * 
     * @param randiId
     */
    public void setRandiId(int randiId) {
        this.randiId = randiId;
    }


    /**
     * Gets the randiSubId value for this CreateTransaction_RQEntities.
     * 
     * @return randiSubId
     */
    public java.lang.String getRandiSubId() {
        return randiSubId;
    }


    /**
     * Sets the randiSubId value for this CreateTransaction_RQEntities.
     * 
     * @param randiSubId
     */
    public void setRandiSubId(java.lang.String randiSubId) {
        this.randiSubId = randiSubId;
    }


    /**
     * Gets the complainantName value for this CreateTransaction_RQEntities.
     * 
     * @return complainantName
     */
    public java.lang.String getComplainantName() {
        return complainantName;
    }


    /**
     * Sets the complainantName value for this CreateTransaction_RQEntities.
     * 
     * @param complainantName
     */
    public void setComplainantName(java.lang.String complainantName) {
        this.complainantName = complainantName;
    }


    /**
     * Gets the complainantEmail value for this CreateTransaction_RQEntities.
     * 
     * @return complainantEmail
     */
    public java.lang.String getComplainantEmail() {
        return complainantEmail;
    }


    /**
     * Sets the complainantEmail value for this CreateTransaction_RQEntities.
     * 
     * @param complainantEmail
     */
    public void setComplainantEmail(java.lang.String complainantEmail) {
        this.complainantEmail = complainantEmail;
    }


    /**
     * Gets the claimType value for this CreateTransaction_RQEntities.
     * 
     * @return claimType
     */
    public java.lang.String getClaimType() {
        return claimType;
    }


    /**
     * Sets the claimType value for this CreateTransaction_RQEntities.
     * 
     * @param claimType
     */
    public void setClaimType(java.lang.String claimType) {
        this.claimType = claimType;
    }


    /**
     * Gets the currencyCode value for this CreateTransaction_RQEntities.
     * 
     * @return currencyCode
     */
    public java.lang.String getCurrencyCode() {
        return currencyCode;
    }


    /**
     * Sets the currencyCode value for this CreateTransaction_RQEntities.
     * 
     * @param currencyCode
     */
    public void setCurrencyCode(java.lang.String currencyCode) {
        this.currencyCode = currencyCode;
    }


    /**
     * Gets the invoiceAmount value for this CreateTransaction_RQEntities.
     * 
     * @return invoiceAmount
     */
    public java.math.BigDecimal getInvoiceAmount() {
        return invoiceAmount;
    }


    /**
     * Sets the invoiceAmount value for this CreateTransaction_RQEntities.
     * 
     * @param invoiceAmount
     */
    public void setInvoiceAmount(java.math.BigDecimal invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }


    /**
     * Gets the costCode value for this CreateTransaction_RQEntities.
     * 
     * @return costCode
     */
    public java.lang.String getCostCode() {
        return costCode;
    }


    /**
     * Sets the costCode value for this CreateTransaction_RQEntities.
     * 
     * @param costCode
     */
    public void setCostCode(java.lang.String costCode) {
        this.costCode = costCode;
    }


    /**
     * Gets the authorisedBy value for this CreateTransaction_RQEntities.
     * 
     * @return authorisedBy
     */
    public java.lang.String getAuthorisedBy() {
        return authorisedBy;
    }


    /**
     * Sets the authorisedBy value for this CreateTransaction_RQEntities.
     * 
     * @param authorisedBy
     */
    public void setAuthorisedBy(java.lang.String authorisedBy) {
        this.authorisedBy = authorisedBy;
    }


    /**
     * Gets the rejectedBy value for this CreateTransaction_RQEntities.
     * 
     * @return rejectedBy
     */
    public java.lang.String getRejectedBy() {
        return rejectedBy;
    }


    /**
     * Sets the rejectedBy value for this CreateTransaction_RQEntities.
     * 
     * @param rejectedBy
     */
    public void setRejectedBy(java.lang.String rejectedBy) {
        this.rejectedBy = rejectedBy;
    }


    /**
     * Gets the status value for this CreateTransaction_RQEntities.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this CreateTransaction_RQEntities.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the randiAgent value for this CreateTransaction_RQEntities.
     * 
     * @return randiAgent
     */
    public java.lang.String getRandiAgent() {
        return randiAgent;
    }


    /**
     * Sets the randiAgent value for this CreateTransaction_RQEntities.
     * 
     * @param randiAgent
     */
    public void setRandiAgent(java.lang.String randiAgent) {
        this.randiAgent = randiAgent;
    }


    /**
     * Gets the randiCreationDate value for this CreateTransaction_RQEntities.
     * 
     * @return randiCreationDate
     */
    public java.lang.String getRandiCreationDate() {
        return randiCreationDate;
    }


    /**
     * Sets the randiCreationDate value for this CreateTransaction_RQEntities.
     * 
     * @param randiCreationDate
     */
    public void setRandiCreationDate(java.lang.String randiCreationDate) {
        this.randiCreationDate = randiCreationDate;
    }


    /**
     * Gets the transactionGUID value for this CreateTransaction_RQEntities.
     * 
     * @return transactionGUID
     */
    public java.lang.String getTransactionGUID() {
        return transactionGUID;
    }


    /**
     * Sets the transactionGUID value for this CreateTransaction_RQEntities.
     * 
     * @param transactionGUID
     */
    public void setTransactionGUID(java.lang.String transactionGUID) {
        this.transactionGUID = transactionGUID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CreateTransaction_RQEntities)) return false;
        CreateTransaction_RQEntities other = (CreateTransaction_RQEntities) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.randiId == other.getRandiId() &&
            ((this.randiSubId==null && other.getRandiSubId()==null) || 
             (this.randiSubId!=null &&
              this.randiSubId.equals(other.getRandiSubId()))) &&
            ((this.complainantName==null && other.getComplainantName()==null) || 
             (this.complainantName!=null &&
              this.complainantName.equals(other.getComplainantName()))) &&
            ((this.complainantEmail==null && other.getComplainantEmail()==null) || 
             (this.complainantEmail!=null &&
              this.complainantEmail.equals(other.getComplainantEmail()))) &&
            ((this.claimType==null && other.getClaimType()==null) || 
             (this.claimType!=null &&
              this.claimType.equals(other.getClaimType()))) &&
            ((this.currencyCode==null && other.getCurrencyCode()==null) || 
             (this.currencyCode!=null &&
              this.currencyCode.equals(other.getCurrencyCode()))) &&
            ((this.invoiceAmount==null && other.getInvoiceAmount()==null) || 
             (this.invoiceAmount!=null &&
              this.invoiceAmount.equals(other.getInvoiceAmount()))) &&
            ((this.costCode==null && other.getCostCode()==null) || 
             (this.costCode!=null &&
              this.costCode.equals(other.getCostCode()))) &&
            ((this.authorisedBy==null && other.getAuthorisedBy()==null) || 
             (this.authorisedBy!=null &&
              this.authorisedBy.equals(other.getAuthorisedBy()))) &&
            ((this.rejectedBy==null && other.getRejectedBy()==null) || 
             (this.rejectedBy!=null &&
              this.rejectedBy.equals(other.getRejectedBy()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.randiAgent==null && other.getRandiAgent()==null) || 
             (this.randiAgent!=null &&
              this.randiAgent.equals(other.getRandiAgent()))) &&
            ((this.randiCreationDate==null && other.getRandiCreationDate()==null) || 
             (this.randiCreationDate!=null &&
              this.randiCreationDate.equals(other.getRandiCreationDate()))) &&
            ((this.transactionGUID==null && other.getTransactionGUID()==null) || 
             (this.transactionGUID!=null &&
              this.transactionGUID.equals(other.getTransactionGUID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getRandiId();
        if (getRandiSubId() != null) {
            _hashCode += getRandiSubId().hashCode();
        }
        if (getComplainantName() != null) {
            _hashCode += getComplainantName().hashCode();
        }
        if (getComplainantEmail() != null) {
            _hashCode += getComplainantEmail().hashCode();
        }
        if (getClaimType() != null) {
            _hashCode += getClaimType().hashCode();
        }
        if (getCurrencyCode() != null) {
            _hashCode += getCurrencyCode().hashCode();
        }
        if (getInvoiceAmount() != null) {
            _hashCode += getInvoiceAmount().hashCode();
        }
        if (getCostCode() != null) {
            _hashCode += getCostCode().hashCode();
        }
        if (getAuthorisedBy() != null) {
            _hashCode += getAuthorisedBy().hashCode();
        }
        if (getRejectedBy() != null) {
            _hashCode += getRejectedBy().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getRandiAgent() != null) {
            _hashCode += getRandiAgent().hashCode();
        }
        if (getRandiCreationDate() != null) {
            _hashCode += getRandiCreationDate().hashCode();
        }
        if (getTransactionGUID() != null) {
            _hashCode += getTransactionGUID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CreateTransaction_RQEntities.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CreateTransaction_RQEntities"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("randiId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RandiId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("randiSubId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RandiSubId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complainantName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ComplainantName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complainantEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ComplainantEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("claimType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ClaimType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currencyCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CurrencyCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("invoiceAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "InvoiceAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("costCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CostCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authorisedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "AuthorisedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rejectedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RejectedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("randiAgent");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RandiAgent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("randiCreationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RandiCreationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionGUID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "TransactionGUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
