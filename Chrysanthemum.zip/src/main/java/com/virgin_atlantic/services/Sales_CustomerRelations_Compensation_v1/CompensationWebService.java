/**
 * CompensationWebService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1;

public interface CompensationWebService extends javax.xml.rpc.Service {
    public java.lang.String getBasicHttpBinding_ICompensationWebServiceAddress();

    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ICompensationWebService getBasicHttpBinding_ICompensationWebService() throws javax.xml.rpc.ServiceException;

    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ICompensationWebService getBasicHttpBinding_ICompensationWebService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
