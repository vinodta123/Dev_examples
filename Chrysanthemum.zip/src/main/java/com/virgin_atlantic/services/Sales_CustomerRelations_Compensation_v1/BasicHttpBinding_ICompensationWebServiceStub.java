/**
 * BasicHttpBinding_ICompensationWebServiceStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1;

public class BasicHttpBinding_ICompensationWebServiceStub extends org.apache.axis.client.Stub implements com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ICompensationWebService {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[8];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateTransaction");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CreateTransaction_RQ"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CreateTransaction_RQEntities"), com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RQEntities.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CreateTransaction_RS"));
        oper.setReturnClass(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RS.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CreateTransaction_RS"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ReceiveGUIDInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RecieveGUIDInfo_RQ"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RecieveGUIDInfo_RQEntities"), com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RQEntities.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RecieveGUIDInfo_RS"));
        oper.setReturnClass(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RS.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RecieveGUIDInfo_RS"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ValidateGUID");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateGUID_RQ"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateGUID_RQEntities"), com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RQEntities.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateGUID_RS"));
        oper.setReturnClass(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RS.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateGUID_RS"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("AddBankDetails");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "AddBankDetails_RQ"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "AddBankDetails_RQEntities"), com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RQEntities.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "AddBankDetails_RS"));
        oper.setReturnClass(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RS.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "AddBankDetails_RS"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ValidateRANDIID");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateRANDIID_RQ"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateRANDIID_RQEntities"), com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RQEntities.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateRANDIID_RS"));
        oper.setReturnClass(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RS.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateRANDIID_RS"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetFilteredLines");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "GetFilteredLines_RQ"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "GetFilteredLines_RQEntities"), com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RQEntities.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "GetFilteredLines_RS"));
        oper.setReturnClass(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RS.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "GetFilteredLines_RS"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UpdateTransaction");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "UpdateTransaction_RQ"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "UpdateTransaction_RQEntities"), com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RQEntities.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "UpdateTransaction_RS"));
        oper.setReturnClass(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RS.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "UpdateTransaction_RS"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SendEmail");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "SendEmail_RQ"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "SendEmail_RQEntities"), com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RQEntities.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "SendEmail_RS"));
        oper.setReturnClass(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RS.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "SendEmail_RS"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

    }

    public BasicHttpBinding_ICompensationWebServiceStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public BasicHttpBinding_ICompensationWebServiceStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public BasicHttpBinding_ICompensationWebServiceStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "AddBankDetails_RQEntities");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RQEntities.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "AddBankDetails_RS");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RS.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "Addressee");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.Addressee.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ArrayOfFilteredLine");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.FilteredLine[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "FilteredLine");
            qName2 = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "FilteredLine");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ArrayOfRANDIResult");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RANDIResult[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RANDIResult");
            qName2 = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RANDIResult");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CcAddress");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CcAddress.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CreateTransaction_RQEntities");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RQEntities.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CreateTransaction_RS");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RS.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "FilteredLine");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.FilteredLine.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "GetFilteredLines_RQEntities");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RQEntities.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "GetFilteredLines_RS");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RS.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "MessageData");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.MessageData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ProcessingMetadata");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ProcessingMetadata.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RANDIResult");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RANDIResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RecieveGUIDInfo_RQEntities");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RQEntities.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RecieveGUIDInfo_RS");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RS.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "Result");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.Result.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "SendEmail_RQEntities");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RQEntities.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "SendEmail_RS");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RS.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "UpdateTransaction_RQEntities");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RQEntities.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "UpdateTransaction_RS");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RS.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateGUID_RQEntities");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RQEntities.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateGUID_RS");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RS.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateRANDIID_RQEntities");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RQEntities.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateRANDIID_RS");
            cachedSerQNames.add(qName);
            cls = com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RS.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RS createTransaction(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RQEntities createTransaction_RQ) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1/ICompensationWebService/CreateTransaction");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "CreateTransaction"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {createTransaction_RQ});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RS) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RS) org.apache.axis.utils.JavaUtils.convert(_resp, com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RS.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RS receiveGUIDInfo(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RQEntities recieveGUIDInfo_RQ) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1/ICompensationWebService/ReceiveGUIDInfo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "RecieveGUIDInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {recieveGUIDInfo_RQ});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RS) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RS) org.apache.axis.utils.JavaUtils.convert(_resp, com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RS.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RS validateGUID(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RQEntities validateGUID_RQ) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1/ICompensationWebService/ValidateGUID");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateGUID"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {validateGUID_RQ});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RS) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RS) org.apache.axis.utils.JavaUtils.convert(_resp, com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RS.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RS addBankDetails(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RQEntities addBankDetails_RQ) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1/ICompensationWebService/AddBankDetails");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "AddBankDetails"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {addBankDetails_RQ});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RS) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RS) org.apache.axis.utils.JavaUtils.convert(_resp, com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RS.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RS validateRANDIID(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RQEntities validateRANDIID_RQ) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1/ICompensationWebService/ValidateRANDIID");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ValidateRANDIID"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {validateRANDIID_RQ});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RS) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RS) org.apache.axis.utils.JavaUtils.convert(_resp, com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RS.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RS getFilteredLines(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RQEntities getFilteredLines_RQ) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1/ICompensationWebService/GetFilteredLines");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "GetFilteredLines"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {getFilteredLines_RQ});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RS) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RS) org.apache.axis.utils.JavaUtils.convert(_resp, com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RS.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RS updateTransaction(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RQEntities updateTransaction_RQ) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1/ICompensationWebService/UpdateTransaction");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "UpdateTransaction"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {updateTransaction_RQ});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RS) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RS) org.apache.axis.utils.JavaUtils.convert(_resp, com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RS.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RS sendEmail(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RQEntities sendEmail_RQ) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1/ICompensationWebService/SendEmail");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "SendEmail"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sendEmail_RQ});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RS) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RS) org.apache.axis.utils.JavaUtils.convert(_resp, com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RS.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
