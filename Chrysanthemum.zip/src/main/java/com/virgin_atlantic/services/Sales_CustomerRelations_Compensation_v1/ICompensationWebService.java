/**
 * ICompensationWebService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1;

public interface ICompensationWebService extends java.rmi.Remote {
    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RS createTransaction(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.CreateTransaction_RQEntities createTransaction_RQ) throws java.rmi.RemoteException;
    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RS receiveGUIDInfo(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RQEntities recieveGUIDInfo_RQ) throws java.rmi.RemoteException;
    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RS validateGUID(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RQEntities validateGUID_RQ) throws java.rmi.RemoteException;
    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RS addBankDetails(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RQEntities addBankDetails_RQ) throws java.rmi.RemoteException;
    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RS validateRANDIID(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateRANDIID_RQEntities validateRANDIID_RQ) throws java.rmi.RemoteException;
    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RS getFilteredLines(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.GetFilteredLines_RQEntities getFilteredLines_RQ) throws java.rmi.RemoteException;
    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RS updateTransaction(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.UpdateTransaction_RQEntities updateTransaction_RQ) throws java.rmi.RemoteException;
    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RS sendEmail(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.SendEmail_RQEntities sendEmail_RQ) throws java.rmi.RemoteException;
}
