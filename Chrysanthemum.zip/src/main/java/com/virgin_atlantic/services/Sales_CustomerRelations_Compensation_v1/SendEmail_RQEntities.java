/**
 * SendEmail_RQEntities.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1;

public class SendEmail_RQEntities  implements java.io.Serializable {
    private com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ProcessingMetadata processingMetaData;

    private com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.Addressee addressee;

    private com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.MessageData messageData;

    public SendEmail_RQEntities() {
    }

    public SendEmail_RQEntities(
           com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ProcessingMetadata processingMetaData,
           com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.Addressee addressee,
           com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.MessageData messageData) {
           this.processingMetaData = processingMetaData;
           this.addressee = addressee;
           this.messageData = messageData;
    }


    /**
     * Gets the processingMetaData value for this SendEmail_RQEntities.
     * 
     * @return processingMetaData
     */
    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ProcessingMetadata getProcessingMetaData() {
        return processingMetaData;
    }


    /**
     * Sets the processingMetaData value for this SendEmail_RQEntities.
     * 
     * @param processingMetaData
     */
    public void setProcessingMetaData(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ProcessingMetadata processingMetaData) {
        this.processingMetaData = processingMetaData;
    }


    /**
     * Gets the addressee value for this SendEmail_RQEntities.
     * 
     * @return addressee
     */
    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.Addressee getAddressee() {
        return addressee;
    }


    /**
     * Sets the addressee value for this SendEmail_RQEntities.
     * 
     * @param addressee
     */
    public void setAddressee(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.Addressee addressee) {
        this.addressee = addressee;
    }


    /**
     * Gets the messageData value for this SendEmail_RQEntities.
     * 
     * @return messageData
     */
    public com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.MessageData getMessageData() {
        return messageData;
    }


    /**
     * Sets the messageData value for this SendEmail_RQEntities.
     * 
     * @param messageData
     */
    public void setMessageData(com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.MessageData messageData) {
        this.messageData = messageData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SendEmail_RQEntities)) return false;
        SendEmail_RQEntities other = (SendEmail_RQEntities) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.processingMetaData==null && other.getProcessingMetaData()==null) || 
             (this.processingMetaData!=null &&
              this.processingMetaData.equals(other.getProcessingMetaData()))) &&
            ((this.addressee==null && other.getAddressee()==null) || 
             (this.addressee!=null &&
              this.addressee.equals(other.getAddressee()))) &&
            ((this.messageData==null && other.getMessageData()==null) || 
             (this.messageData!=null &&
              this.messageData.equals(other.getMessageData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProcessingMetaData() != null) {
            _hashCode += getProcessingMetaData().hashCode();
        }
        if (getAddressee() != null) {
            _hashCode += getAddressee().hashCode();
        }
        if (getMessageData() != null) {
            _hashCode += getMessageData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SendEmail_RQEntities.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "SendEmail_RQEntities"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processingMetaData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "processingMetaData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "ProcessingMetadata"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addressee");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "Addressee"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "Addressee"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "MessageData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1", "MessageData"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
