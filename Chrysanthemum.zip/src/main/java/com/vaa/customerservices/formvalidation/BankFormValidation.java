package com.vaa.customerservices.formvalidation;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.log4j.Logger;

import com.vaa.customerservices.model.AddBankDetailsModel;
import com.vaa.customerservices.model.GuidInfoModel;
import com.vaa.customerservices.util.CustomerServicesException;

public class BankFormValidation {
static final Logger log = Logger.getLogger(BankFormValidation.class);	
	
	@Resource(name="applicationProperty")
	private Properties applicationProperty;
		

		/**
		 * @param queryString
		 * @throws CustomerServicesException
		 */
		public boolean validateURL(String queryString) throws CustomerServicesException {
			log.info("entring into validateURL method");
			String [] splitQuery;
			boolean nullCheck=true;
			try {
				splitQuery=queryString.split("=");
				if(splitQuery[0]==null ||splitQuery[0].equals("")||splitQuery[1]==null||splitQuery[1].equals("")){	
					nullCheck=false;
				}
			}catch(Exception er){
				log.error("BankFormValidation -- > validate Query String " + er);
				throw new CustomerServicesException(er);
				
			}	
			return nullCheck;
		}
		
		/**
		 * @param addbankdetails
		 * @return List errorMessage
		 * @throws CustomerServicesException
		 */
		public List<String> validateAddBankDetails(AddBankDetailsModel addbankdetails) throws CustomerServicesException {
		log.info("entring into validateAddBankDetails  method");
		List<String> errorMessage=new ArrayList<String>();
		String currency=null;
		
		try {
				currency=addbankdetails.getCurrency();	
				
				if(!addbankdetails.getBankName().matches("[A-Za-z\\s]+")||addbankdetails.getBankName().length()>50 || addbankdetails.getBankName().isEmpty() || addbankdetails.getBankName()==null){
					errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.bankname"));						
				}
				if(!addbankdetails.getPayeeName().matches("[A-Za-z\\s]+")||addbankdetails.getPayeeName().length()>50 || addbankdetails.getPayeeName().isEmpty() || addbankdetails.getPayeeName()==null) {
					errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.payeename"));
				}
				if(!addbankdetails.getReferenceNumber().matches("[0-9]+")||addbankdetails.getReferenceNumber().length()<7 ||addbankdetails.getReferenceNumber().length()>9 || addbankdetails.getReferenceNumber()==null || addbankdetails.getReferenceNumber().isEmpty()) {
					errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.referencenumber"));
				}
				if(currency.equalsIgnoreCase("GBP")){					
					if(!addbankdetails.getAccountNumber().matches("[0-9]+")||addbankdetails.getAccountNumber().length()!=8||addbankdetails.getAccountNumber()==null||addbankdetails.getAccountNumber().isEmpty()){
						errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.accountnumber"));
					}
					if(!addbankdetails.getBankCode().matches("[0-9]+")||addbankdetails.getBankCode().length()!=6||addbankdetails.getBankCode()==null||addbankdetails.getBankCode().isEmpty()){
						errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.bankcode"));
					}					
				}
				if(currency.equalsIgnoreCase("USD")){						
					if(!addbankdetails.getAccountNumber().matches("[0-9]+")||addbankdetails.getAccountNumber()==null||addbankdetails.getAccountNumber().isEmpty()||addbankdetails.getAccountNumber().length()<4){
						errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.accountnumber"));
					}
					if(addbankdetails.getBankCode().length()<9||!addbankdetails.getBankCode().matches("[A-Za-z0-9]+")||addbankdetails.getBankCode()==null||addbankdetails.getBankCode().isEmpty()){
						errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.bankcode"));
					}					
				}
				
				if(currency.equalsIgnoreCase("EUR")){	
				
					if(addbankdetails.getCountryCode().equalsIgnoreCase("euro")){
						
						if(!addbankdetails.getIbanNumber().matches("[A-Za-z0-9]+")||(addbankdetails.getIbanNumber().length()<16 || addbankdetails.getIbanNumber().length()>31)||addbankdetails.getIbanNumber()==null||addbankdetails.getIbanNumber().isEmpty()){
							errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.ibannumber"));
						}
						if((addbankdetails.getSwiftCode().length()<8 || addbankdetails.getSwiftCode().length()>11)||!addbankdetails.getSwiftCode().matches("[A-Za-z0-9]+")||addbankdetails.getSwiftCode()==null||addbankdetails.getSwiftCode().isEmpty()){
							errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.swiftnumber"));
						}
					}
					if(addbankdetails.getCountryCode().equalsIgnoreCase("noneuro") || addbankdetails.getCountryCode().equalsIgnoreCase("zchina")){
						
						if(addbankdetails.getAccountNumber().length()<4||!addbankdetails.getAccountNumber().matches("[0-9]+")||addbankdetails.getAccountNumber()==null||addbankdetails.getAccountNumber().isEmpty()){
							errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.accountnumber"));
						}
						if((addbankdetails.getSwiftCode().length()<8 || addbankdetails.getSwiftCode().length()>11)||!addbankdetails.getSwiftCode().matches("[A-Za-z0-9]+")||addbankdetails.getSwiftCode()==null||addbankdetails.getSwiftCode().isEmpty()){
							errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.swiftnumber"));
						}						
					}
					
				}				
				if(!currency.equalsIgnoreCase("EUR")&&!currency.equalsIgnoreCase("USD")&&!currency.equalsIgnoreCase("GBP")){
					
					if(addbankdetails.getOthersPayMethod().equalsIgnoreCase("iban")){
						if(!addbankdetails.getIbanNumber().matches("[A-Za-z0-9]+")||(addbankdetails.getIbanNumber().length()<16 || addbankdetails.getIbanNumber().length()>31)||addbankdetails.getIbanNumber()==null||addbankdetails.getIbanNumber().isEmpty()){
							errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.ibannumber"));
						}
						if(currency.equalsIgnoreCase("INR")){							
							if((addbankdetails.getIbanswiftCode().length()<8 || addbankdetails.getIbanswiftCode().length()>11)||(!addbankdetails.getIbanswiftCode().matches("[A-Za-z]{4}+")&&!addbankdetails.getIbanswiftCode().matches("[A-Za-z0-9]+"))||addbankdetails.getIbanswiftCode()==null||addbankdetails.getIbanswiftCode().isEmpty()){
								errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.swiftnumber"));
							}
						}else{
							if((addbankdetails.getIbanswiftCode().length()<8 || addbankdetails.getIbanswiftCode().length()>11)||!addbankdetails.getIbanswiftCode().matches("[A-Za-z0-9]+")||addbankdetails.getIbanswiftCode()==null||addbankdetails.getIbanswiftCode().isEmpty()){
								errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.swiftnumber"));
							}
							
						}												
					}
					if(addbankdetails.getOthersPayMethod().equalsIgnoreCase("bankacc")){
						
												
						if(addbankdetails.getAccountNumber().length()<4||!addbankdetails.getAccountNumber().matches("[0-9]+")||addbankdetails.getAccountNumber()==null||addbankdetails.getAccountNumber().isEmpty()){
							errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.accountnumber"));
						}
						
						if(addbankdetails.getSwiftCode()!=null && !addbankdetails.getSwiftCode().isEmpty()){
							if(currency.equalsIgnoreCase("INR")){										
								if((addbankdetails.getSwiftCode().length()<8 || addbankdetails.getSwiftCode().length()>11)||(!addbankdetails.getSwiftCode().matches("[A-Za-z]{4}+")&&!addbankdetails.getSwiftCode().matches("[A-Za-z0-9]+"))||addbankdetails.getSwiftCode()==null||addbankdetails.getSwiftCode().isEmpty()){
											errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.swiftnumber"));
									}
							}else{
									if((addbankdetails.getSwiftCode().length()<8 || addbankdetails.getSwiftCode().length()>11)||!addbankdetails.getSwiftCode().matches("[A-Za-z0-9]+")||addbankdetails.getSwiftCode()==null||addbankdetails.getSwiftCode().isEmpty()){
												errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.swiftnumber"));
									}						
							}
							
						}else{
							if((addbankdetails.getBankCode().length()<4||!addbankdetails.getBankCode().matches("[0-9]+")||addbankdetails.getBankCode()==null||addbankdetails.getBankCode().isEmpty())){
								errorMessage.add(applicationProperty.getProperty("errorMessage.invalid.bankcode.swiftcode"));	}
							}
							
						}
						
						
				}		
				log.info("BankFormValidation :: validateAddBankDetails method :: Error Message --> " + errorMessage);					
		}catch(Exception er){
			log.error("BankFormValidation :: validateAddBankDetails method :: validation fields :: " + "  Currency :"+addbankdetails.getCurrency()+"  Payment By :"+addbankdetails.getOthersPayMethod()+" Region  :"+addbankdetails.getCountryCode());
			log.error("BankFormValidation :: validateAddBankDetails method :: validate add bank details " + er);
			throw new CustomerServicesException(er);			
		}
		return errorMessage;
		}
		
		/**
		 * @param guidInfoModel
		 * @return errorMessage List
		 * @throws CustomerServicesException
		 */
		public List<String> validateFormDetails(GuidInfoModel guidInfoModel) throws CustomerServicesException {
			log.info("entring into  validateFormDetails  method");
			List<String> errorMessage=new ArrayList<String>();			
			AddBankDetailsModel addbankdetails=new AddBankDetailsModel();	
			String reagion=null;			
			String [] tmp=null;
			try {				

				addbankdetails.setPayeeName(guidInfoModel.getPayeeName());				
				addbankdetails.setBankName(guidInfoModel.getBankName());				
				addbankdetails.setCurrency(guidInfoModel.getCurrency());				
				addbankdetails.setReferenceNumber(guidInfoModel.getReferenceNumber());				
				addbankdetails.setAccountNumber(guidInfoModel.getAccountNumber());				
				addbankdetails.setBankCode(guidInfoModel.getBankCode());				
				if(!guidInfoModel.getCurrency().equalsIgnoreCase("GBP")&&!guidInfoModel.getCurrency().equalsIgnoreCase("USD")){
					tmp=guidInfoModel.getCountry().toString().split("_");
					reagion=tmp[0];
					addbankdetails.setCountryCode(reagion);
					addbankdetails.setIbanNumber(guidInfoModel.getIbanNumber());
					addbankdetails.setSwiftCode(guidInfoModel.getSwiftCode());
					addbankdetails.setIbanswiftCode(guidInfoModel.getIbanswiftCode());
					addbankdetails.setOthersPayMethod(guidInfoModel.getOthersPayMethod());	
				}
				errorMessage=validateAddBankDetails(addbankdetails);
				
			}catch(Exception er){
				log.error("BankFormValidation :: validateFormDetails method :: validate valdiateGUID call details " + er);
				throw new CustomerServicesException(er);
				
			}
			return errorMessage;	
		}

}
