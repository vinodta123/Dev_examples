package com.vaa.customerservices.service;

import java.util.Map;

import javax.xml.rpc.ServiceException;

import com.vaa.customerservices.model.AddBankDetailsModel;
import com.vaa.customerservices.model.GuidInfoModel;
import com.vaa.customerservices.model.ValidateGuIdModel;
import com.vaa.customerservices.util.CustomerServicesException;


public interface BankDetailsService {
	
	/**
	 * 
	 * @param guId
	 * @return
	 * @throws ServiceException
	 */
	public GuidInfoModel receiveGuidInfo(String guId)throws CustomerServicesException;
	
	/***
	 * 
	 * @param formdetails
	 * @return ValidateGuIdModel
	 */
	public ValidateGuIdModel validateGUID(ValidateGuIdModel validateGuidRQ) throws CustomerServicesException;
	
	/***
	 * 
	 * @param bankdetails
	 * @return boolean
	 */
	public AddBankDetailsModel addBankDetails(AddBankDetailsModel bankdetails) throws CustomerServicesException;
	
	/***
	 * 
	 * @param getCountryList
	 * @return Map<String,String>
	 */
	public Map<String,String> getCountryList(String currencyType)throws CustomerServicesException;
	
}
