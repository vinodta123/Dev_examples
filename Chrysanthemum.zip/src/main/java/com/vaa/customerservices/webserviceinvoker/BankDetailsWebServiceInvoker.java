package com.vaa.customerservices.webserviceinvoker;

import java.net.URL;
import java.util.Properties;

import javax.annotation.Resource;
import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

import com.vaa.customerservices.model.AddBankDetailsModel;
import com.vaa.customerservices.model.GuidInfoModel;
import com.vaa.customerservices.model.ValidateGuIdModel;
import com.vaa.customerservices.util.CustomerServicesException;
import com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RQEntities;
import com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.AddBankDetails_RS;
import com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.BasicHttpBinding_ICompensationWebServiceStub;
import com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RQEntities;
import com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.RecieveGUIDInfo_RS;
import com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.Result;
import com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RQEntities;
import com.virgin_atlantic.services.Sales_CustomerRelations_Compensation_v1.ValidateGUID_RS;


public class BankDetailsWebServiceInvoker extends BaseWebServiceInvoker {
	

	private static final Logger log = Logger.getLogger(BankDetailsWebServiceInvoker.class);
	public static final String VAA_BANK_DETAILS_ADDBY="CUSTOMER";
	
	@Resource(name="applicationProperty")
	private Properties applicationProperty;

	
	public static int connectionTimeout;
	
	/**
	 * @method getStubCreation
	 * @return BasicHttpBinding_ICompensationWebServiceStub
	 * @throws Exception
	 */
	private BasicHttpBinding_ICompensationWebServiceStub getStubCreation()
			throws Exception {
		log.info("entering into getStubCreation method");
		BasicHttpBinding_ICompensationWebServiceStub callingStub=null;
		String webServiceURL=applicationProperty.getProperty("webService.url");
		String guid=applicationProperty.getProperty("webService.header.applicationId");
		String applicatioName=applicationProperty.getProperty("webService.header.applicationName");
		URL urlport = new URL(webServiceURL);
		org.apache.axis.client.Service axisservice =new org.apache.axis.client.Service();
		callingStub= new BasicHttpBinding_ICompensationWebServiceStub(urlport,axisservice);
		callingStub.clearHeaders();
		callingStub.setHeader(getSOAPHeader(guid, applicatioName));
		if(applicationProperty.getProperty("webService.connectionTimeout")!=null){
			connectionTimeout = Integer.parseInt(applicationProperty.getProperty("webService.connectionTimeout"));
			callingStub.setTimeout(connectionTimeout);
		}
		return callingStub;
	}
	
	/**
	 * @method receiveGuidInfo
	 * @param guId
	 * @return GuidInfoModel
	 * @throws ServiceException	 */
	public GuidInfoModel receiveGuidInfo(String guId)
			throws CustomerServicesException {
		log.info("entering into receiveGuidInfo method");
		RecieveGUIDInfo_RS receiveGUIDRS=new RecieveGUIDInfo_RS();
		GuidInfoModel GuidInfoModel_RS = new GuidInfoModel();
		BasicHttpBinding_ICompensationWebServiceStub callingStub=null;
		
		Result serviceResult=null;
		String errorMessage=null;
		try {
			callingStub=getStubCreation();
			receiveGUIDRS=callingStub.receiveGUIDInfo(new RecieveGUIDInfo_RQEntities(guId));
			serviceResult=receiveGUIDRS.getResult();
			if (serviceResult.getResultCode()!=null && serviceResult.getResultCode().equals("0")) {
				GuidInfoModel_RS.setName(receiveGUIDRS.getName());				
				GuidInfoModel_RS.setCurrency(receiveGUIDRS.getCurrency());			
				GuidInfoModel_RS.setInvoiceAmount(receiveGUIDRS.getInvoiceAmount());
				
			} else {				
				log.info("BankDetailsWebServiceInvoker : Error in receiveGuidIno call ::  Webservice URL ::"+applicationProperty.getProperty("webService.url")+" Request Details::" +guId);
				log.info("BankDetailsWebServiceInvoker : Error in receiveGuidIno call :: Response Details " +"name "+GuidInfoModel_RS.getName()+" Currency "+GuidInfoModel_RS.getCurrency()+"Amount "+receiveGUIDRS.getInvoiceAmount());
				errorMessage="Result Code: "+ serviceResult.getResultCode()+" Error Code: "+serviceResult.getErrorCode()+" Error Type: "+serviceResult.getErrorType()+" Error Description : "+serviceResult.getTechnicalDescription();
				throw new CustomerServicesException(errorMessage);
			}
		
		}catch (Exception e) {
			log.error("BankDetailsWebServiceInvoker : Error in receiveGuidIno call ::  Webservice URL ::"+applicationProperty.getProperty("webService.url")+" Request Details::" +guId);
			log.error("BankDetailsWebServiceInvoker : Exception in ReceiveGuid :: Response Details " +"name "+GuidInfoModel_RS.getName()+" Currency "+GuidInfoModel_RS.getCurrency()+"Amount "+receiveGUIDRS.getInvoiceAmount());
			log.error("BankDetailsWebServiceInvoker :: Exception in ReceiveGuid Information"+e);
			throw new CustomerServicesException(e);

		}
		return GuidInfoModel_RS;

	}

	/**
	 * @method validateGUID
	 * @param validatGUIDRQ
	 * @return boolean
	 * @throws CustomerServicesException
	 */
	public ValidateGuIdModel validateGUID(ValidateGuIdModel validatGUIDRQ)
			throws CustomerServicesException {
		log.info("entering into validateGUID method");
		boolean isValid=false;
		ValidateGUID_RQEntities validateGUIDRQ = new ValidateGUID_RQEntities();
		ValidateGUID_RS validateGUIDRS=new ValidateGUID_RS();
		BasicHttpBinding_ICompensationWebServiceStub callingStub=null;
		Result serviceResult=null;
		String errorMessage=null;		
		ValidateGuIdModel validateGUISRS = new ValidateGuIdModel();
		try {
			callingStub=getStubCreation();			
			if((validatGUIDRQ.getGuid()!=null && !validatGUIDRQ.getGuid().isEmpty()) &&( validatGUIDRQ.getReferenceNumber()!=null && !validatGUIDRQ.getReferenceNumber().isEmpty() && validatGUIDRQ.getReferenceNumber().matches("[0-9]+") )){
				validateGUIDRQ.setRandiId(validatGUIDRQ.getReferenceNumber());
				validateGUIDRQ.setTransactionId(validatGUIDRQ.getGuid());				
				validateGUIDRS = callingStub.validateGUID(validateGUIDRQ);
				serviceResult=validateGUIDRS.getResult();
				isValid = validateGUIDRS.isIsValid();				
					if (serviceResult.getResultCode()!=null && serviceResult.getResultCode().equals("0") && isValid) {
						validateGUISRS.setValid(isValid);
						validateGUISRS.setErrorCode(serviceResult.getResultCode());	
					}else if (serviceResult.getErrorCode().equals("1005") && !isValid){
						validateGUISRS.setValid(isValid);
						validateGUISRS.setErrorCode(serviceResult.getErrorCode());				
					}
					else {
						log.info("BankDetailsWebServiceInvoker : Error in validateGUID call  ::  Webservice URL ::"+applicationProperty.getProperty("webService.url"));
						log.info("Request details :: GUID "+validatGUIDRQ.getGuid() +"Reference number "+validatGUIDRQ.getReferenceNumber());
						log.info("BankDetailsWebServiceInvoker :: Error in validateGUID :: Response Details " +"IsValid "+validateGUISRS.isValid()+" Error Code "+validateGUISRS.getErrorCode());						
					
						errorMessage="Result Code: "+ serviceResult.getResultCode()+" Error Code: "+serviceResult.getErrorCode()+" Error Type: "+serviceResult.getErrorType()+" Error Description : "+serviceResult.getTechnicalDescription();
						throw new CustomerServicesException(errorMessage);
					}
			}else{
				validateGUISRS.setErrorCode("1005");
				validateGUISRS.setValid(false);
				log.info("BankDetailsWebServiceInvoker : Error in validateGUID call GUID or Reference number is null/empty  ::  Webservice URL ::"+applicationProperty.getProperty("webService.url"));
				log.info("Request details :: GUID "+validatGUIDRQ.getGuid());
				log.info("Request details :: Reference number "+validatGUIDRQ.getReferenceNumber());	
				log.info("BankDetailsWebServiceInvoker :: Error in validateGUID :: Response Details " +"IsValid "+validateGUISRS.isValid()+" Error Code "+validateGUISRS.getErrorCode());
			}
		} catch (Exception e) {
			log.error("BankDetailsWebServiceInvoker :: Exception in ValidateGUID "+e);
			log.error("Webservice URL ::"+applicationProperty.getProperty("webService.url"));
			log.error("Request details :: GUID "+validatGUIDRQ.getGuid());
			log.error("Request details :: Reference number "+validatGUIDRQ.getReferenceNumber());
			log.error("BankDetailsWebServiceInvoker :: Error in validateGUID :: Response Details " +"IsValid "+validateGUISRS.isValid()+" Error Code "+validateGUISRS.getErrorCode());
			throw new CustomerServicesException(e);
		}
		return validateGUISRS;

	}

	/**
	 * @method addBankDetails
	 * @param addbankdetails
	 * @return boolean
	 * @throws CustomerServicesException
	 */
	public boolean addBankDetails(AddBankDetailsModel addbankdetails)
			throws CustomerServicesException {
		log.info("entering into addBankDetails method");
		boolean isSuccess = false;
		AddBankDetails_RQEntities addDetailsRQ = new AddBankDetails_RQEntities();
		AddBankDetails_RS addDetailsRS=new AddBankDetails_RS();
		BasicHttpBinding_ICompensationWebServiceStub callingStub=null;
		Result serviceResult=null;
		String errorMessage=null;
		try {
			
			addDetailsRQ.setTransactionId(addbankdetails.getGuid());
			addDetailsRQ.setRandiId(addbankdetails.getReferenceNumber());
			addDetailsRQ.setBankAccountNumber(addbankdetails.getAccountNumber());
			addDetailsRQ.setBankCode(addbankdetails.getBankCode());
			addDetailsRQ.setBankCountrycode(addbankdetails.getCountryCode());
			addDetailsRQ.setBankName(addbankdetails.getBankName());
			addDetailsRQ.setCurrencyCode(addbankdetails.getCurrency());
			addDetailsRQ.setIBAN(addbankdetails.getIbanNumber());			
			addDetailsRQ.setPayeeName(addbankdetails.getPayeeName());
			
			if(addbankdetails.getIbanswiftCode()!=null && !addbankdetails.getIbanswiftCode().isEmpty()){			
				addDetailsRQ.setSwiftCode(addbankdetails.getIbanswiftCode());
			}else{
				addDetailsRQ.setSwiftCode(addbankdetails.getSwiftCode());
			}
			addDetailsRQ.setBankDetailsAddedBy(VAA_BANK_DETAILS_ADDBY);
			
			callingStub=getStubCreation();
			addDetailsRS = callingStub.addBankDetails(addDetailsRQ);
			serviceResult=addDetailsRS.getResult();
			if (serviceResult.getResultCode()!=null && serviceResult.getResultCode().equals("0")) {			
				isSuccess = addDetailsRS.isIsSuccessful();				
			} else {	
				log.info("BankDetailsWebServiceInvoker : Error in addBankDetails call   ::  Webservice URL ::"+applicationProperty.getProperty("webService.url"));
				log.info("Request details ");
				log.info("Request details :: GUID "+addbankdetails.getGuid());
				log.info("Request details :: Reference number "+addbankdetails.getReferenceNumber());
				log.info("Request details :: Country "+addbankdetails.getCountry());
				log.info("Request details :: Currency "+addbankdetails.getCurrency());
				log.info("Request details :: Payee name "+addbankdetails.getPayeeName());
				log.info("BankDetailsWebServiceInvoker :: Response :: "+addDetailsRS.isIsSuccessful());
				
				errorMessage="Result Code: "+ serviceResult.getResultCode()+" Error Code: "+serviceResult.getErrorCode()+" Error Type: "+serviceResult.getErrorType()+" Error Description : "+serviceResult.getTechnicalDescription();
				throw new CustomerServicesException(errorMessage);
			}
		} catch (Exception e) {
			log.error("BankDetailsWebServiceInvoker :: Exception in Add Bank Details"+e);
			log.error("Webservice URL ::"+applicationProperty.getProperty("webService.url"));
			log.error("Request details :: GUID "+addbankdetails.getGuid());
			log.error("Request details :: Reference number "+addbankdetails.getReferenceNumber());
			log.error("Request details :: Country "+addbankdetails.getCountry());
			log.error("Request details :: Currency "+addbankdetails.getCurrency());
			log.error("Request details :: Payee name "+addbankdetails.getPayeeName());
			log.error("BankDetailsWebServiceInvoker :: Response :: "+addDetailsRS.isIsSuccessful());
			
			throw new CustomerServicesException(e);
		}
		return isSuccess;
	}
}
