package com.vaa.customerservices.webserviceinvoker;

import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.apache.axis.message.SOAPHeaderElement;
import org.apache.log4j.Logger;

import com.vaa.customerservices.util.ApplicationConstants;
import com.vaa.customerservices.util.CustomerServicesException;

public class BaseWebServiceInvoker {
	

	private static final Logger log = Logger.getLogger(BaseWebServiceInvoker.class);
	
	
	/**
	 * Method to create SOAP header to be sent in each request to SSP services
	 *@Method getSOAPHeader()
	 * @param guid
	 * @param applicationName
	 * @return SOAPHeaderElement
	 */
	public static SOAPHeaderElement getSOAPHeader(String guid, String applicationName) throws CustomerServicesException {
		log.info("entring into getSOAPHeader method");
		SOAPHeaderElement header=null;
		try {
		SimpleDateFormat dateTimeLocal = new SimpleDateFormat(ApplicationConstants.FORMAT_yyyy_MM_dd_HH_mm_ss);
		SimpleDateFormat dateTimeUTC = new SimpleDateFormat(ApplicationConstants.FORMAT_yyyy_MM_dd_HH_mm_ss);
		GregorianCalendar gc = new GregorianCalendar();
		header = new SOAPHeaderElement(ApplicationConstants.CONTEXT_NAMESPACE,ApplicationConstants.SERVICE_CALLING_CONTEXT);
		SOAPHeaderElement serviceCallingContext = new SOAPHeaderElement("",ApplicationConstants.SERVICE_CALLING_CONTEXT);
		SOAPHeaderElement serviceContext = new SOAPHeaderElement("",ApplicationConstants.SERVICE_CONTEXT);
		SOAPHeaderElement userContext = new SOAPHeaderElement("",ApplicationConstants.USER_CONTEXT);
		SOAPHeaderElement localTxnDateTime = new SOAPHeaderElement("",ApplicationConstants.CONTEXT_LOCAL_TXN_DATE_TIME);
		SOAPHeaderElement utcTxnDateTime = new SOAPHeaderElement("",ApplicationConstants.CONTEXT_UTC_TXN_DATE_TIME);
		SOAPHeaderElement appName = new SOAPHeaderElement("",ApplicationConstants.CONTEXT_APPNAME);
		SOAPHeaderElement guidElement = new SOAPHeaderElement("",ApplicationConstants.CONTEXT_GUID);
		SOAPHeaderElement requestId = new SOAPHeaderElement("",ApplicationConstants.CONTEXT_REQUEST_ID);
	
		// create calling context element
		localTxnDateTime.setActor(null);
		utcTxnDateTime.setActor(null);
		appName.setActor(null);
		guidElement.setActor(null);
		dateTimeUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		
		localTxnDateTime.addTextNode(dateTimeLocal.format(gc.getTime()));
		utcTxnDateTime.addTextNode(dateTimeUTC.format(gc.getTime()));
		appName.addTextNode(applicationName);
		guidElement.addTextNode(guid);
		requestId.addTextNode(guid+applicationName);

		userContext.addChildElement(localTxnDateTime);
		userContext.addChildElement(utcTxnDateTime);
		userContext.addChildElement(appName);
		userContext.addChildElement(guidElement);
		userContext.addChildElement(requestId);
		userContext.setActor(null);
	
		serviceContext.addChildElement(userContext);
		serviceContext.setActor(null);
		
		serviceCallingContext.addChildElement(serviceContext);
		serviceCallingContext.setActor(null);
		// create service calling context
		header.addChildElement(serviceCallingContext);
		
		header.setMustUnderstand(false);
		header.setActor(null);
		} catch (Exception e) {
			log.error("BaseWebServiceInvoker:: Exception in getSOAPHeader  -- >"+ e);
			throw new CustomerServicesException(e);
		}
		
		return header;
	}	
	
}
