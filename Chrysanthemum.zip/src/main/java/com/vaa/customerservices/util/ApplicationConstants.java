package com.vaa.customerservices.util;

public interface ApplicationConstants {

	
public static final String VAA_CUSTOMERSERVICES = "/vaa-customerservices";
public static final String BANK_DETAILTSFORM = "bankDetailsForm";

public static final String COMMAND = "command";
//public static final String VAA_CUSTOMERSERVICES = "/vaa-customerservices";

public static final String  FORMAT_yyyy_MM_dd_HH_mm_ss="yyyy-MM-dd HH:mm:ss";
public static final String  FORMAT_HH_mm_ss="HH:mm:ss";
public static final String CONTEXT_NAMESPACE="http://services.virgin-atlantic.com/Sales.CustomerRelations.Compensation.v1";
public static final String HEADER_VERSION="HeaderVersion";
public static final String SERVICE_CALLING_CONTEXT="ServiceCallingContext";
public static final String SERVICE_CONTEXT="ServiceContext";
public static final String USER_CONTEXT="UserContext";
public static final String CONTEXT_LOCAL_TXN_DATE_TIME="LocalTransactionStartDateTime";
public static final String CONTEXT_UTC_TXN_DATE_TIME="UTCTransactionStartDateTime";
public static final String CONTEXT_APPNAME="ApplicationName";
public static final String CONTEXT_GUID="GUID";
public static final String CONTEXT_REQUEST_ID="RequestId";
public static final String ERROR="error";
}
