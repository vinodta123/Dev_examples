/**
 * 
 */
package com.vaa.customerservices.util;


/**
 * @author charls
 *
 */
public class CustomerServicesException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1737368500273221324L;
	private String message = null;
	
	/**
	 * 
	 */
	public CustomerServicesException() {
		// TODO Auto-generated constructor stub#
		super();
	}

	/**
	 * 
	 * @param message
	 */
	public CustomerServicesException(String message) {		
		super(message);
		this.message = message;
	}

	/***
	 * 
	 * @param cause
	 */
	public CustomerServicesException(Throwable cause) {
		super(cause);
	}

	/***
	 * 
	 * @param message
	 * @param cause
	 */
	public CustomerServicesException(String message, Throwable cause)

	{

		super(message, cause);
	
		
	}

	/***
	 * 
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public CustomerServicesException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace){

		super(message, cause, enableSuppression, writableStackTrace);

	}

	
	@Override
	public String toString() {
		return message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
