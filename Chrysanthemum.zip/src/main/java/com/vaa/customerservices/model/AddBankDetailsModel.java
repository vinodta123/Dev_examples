package com.vaa.customerservices.model;

import java.util.List;



public class AddBankDetailsModel  implements java.io.Serializable {
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String referenceNumber;
	private String payeeName;
	private String accountNumber;
	private String bankCode;
	private String ibanNumber;
	private String swiftCode;
	private String ibanswiftCode;
	private String customerName;
	private String invoiceAmount;
	private String currency;
	private String guid;
	private String randiId;
	private String bankName;
	private String country;
	private String countryCode;
	private String othersPayMethod;
	private List<String> errorMessage;
	private boolean isSuccess;
	
	
	
	public boolean isSuccess() {
		return isSuccess;
	}

	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public List<String> getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(List<String> errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getOthersPayMethod() {
		return othersPayMethod;
	}

	public void setOthersPayMethod(String othersPayMethod) {
		this.othersPayMethod = othersPayMethod;
	}

	public String getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(String invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}
	public String getGuid() {
		return guid;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	
	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getIbanNumber() {
		return ibanNumber;
	}
	public void setIbanNumber(String ibanNumber) {
		this.ibanNumber = ibanNumber;
	}
	public String getSwiftCode() {
		return swiftCode;
	}
	public void setSwiftCode(String swiftCode) {
		this.swiftCode = swiftCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public String getRandiId() {
		return randiId;
	}
	public void setRandiId(String randiId) {
		this.randiId = randiId;
	}
	
	public String getIbanswiftCode() {
		return ibanswiftCode;
	}
	public void setIbanswiftCode(String ibanswiftCode) {
		this.ibanswiftCode = ibanswiftCode;
	}

}
