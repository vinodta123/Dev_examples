package com.vaa.customerservices.model;

import java.util.Map;


public class GuidInfoModel implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 936794602935038263L;
	
	private boolean isValid;	
	private String currency;
    private String invoiceAmount;
    private String timeRemaining;
    private String name;
    private String email;    
    private String guid;    			
    private String referenceNumber;
	private String payeeName;
	private String accountNumber;
	private String bankCode;
	private String bankName;
	private String ibanNumber;
	private String swiftCode;
	private String ibanswiftCode;
	
	private String country;	
	private String reagion;
	private Map<String,String> countryList;	
	private String othersPayMethod;
	private String countryName;
	
	private String countryCode;
	
	

	
	public String getReagion() {
		return reagion;
	}
	public void setReagion(String reagion) {
		this.reagion = reagion;
	}
	
	public String getOthersPayMethod() {
		return othersPayMethod;
	}
	public void setOthersPayMethod(String othersPayMethod) {
		this.othersPayMethod = othersPayMethod;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}	
	public Map<String, String> getCountryList() {
		return countryList;
	}
	public void setCountryList(Map<String, String> countryList) {
		this.countryList = countryList;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getIbanNumber() {
		return ibanNumber;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public void setIbanNumber(String ibanNumber) {
		this.ibanNumber = ibanNumber;
	}
	public String getSwiftCode() {
		return swiftCode;
	}
	public void setSwiftCode(String swiftCode) {
		this.swiftCode = swiftCode;
	}
	
    
	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(String invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public String getTimeRemaining() {
		return timeRemaining;
	}

	public void setTimeRemaining(String timeRemaining) {
		this.timeRemaining = timeRemaining;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}
	
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getIbanswiftCode() {
		return ibanswiftCode;
	}
	public void setIbanswiftCode(String ibanswiftCode) {
		this.ibanswiftCode = ibanswiftCode;
	}


}
