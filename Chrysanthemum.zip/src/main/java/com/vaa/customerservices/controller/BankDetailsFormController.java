package com.vaa.customerservices.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.vaa.customerservices.formvalidation.BankFormValidation;
import com.vaa.customerservices.model.AddBankDetailsModel;
import com.vaa.customerservices.model.GuidInfoModel;
import com.vaa.customerservices.model.ValidateGuIdModel;
import com.vaa.customerservices.service.BankDetailsService;
import com.vaa.customerservices.util.CustomerServicesException;




@Controller
public class BankDetailsFormController {
	
	private static final Logger log = Logger.getLogger(BankDetailsFormController.class);
	
	public static final String VAA_RECEIVE_GUID_SERVLET = "/vaa-customerservices";
	public static final String VAA_VALIDATION_SERVLET="/reviewBankDetails";
	public static final String VAA_ADDBANKDETAILS_SERVLET="/confirmBankDetails";
	public static final String VAA_FORMBACK_SERVLET="/backToBankDetailsForm";
	public static final String VAA_BANK_DETAILS_FORM="bankDetailsForm";
	public static final String VAA_BANK_DETAILS_REVIEW_FORM="bankDetailsReview";
	public static final String VAA_ERROR="error";
	public static final String VAA_CONFIRMATION="bankDetailsConfirmation";
	
	
	public BankDetailsService bankDetailsService;
	public BankFormValidation bankFormValidation;
	

	/**
	 * @param bankDetailsService
	 */
	@Autowired
	public void setBankDetailsService(BankDetailsService bankDetailsService) { 
		this.bankDetailsService = bankDetailsService;
	}
	
	@Autowired
	public void setBankFormValidation(BankFormValidation bankFormValidation) { 
		this.bankFormValidation = bankFormValidation;
	}

	@Resource(name="applicationProperty")
	private Properties applicationProperty;

	
	/**
	 * @param request
	 * @param model
	 * @return ModelAndView
	 */
	@RequestMapping(value = VAA_RECEIVE_GUID_SERVLET, method = RequestMethod.GET)
	public ModelAndView bankFormDetails(HttpServletRequest request,ModelMap model) {
		log.info("entering into bankFormDetails receive GUID servlet method of  BankDetailsFormController ");
		String nextForm = VAA_BANK_DETAILS_FORM;	
		String queryString=null;
		String GUID=null;	
		GuidInfoModel guidInfoModel=new GuidInfoModel();
		try {	
			queryString=request.getQueryString();
			GUID=request.getParameter("guid");			
			if(bankFormValidation.validateURL(queryString)){
				
				guidInfoModel=bankDetailsService.receiveGuidInfo(GUID);
				guidInfoModel.setGuid(GUID);	
				nextForm=VAA_BANK_DETAILS_FORM;
			}else{
				nextForm=VAA_ERROR;
			}
			
		}catch(CustomerServicesException er){ 
			log.error("BankDetailsFormController :: Exception in Receive GUID Information ",er);
			nextForm=VAA_ERROR;
		}catch (Exception e) {
			log.error("BankDetailsFormController :: Exception in Receive GUID Information ",e);	
			nextForm=VAA_ERROR;
		}	
		return new ModelAndView(nextForm, "command", guidInfoModel);
	}

		
	/**
	 * @param guidInfoModel1
	 * @param request
	 * @param model
	 * @return String
	 */
	@RequestMapping(value = VAA_VALIDATION_SERVLET, method = RequestMethod.POST)
	public String displayBankDetails(@ModelAttribute("command")GuidInfoModel guidInfoModel1, HttpServletRequest request, ModelMap model){
	log.info("entring into validate GUID servlet method of  BankDetailsFormController ");
		boolean isValid;
		String errorCode=null;
		ValidateGuIdModel validateGuidRQ = new ValidateGuIdModel();
		ValidateGuIdModel validateGuidRS;
		String nextForm = VAA_BANK_DETAILS_REVIEW_FORM;
		Map<String,String> countries = null;
		List<String> validateFormDetails=new ArrayList<String>();
		
		
		try {	
			validateFormDetails=bankFormValidation.validateFormDetails(guidInfoModel1);
			if(!guidInfoModel1.getCurrency().equalsIgnoreCase("GBP")&&!guidInfoModel1.getCurrency().equalsIgnoreCase("USD")){
				String [] tmp=guidInfoModel1.getCountry().split("_");				
				guidInfoModel1.setReagion(tmp[0]);
				if(tmp[1].equalsIgnoreCase("top")){
					model.addAttribute("countryCode", tmp[2]);
			}else{
				model.addAttribute("countryCode", tmp[1]);
			}
			
			}
			if(validateFormDetails.isEmpty()){
				validateGuidRQ.setGuid(guidInfoModel1.getGuid());
				validateGuidRQ.setReferenceNumber(guidInfoModel1.getReferenceNumber());
			
				validateGuidRS=bankDetailsService.validateGUID(validateGuidRQ);
				isValid=validateGuidRS.isValid();
				errorCode=validateGuidRS.getErrorCode();

				if(isValid && errorCode.equals("0")){
					nextForm = VAA_BANK_DETAILS_REVIEW_FORM;
				}else if(!isValid && errorCode.equals("1005")){	
					countries=bankDetailsService.getCountryList(guidInfoModel1.getCurrency());
					guidInfoModel1.setCountryList(countries);
					final String referrorMessage = applicationProperty.getProperty("errorMessage.invalid.referencenumber"); 
					model.addAttribute("referrorMessage", referrorMessage);
					nextForm=VAA_BANK_DETAILS_FORM;				
				}else{
					nextForm=VAA_ERROR;
				}
			}else{
				countries=bankDetailsService.getCountryList(guidInfoModel1.getCurrency());
				guidInfoModel1.setCountryList(countries);
				model.addAttribute("errorMessage", validateFormDetails);
				nextForm=VAA_BANK_DETAILS_FORM;	
				
			}
			
		}catch (CustomerServicesException er){
			log.error("BankDetailsFormController :: Exception in ValidateGUID ",er);
			nextForm=VAA_ERROR;
		}catch (Exception e) {
			log.error("BankDetailsFormController :: Exception in ValidateGUID ", e);
			nextForm=VAA_ERROR;
		}	
		return nextForm;
	}


	/**
	 * @param addBankDetails
	 * @param request
	 * @param model
	 * @return String
	 */
	@RequestMapping(value = VAA_ADDBANKDETAILS_SERVLET, method = RequestMethod.POST)
	public String confirmBankDetails(@ModelAttribute("command")AddBankDetailsModel addBankDetails, HttpServletRequest request, ModelMap model){
		log.info("entring into add bank details servlet method of  BankDetailsFormController ");		
		boolean isValid;
		String nextPage = VAA_ERROR;
		ValidateGuIdModel validateGuidRQ = new ValidateGuIdModel();
		ValidateGuIdModel validateGuidRS=new ValidateGuIdModel();		
		AddBankDetailsModel addBankDetailsRS=new AddBankDetailsModel();		
		try {
			validateGuidRQ.setGuid(addBankDetails.getGuid());
			validateGuidRQ.setReferenceNumber(addBankDetails.getReferenceNumber());
			validateGuidRS=bankDetailsService.validateGUID(validateGuidRQ);
			isValid=validateGuidRS.isValid();
			if(isValid){
				addBankDetailsRS=bankDetailsService.addBankDetails(addBankDetails);				
				if(addBankDetailsRS.isSuccess() && addBankDetailsRS.getErrorMessage().isEmpty()){
					nextPage=VAA_CONFIRMATION;
				}else{
					log.info("BankDetailsFormController :: Error in add bank details values -> " + addBankDetailsRS.getErrorMessage());
					nextPage=VAA_ERROR;	
				}
			}
			else
			{
				nextPage=VAA_ERROR;
			}

		}catch (CustomerServicesException er){
			log.error("BankDetailsFormController :: Exception in Add Bank Details ", er);
			nextPage=VAA_ERROR;
		}catch (Exception e) {
			log.error("BankDetailsFormController :: Exception in Add Bank Details ", e);
			nextPage=VAA_ERROR;
		}		
		return nextPage;
	}	

	/**
	 * 
	 * @param request
	 * @param model
	 * @return ModelAndView
	 */
	@RequestMapping(value = VAA_FORMBACK_SERVLET, method = RequestMethod.POST)
	public ModelAndView backToBankDetailsForm(HttpServletRequest request,ModelMap model) {
		log.info("entering into BankDetailsFormController backToBankDetailsForm method");
		String nextForm = VAA_ERROR;	
		GuidInfoModel guidInfoModel=new GuidInfoModel();
		Map<String,String> countries = null;
		try {
			
			guidInfoModel.setGuid(request.getParameter("guid"));			
			guidInfoModel.setName(request.getParameter("name"));
			guidInfoModel.setCurrency(request.getParameter("currency"));
			guidInfoModel.setInvoiceAmount(request.getParameter("invoiceAmount"));
			guidInfoModel.setCountry(request.getParameter("country"));	
			guidInfoModel.setReferenceNumber(request.getParameter("referenceNumber"));
			guidInfoModel.setPayeeName(request.getParameter("payeeName"));
			guidInfoModel.setBankName(request.getParameter("bankName"));
			guidInfoModel.setIbanNumber(request.getParameter("ibanNumber"));
			guidInfoModel.setSwiftCode(request.getParameter("swiftCode"));
			guidInfoModel.setIbanswiftCode(request.getParameter("ibanswiftCode"));
			guidInfoModel.setAccountNumber(request.getParameter("accountNumber"));
			guidInfoModel.setBankCode(request.getParameter("bankCode"));
			guidInfoModel.setOthersPayMethod(request.getParameter("othersPayMethod"));
			countries=bankDetailsService.getCountryList(guidInfoModel.getCurrency());
			guidInfoModel.setCountryList(countries);
			
			nextForm=VAA_BANK_DETAILS_FORM;			
		}catch(CustomerServicesException er){ 
			log.error("BankDetailsFormController :: Exception in backToBankDetailsForm " , er);
			nextForm=VAA_ERROR;
		}catch (Exception e) {
			log.error("BankDetailsFormController :: Exception in backToBankDetailsForm ", e);	
			nextForm=VAA_ERROR;
		}		
		return new ModelAndView(nextForm, "command", guidInfoModel);
	}
	
	
}

