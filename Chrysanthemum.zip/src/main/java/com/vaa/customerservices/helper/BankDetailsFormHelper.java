package com.vaa.customerservices.helper;

import org.apache.log4j.Logger;

import com.vaa.customerservices.controller.BankDetailsFormController;
import com.vaa.customerservices.util.CustomerServicesException;



public class BankDetailsFormHelper {
	static final Logger log = Logger.getLogger(BankDetailsFormController.class);
	

	
/**
 * 
 * @param queryString
 * @throws CustomerServicesException
 */
	public void validateURL(String queryString) throws CustomerServicesException {
		log.info("entring into helper validateURL  method");
		String [] splitQuery;
		try {
			splitQuery=queryString.split("=");
			if(splitQuery[0]==null ||splitQuery[0].equals("")||splitQuery[1]==null||splitQuery[1].equals("")){	
				log.info("GUID in customer Url is null");
				throw new CustomerServicesException("GUID in Url is valid");
			}
		}catch(Exception er){
			log.error("BankDetailsFormHelper -- > validate Query String ", er);
			throw new CustomerServicesException(er);
			
		}	

}
}
