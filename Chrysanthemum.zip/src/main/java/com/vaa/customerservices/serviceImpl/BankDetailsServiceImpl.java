package com.vaa.customerservices.serviceImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;



import javax.annotation.Resource;

import org.apache.log4j.Logger;

import com.vaa.customerservices.formvalidation.BankFormValidation;
import com.vaa.customerservices.model.AddBankDetailsModel;
import com.vaa.customerservices.model.GuidInfoModel;
import com.vaa.customerservices.model.ValidateGuIdModel;
import com.vaa.customerservices.service.BankDetailsService;
import com.vaa.customerservices.util.CustomerServicesException;
import com.vaa.customerservices.webserviceinvoker.BankDetailsWebServiceInvoker;

public class BankDetailsServiceImpl implements BankDetailsService {

	private static final Logger log = Logger.getLogger(BankDetailsServiceImpl.class);

	@Resource(name="countriesProperty")
	private Properties countriesProperty;

	public BankDetailsWebServiceInvoker bankDetailsWebServiceInvoker;

	public void setBankDetailsWebServiceInvoker(
			BankDetailsWebServiceInvoker bankDetailsWebServiceInvoker) {
		this.bankDetailsWebServiceInvoker = bankDetailsWebServiceInvoker;
	}

	/**
	 * @method receiveGuidInfo
	 * @param guId
	 * @return GuidInfoModel
	 * @throws CustomerServicesException
	 */
	public GuidInfoModel receiveGuidInfo(String guId)
			throws CustomerServicesException {
		log.info("entering into receiveGuidInfo method  ");
		GuidInfoModel guidInfoModel_RS =new GuidInfoModel();
		try{
		if (guId != null) {
				guidInfoModel_RS = bankDetailsWebServiceInvoker.receiveGuidInfo(guId);
				if(guidInfoModel_RS!=null){
					guidInfoModel_RS.setCountryList(makeCountryList(guidInfoModel_RS.getCurrency()));
				}
			}else{
				throw new CustomerServicesException();
			}

		
		} catch (Exception e) {
			log.error("BankDetailsServiceImpl :: Exception in ReceiveGuid Information"+e);
			throw new CustomerServicesException(e);

		}
	return guidInfoModel_RS;
	}
	
	
	
/**
 * @method validateGUID
 * @param validateGuidRQ
 * @return ValidateGuIdModel
 * @throws CustomerServicesException
 */
	public ValidateGuIdModel validateGUID(ValidateGuIdModel validateGuidRQ)
			throws CustomerServicesException {
		
		log.info("entering into validateGUID method ");
		ValidateGuIdModel validateGUISRS=new ValidateGuIdModel();
		try {
			validateGUISRS = bankDetailsWebServiceInvoker
						.validateGUID(validateGuidRQ);			

		
		} catch (Exception e) {
			log.error("BankDetailsServiceImpl :: Exception in ValidateGUID"+e);
			throw new CustomerServicesException(e);
		}

		return validateGUISRS;

	}

	/**
	 * @method addBankDetails
	 * @param bankdetails
	 * @return boolean
	 * @throws CustomerServicesException
	 */
	public AddBankDetailsModel addBankDetails(AddBankDetailsModel bankdetails)
			throws CustomerServicesException {
		log.info("entering into addBankDetails method");
		boolean isSuccess = false;	
		List<String> addBankDetailsValidatonMessage=new ArrayList<String>();
		BankFormValidation validate = new BankFormValidation();
		AddBankDetailsModel addBankDetailsRS=new AddBankDetailsModel();
		try {
				addBankDetailsValidatonMessage=validate.validateAddBankDetails(bankdetails);				
				
				if(addBankDetailsValidatonMessage.isEmpty() && bankdetails!=null){
					
					isSuccess = bankDetailsWebServiceInvoker.addBankDetails(bankdetails);				
				
					addBankDetailsRS.setSuccess(isSuccess);	
					addBankDetailsRS.setErrorMessage(addBankDetailsValidatonMessage);
				}else{
					addBankDetailsRS.setErrorMessage(addBankDetailsValidatonMessage);
					addBankDetailsRS.setSuccess(false);				
					
				}
				
	
		} catch (Exception e) {
			log.error("BankDetailsServiceImpl :: Exception in Add Bank Details" + e);
			throw new CustomerServicesException(e);
		}

		return addBankDetailsRS;

	}
	
	
	/**
	 * @method getCountryList
	 * @param guId
	 * @return Map<String,String>
	 * @throws CustomerServicesException
	 */
	public Map<String,String> getCountryList(String currencyType)
			throws CustomerServicesException {
		log.info("entering into getCountryList method  ");
		Map<String,String> countries = null;
		try {
			countries=makeCountryList(currencyType);
		} catch (CustomerServicesException e) {
			log.error("BankDetailsServiceImpl :: Exception in getCountryList Information"
					+ e);
			throw new CustomerServicesException(e);
		}catch (Exception e) {
			log.error("BankDetailsServiceImpl :: Exception in getCountryList Information"
					+ e);
			throw new CustomerServicesException(e);
		}
		return countries;
	}
	
	
	
	/**
	 * @method makeCountryList
	 * @param currencyType
	 * @return Map<String,String>
	 * @throws CustomerServicesException
	 */
	private Map<String,String> makeCountryList(String currencyType)
			throws CustomerServicesException {
		log.info("entering into makeCountryList method  ");
		
		Map<String,String> countries = new 	LinkedHashMap<String,String>();
		Map<String,String> toppcountries = new 	TreeMap<String,String>();
		Map<String,String> othercountries = new LinkedHashMap<String,String>();
		Map<String,String> finalcountries = new LinkedHashMap<String,String>();
		Set<Object> setKeys=null;
		try {
			if (currencyType != null) {
					setKeys=countriesProperty.keySet();
					 for(Object objectSet:setKeys){
				            String mapkey = (String)objectSet;
				            
				            if(currencyType.equalsIgnoreCase("EUR") && (mapkey.contains("top"))){	
				            	toppcountries.put(mapkey, countriesProperty.getProperty(mapkey));
				            }
					        
				            if(currencyType.equalsIgnoreCase("EUR") && (mapkey.contains("euro") || mapkey.contains("china"))){	
				             countries.put(mapkey, countriesProperty.getProperty(mapkey));
				            }else if(mapkey.contains("other")) {
				             othercountries.put(mapkey, countriesProperty.getProperty(mapkey));
				            } 
					 }  
					 
					 if(!countries.isEmpty()){
						 finalcountries = sortByValues(countries,toppcountries); 
					 }else{
						 finalcountries=sortByValues(othercountries,toppcountries);
						 	 
					 }
			}
	
		} catch (Exception e) {
			log.error("BankDetailsServiceImpl :: Exception in makeCountryList Information"
					+ e);
			throw new CustomerServicesException(e);

		}
		return finalcountries;
	}
	
	/**
	 * @method sortByValues
	 * @param mapToSort, toppcountries
	 * @return Map<String,String>
	 * @throws CustomerServicesException
	 */
	private static Map<String,String> sortByValues(Map<String,String> mapToSort, Map<String,String> toppcountries) throws CustomerServicesException { 
		log.info("entering into sortByValues method  ");
		Set<Entry<String, String>> entries = mapToSort.entrySet();
		List<Entry<String, String>> listOfEntries = new ArrayList<Entry<String, String>>(entries);
		
		 Collections.sort(listOfEntries, new Comparator<Entry<String,String>>() { 
			
			public int compare(Entry<String, String> e1, Entry<String, String> e2) {
				String v1 = e1.getValue(); String v2 = e2.getValue();
				return v1.compareTo(v2);
				}
			});
		
		 Map<String,String> sortedByValue = new LinkedHashMap<String, String>();

		 if(!toppcountries.isEmpty()){
			 for(Map.Entry<String, String> entry : toppcountries.entrySet()){
				 sortedByValue.put(entry.getKey().substring(2, entry.getKey().length()), entry.getValue()); 
			 }	
		 }	
		 for(Entry<String, String> entry : listOfEntries){ 
			 sortedByValue.put(entry.getKey(), entry.getValue()); 
		 }
		return sortedByValue;
	}
}
