HOW CAN I RUN Bundle Check 

Utility is taking following 3 parameters 
1) Publisher/Authors hostname and port number
2) password to connect to felix console
3) filepath - This file comes in every release from LBI

Following is the example

command> startCheck.bat http://<hostname>:<port> <password> <filepath>

Testing
startCheck.bat http://10.215.73.189:18001 dragonfly@2014 Bundles_sprint79.0_publish.txt

Dev2
startCheck.bat http://10.215.73.169:18001 dragonfly@2014 Bundles_sprint79.0_publish.txt

local 
startCheck.bat http://localhost:4502 admin Bundles_sprint79.0_publish.txt

startCheck.bat http://10.215.193.35:18001 vaadragongfly@tcs Bundles_sprint79.0_publish.txt

staging 

startCheck.bat http://10.215.193.42:18001 dragonfly@2014 Bundles_sprint79.0_publish.txt

startCheck.bat http://10.215.193.45:18002 dragonfly@2014 Bundles_sprint79.0_publish.txt

http://10.215.67.89/

vsvaasryapp2549.vaa.vtg.local

admin vsvaasryapp2536   10.215.67.88
node vsvaasryapp2549   10.215.67.89

startCheck.bat http://10.215.67.89:18001 dragonfly@2014 Bundles_sprint79.0_publish.txt

vsvaasryapp2549.vaa.vtg.local

find . -type f -exec grep -l "VSVAASRYWEB2297" {}\; 

find . -type f -exec grep -l "vsvaasryapp2536" {} \;

grep -i "VSVAASRYWEB2297" error.log 


/u01/apps/oracle_oc/wlserver_10.3/common/bin/
