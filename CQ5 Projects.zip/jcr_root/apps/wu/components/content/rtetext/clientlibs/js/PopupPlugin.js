CQ.form.rte.plugins.PopupPlugin = CQ.Ext.extend(CQ.form.rte.plugins.Plugin, {
	popupUI : null,
	popupDialog : null,
	modifyLink : function(context) {
		var com = CQ.form.rte.Common;
		if (!this.linkDialog || this.linkDialog.isDestroyed) {
			var linkRules = this.editorKernel.htmlRules.links;
			var dialogConfig = {
				"configVersion" : 1,
				"defaultDialog" : {
					"dialogClass" : {
						"type" : "rtepopupdialog"
					}
				},
				"parameters" : {
					"linkRules" : linkRules,
					"editorKernel" : this.editorKernel
				}
			};
			var dm = this.editorKernel.getDialogManager();
			var dialogHelper = dm.createDialogHelper();
			CQ.Util.applyDefaults(dialogConfig, this.config.popupDialogConfig
					|| {});

			dialogHelper.configure(dialogConfig);
			this.popupDialog = dialogHelper.create();
			dialogHelper.calculateInitialPosition();

		}
		var linkToEdit = null;
		var selectionDef = this.editorKernel.analyzeSelection();
		if (selectionDef.anchorCount == 1) {
			linkToEdit = selectionDef.anchors[0];
		}
		
		linkToEdit = linkToEdit || {};
		if (typeof linkToEdit.attributes === 'undefined')
			linkToEdit.attributes = {};
		this.popupDialog.initializeEdit(this.editorKernel, linkToEdit,
				this.applyLink.createDelegate(this));
		if (CQ.Ext.isIE) {
			this.savedRange = context.doc.selection.createRange();
		}
		var href=CUI.rte.HtmlRules.Links.getLinkHref(this.popupDialog.objToEdit.dom);
		var cssclass=com.getAttribute(this.popupDialog.objToEdit.dom, "class");
		var width=com.getAttribute(this.popupDialog.objToEdit.dom, "width");
		var height=com.getAttribute(this.popupDialog.objToEdit.dom, "height");
		if(href!=null && href!='undefined'){
		this.popupDialog.getFieldByName("href").setValue(href);
	
		this.popupDialog.url=href;
		}
		if(cssclass!=null && cssclass!='undefined'){
			this.popupDialog.getFieldByName("psize").setValue(cssclass);
		
			this.popupDialog.cssname=cssclass;
			if(cssclass=="Custom"){
				this.popupDialog.findById("height").setDisabled(false);
    			this.popupDialog.findById("width").setDisabled(false);
    			this.popupDialog.height=height;
    			this.popupDialog.width=width;
				this.popupDialog.findById("height").setValue(height);
				this.popupDialog.findById("width").setValue(width);
			}
			}
		this.popupDialog.show();
	},
	applyLink : function(context) {

		//        var linkObj = this.linkDialog.objToEdit;
		//        
		//        if (linkObj) {
		//            var linkUrl = linkObj.href;
		//            var cssClass = linkObj.cssClass;
		//            var target = linkObj.target;
		//            if (CQ.Ext.isIE) {
		//                this.savedRange.select();
		//            }
		if (CQ.Ext.isIE) {
			
             this.savedRange.select();
         }
		
		this.editorKernel.relayCmd("popup", {
			"url" : this.popupDialog.url,
			"css" : this.popupDialog.cssname,
			"height":this.popupDialog.height,
			"width":this.popupDialog.width
			
		});
		//  }
	},
	constructor : function(editorKernel) {
		CQ.form.rte.plugins.PopupPlugin.superclass.constructor.call(this,
				editorKernel);
	},
	getFeatures : function() {
		return [ "popup" ];
	},
	initializeUI : function(tbGenerator) {
		var plg = CQ.form.rte.plugins;
		var ui = CQ.form.rte.ui;
		
		 if (this.isFeatureEnabled("popup")) {
		this.popupUI = new ui.TbElement("popup", this, false, this
				.getTooltip("popup"));

		tbGenerator.addElement("popup", 120, this.popupUI, 10);
		 }
	},
	notifyPluginConfig : function(pluginConfig) {

		pluginConfig = pluginConfig || {};

		CQ.Util.applyDefaults(pluginConfig, {
			"features" : "*",
			"trimLinkSelection" : true,
			"popupDialogConfig" : {
				"targetConfig" : {
					"mode" : "manual"
				}
			},
			"anchorDialogConfig" : {
			// empty by default
			},
			"tooltips" : {
				"popup" : {
					"title" : CQ.I18n.getMessage("Popup"),
					"text" : CQ.I18n.getMessage("Create Popup Window")
				}
			}
		});
		this.config = pluginConfig;
	},
	execute : function(cmd, value, env) {
		if (cmd == "popup") {
			this.modifyLink(env.editContext);

		}
	}
//    updateState: function(selDef) {
		//        var hasSingleAnchor = selDef.anchorCount == 1;
		//       
		//        if (this.popupUI) {
		//            this.popupUI.getExtUI().setDisabled(!hasSingleAnchor);
		//         
		//        }
		//     
		//        
		//    }
		});
CQ.form.rte.plugins.PopupPlugin.LINKABLE_OBJECTS = [ "img" ];
CQ.form.rte.plugins.PluginRegistry.register("popup",
		CQ.form.rte.plugins.PopupPlugin);
