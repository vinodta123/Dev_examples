
CQ.form.rte.commands.Popup = CQ.Ext.extend(CQ.form.rte.commands.Command, {
	width:null,
	height:null,
    /**
     * Creates a styled link from the current selection.
     * @private
     */
    addLinkToDom: function(execDef) {
		height =execDef.value.height;
		width=execDef.value.width;
        var context = execDef.editContext;
        var nodeList = execDef.nodeList;
        var url = execDef.value.url;
        var styleName = execDef.value.css;
        var target = execDef.value.target;
        var attributes = execDef.value.attributes || { };
        var links = [ ];
        nodeList.getAnchors(context, links, true);
       
        if(styleName=="Small"){
        	
        	width=400;
        	height=400;
        }
        else if(styleName=="Medium"){
        	width=600;
        	height=700;
        }
        else if(styleName=="Big"){
        	width=800;
        	height=900;
        }
        if (links.length > 0) {
        	
            // modify existing link(s)
        	attributes['width']=width;
        	attributes['height']=height;
            for (var i = 0; i < links.length; i++) {
                this.applyLinkProperties(links[i].dom, url, styleName, target, attributes);
            }
            
        } else {
        	
            // create new link
            var sel = CQ.form.rte.Selection;
            var dpr = CQ.form.rte.DomProcessor;
            if (execDef.value.trimLinkSelection === true) {
                var range = sel.getLeadRange(context);
                range = sel.trimRangeWhitespace(context, range);
                sel.selectRange(context, range);
                nodeList = dpr.createNodeList(context, sel.createProcessingSelection(
                        context));
            }
            // handle HREF problems on IE with undo (IE will deliberately change the
            // HREF, causing the undo mechanism to fail):
            var helperSpan = context.createElement("span");
            helperSpan.innerHTML = "<a href=\"" + url + "\"></a>";
            attributes.href = helperSpan.childNodes[0].href;
            attributes[CQ.form.rte.Common.HREF_ATTRIB] = url;
            attributes['width']=width;
        	attributes['height']=height;
        	if (styleName) {
                attributes.className = styleName;
            }
            if (target) {
                attributes.target = target;
            } else {
                delete attributes.target;
            }
            for (var key in attributes) {
                if (attributes.hasOwnProperty(key)) {
                    var attribValue = attributes[key];
                    if ((attribValue == null) || (attribValue.length == 0)
                            || (attribValue == CQ.form.rte.commands.Popup.REMOVE_ATTRIBUTE)) {
                        delete attributes[key];
                    }
                }
            }
            nodeList.surround(context, "a", attributes);
        }
    },

    /**
     * Applies link properties (href, style, target) to the given anchor dom element.
     * @param {HTMLElement} dom DOM element the link properties will be applied (should be
     * @param {String} url URL/href to set
     * @param {String} styleName Name of CSS class to apply
     * @param {String} target target frame of the link
     * @param {Object} addAttributes additional attributes
     * @private
     */
    applyLinkProperties: function(dom, url, styleName, target, addAttributes) {
        var com = CQ.form.rte.Common;
        dom.href = url;
        dom.setAttribute(CQ.form.rte.Common.HREF_ATTRIB, url);
        if (target) {
            com.setAttribute(dom, "target", target);
        } else {
            com.removeAttribute(dom, "target");
        }
        if (styleName) {
            com.setAttribute(dom, "class", styleName);
        } else {
            com.removeAttribute(dom, "class");
        }
        if(width){
        	com.setAttribute(dom, "width", width);
        }
        else{
        	com.removeAttribute(dom, "width");
        }
        if(height){
        	com.setAttribute(dom, "height", height);
        }
        else{
        	com.removeAttribute(dom, "height");
        }	
        
    },

    /**
     * Removes a styled link according to the current selection.
     * @private
     */
    removeLinkFromDom: function(execDef) {
        var dpr = CQ.form.rte.DomProcessor;
        var context = execDef.editContext;
        var nodeList = execDef.nodeList;
        var links = [ ];
        nodeList.getAnchors(context, links, true);
        for (var i = 0; i < links.length; i++) {
            dpr.removeWithoutChildren(links[i].dom);
        }
    },

    isCommand: function(cmdStr) {
        var cmdLC = cmdStr.toLowerCase();
        return (cmdLC == "modifylink") || (cmdLC == "unlink");
    },

    getProcessingOptions: function() {
        var cmd = CQ.form.rte.commands.Command;
        return cmd.PO_BOOKMARK | cmd.PO_SELECTION | cmd.PO_NODELIST;
    },

    execute: function(execDef) {
    	
        switch (execDef.command.toLowerCase()) {
            case "popup":
                this.addLinkToDom(execDef);
                break;
           
        }
    },

    queryState: function(selectionDef, cmd) {
        return (selectionDef.anchorCount > 0);
    }

});

/**
 * Placeholder object for explicitly removing an attribute
 */
CQ.form.rte.commands.Popup.REMOVE_ATTRIBUTE = new Object();


// register command
CQ.form.rte.commands.CommandRegistry.register("popup", CQ.form.rte.commands.Popup);