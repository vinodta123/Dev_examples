/*function popup(url,style,width,height){
	var left = (screen.width/2)-(400/2);
    var top = (screen.height/2)-(400/2);
    if(style=="Small"){
    	window.open(url,"winname_small","directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=no,resizable=no,width=400,height=400,top="+top+",left="+left);
    }
    else if(style=="Medium"){
    	window.open(url,"winname_medium","directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=no,resizable=no,width=600,height=700,top="+top+",left="+left);
    }
    else if(style=="Big"){
    	 window.open(url,"winname_big","directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=no,resizable=no,width=800,height=900,top="+top+",left="+left);
         
    }
    else if(style=="Custom"){
	window.open(url,style,"directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=no,resizable=no,width="+height+",height="+width+",top="+top+",left="+left);
	return false;
    }
    
	
}*/
jQuery(document).ready(function () {
         var url="";
        jQuery("a.Small, a.Medium, a.Big, a.Custom ").click(function(){     
              url=jQuery(this).attr("href");
              url=url+"?wcmmode=disabled";
              var height=jQuery(this).attr("height");
              var width=jQuery(this).attr("width");
              var left = (screen.width/2)-(width/2);
              var top = (screen.height/2)-(height/2);
              
              var style=jQuery(this).attr("class");
              window.open(url,style,"directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=no,resizable=no,width="+height+",height="+width+",top="+top+",left="+left);
              url="";
              return false;
        }); 
    /*    jQuery("a.Medium").click(function(){    
            url=jQuery(this).attr("href");   
            url=url+"?wcmmode=disabled";
            var left = (screen.width/2)-(600/2);
            var top = (screen.height/2)-(700/2);            
            window.open(url,"winname_medium","directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=no,resizable=no,width=600,height=700,top="+top+",left="+left);
            url="";
            return false;
      });
        jQuery("a.Big").click(function(){   
            url=jQuery(this).attr("href");    
            url=url+"?wcmmode=disabled";
            var left = (screen.width/2)-(800/2);
            var top = (screen.height/2)-(900/2);  
            window.open(url,"winname_big","directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=no,resizable=no,width=800,height=900,top="+top+",left="+left);
            url="";
            return false;
      });*/
    });