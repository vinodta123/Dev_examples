CQ.form.rte.plugins.PopupDialog = CQ.Ext.extend(CQ.form.rte.ui.BaseWindow, {
	dialogconfig:null,
	cssname:"Small",
	url:"#",
	height:null,
	width:null,
    constructor: function(config) {
        config = config || { };
        this.dialogconfig=config;

        var defaults = {
            "title": CQ.I18n.getMessage("Popup"),
            "modal": true,
            "width": 400,
            "height": 350,
            
            "dialogItems": [ {
                    "itemId": "href",
                    "name": "href",
                    "parBrowse": true,
                    
                    "anchor": CQ.themes.Dialog.ANCHOR,
                    "fieldLabel": CQ.I18n.getMessage("Popup to"),
                    "xtype": "pathfield",
               
                    "fieldDescription": CQ.I18n.getMessage("External link example: http://sampleurl.com"),
                    "listeners": {
                        "dialogselect": {
                            "fn": this.geturlvalue,
                            "scope": this
                        },
                        "change": {
                            "fn": this.geturlvalue,
                            "scope": this
                        }
                      
                    },
                    "validator": this.validateLink.createDelegate(this),
                    "validationEvent": "keyup",
                    "escapeAmp": true
                   
                }, 
                {
                	"xtype":"selection",
                	"type":"radio",
                	"name":"psize",
                	"fieldLabel": "Popup Size",
                	"options":[ {
                        "value": "Small",
                        "text": CQ.I18n.getMessage("Small <div style='color: #8F8F8F;font-size: 11px; display:inline-block'>400*400</div>"),
                        "checked":"true"
                    }, {
                        "value": "Medium",
                        "text": CQ.I18n.getMessage("Medium <div style='color: #8F8F8F;font-size: 11px; display:inline-block'>600*700</div>")
                    }, {
                        "value": "Big",
                        "text": CQ.I18n.getMessage("Large  <div style='color: #8F8F8F;font-size: 11px; display:inline-block'>800*900</div>")
                    },
                    {
                        "value": "Custom",
                        "text": CQ.I18n.getMessage("Custom")
                    }
                ],
                "listeners": {
                  
                  "selectionchanged": {
                      "fn": this.getcssvalue,
                      "scope": this
                  }
                
              }
                },{
                	"xtype":"panel",
                	"border":false,
                	"layout":"hbox",
                	"fieldLabel":"Size",
                    "items":[{
                	"xtype":"textfield",
                	"name":"height",
                	"id":"height",
                	"width":50,
                	"listeners": {
                        "change": {
                            "fn": this.getheightvalue,
                            "scope": this
                        }
                      
                    }
                	
                },{
                	"xtype":"label",
                	"text":"px "
                },{
                	"xtype":"textfield",
                	"name":"width",
                	"id":"width",
                	"width":50,
                	"listeners": {
                        "change": {
                            "fn": this.getwidthvalue,
                            "scope": this
                        }
                      
                    }
                	
                },{
                	"xtype":"label",
                	"text":"px "
                }]
                }/*,
                  {
                	
                     "xtype":"textfield",
                     "name":"height",
                     "disabled":true,
                      "listeners": {
                          "change": {
                              "fn": this.getheightvalue,
                              "scope": this
                          }
                        
                      }
                   },
                   {
                       "xtype":"textfield",
                       "name":"width",
                       "disabled":true,
                        "listeners": {
                            "change": {
                                "fn": this.getwidthvalue,
                                "scope": this
                            }
                          
                        }
                     }*/
//                {
//                	
//                	"boxLabel":"Small",
//                	"xtype":"radio",
//                	"name":"psize",
//                	"value":"small",
//                	"text":"t1",
//                	"checked":"true",
//                	"jcr:primaryType":"cq:Widget",
//                	"fieldLabel": "Popup Size",
//                	 "listeners": {
//                        
//                        "check": {
//                            "fn": this.getcssvalue,
//                            "scope": this
//                        }
//                      
//                    }
//                }
//                ,
//                {
//                	
//                	"boxLabel":"Medium",
//                	"xtype":"radio",
//                	"name":"psize",
//                	"value":"medium",
//                	"text":"t1",
//                	"jcr:primaryType":"cq:Widget",
//                	"listeners": {
//                        
//                        "check": {
//                            "fn": this.getcssvalue,
//                            "scope": this
//                        }
//                }
//                },
//                {
//                	
//                	"boxLabel":"Big",
//                	"xtype":"radio",
//                	"name":"psize",
//                	"value":"big",
//                	"text":"t1",
//                	"jcr:primaryType":"cq:Widget",
//                	"listeners": {
//                        
//                        "check": {
//                            "fn": this.getcssvalue,
//                            "scope": this
//                        }
//                }
//                }

            ]
        };
        CQ.Util.applyDefaults(config, defaults);
        CQ.form.rte.plugins.PopupDialog.superclass.constructor.call(this, config);
    },
    getheightvalue:function()
    {
    	
    	var height=this.findById("height");
    		if (!height) {
                return false;
            }
    		this.height = height.getValue();
    		
    },
    getwidthvalue:function()
    {
    	
    	var width=this.findById("width");
		if (!width) {
            return false;
        }
		this.width = width.getValue();

    },
    geturlvalue:function()
    {
    	
    	if(this.getFieldByName("href")){
    		
    		this.url=this.getFieldByName("href").getValue();
//    		if(this.url.indexOf("http")==-1 && !this.url.indexOf("/")==0 && !this.url.indexOf("#")==0)
//    		{
//    			this.url="http://"+this.url;
//    		}
    	}
    	
//        	this.dialogconfig.parameters.editorKernel.relayCmd("popup", {
//            "url": this.url,
//            "css": "cssclass",
//            "target": "_blank"
//        });
    },
    
    getcssvalue:function(a,ch,checked)
    {
    	
    	if(checked==true)
    	{
    		this.cssname=this.getFieldByName("psize").getValue();
    		if(this.cssname=="Custom"){
    			this.findById("height").setDisabled(false);
    			this.findById("width").setDisabled(false);
    		}
    		else{
    			this.findById("height").setDisabled(true);
    			this.findById("width").setDisabled(true);
    			this.height=null;
    			this.width=null;
    		}
    	}
    },
    executeInsertText:function(){
    	
    },
  

    validateLink: function() {
    	
        var href = this.getFieldByName("href");
        if (!href) {
            return false;
        }
        href = href.getValue();
        var linkRules = this.getParameter("linkRules");
        
        
        if (!linkRules) {
            return (href.length > 0);
        }
        var protocol = linkRules.getProtocol(href);
        
        if (protocol) {
            // valid protocol prepended
            return true;
        }
        // internal & relative links
        if (linkRules.isInternalLink(href)) {
            return true;
        }
        if (linkRules.isRelativeLink(href)) {
            return true;
        }
        // invalid protocol?
        if (!linkRules.hasProtocol(href)) {
            return false;
        }
        // Link without protocol (i.e. www.day.com)
        return true;
        
    }

    
});

// register LinkDialog component as xtype
CQ.Ext.reg("rtepopupdialog", CQ.form.rte.plugins.PopupDialog);