/*
 * Copyright 1997-2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
package apps.wu.components.content.trackatransfer;

import java.io.IOException;

import javax.jcr.RepositoryException;

import com.day.text.Text;
import com.day.cq.wcm.commons.AbstractImageServlet;
import com.day.image.Layer;
import com.day.image.Font;

import java.awt.Color;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import com.wu.digital.service.request.RequestServiceJsonImpl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.jackrabbit.util.Base64;

import com.wu.digital.cms.TrackTransfer;

/**
 * Renders an image
 */
public class trackatransfer_png extends AbstractImageServlet {

    protected Layer createLayer(ImageContext c)
            throws RepositoryException, IOException {
        // don't create the later yet. handle everything later
        return null;
    }

    protected void writeLayer(SlingHttpServletRequest req,
                              SlingHttpServletResponse resp,
                              ImageContext c, Layer layer)
            throws IOException, RepositoryException {



    //TrackTransfer tt = new TrackTransfer();
   //String sessionId = tt.createSession();

//	RequestServiceJsonImpl csRequest = new RequestServiceJsonImpl();
//
//    String sessionId = (String) req.getParameter("cssd");
//	String imgString =	csRequest.getCaptcha(sessionId);
//	System.out.println("ssid:" + sessionId);
//
//    ByteArrayOutputStream os = new ByteArrayOutputStream();
//	Base64.decode(imgString, os);
//	ByteArrayInputStream is = new ByteArrayInputStream(os.toByteArray());
//
//	layer = new Layer(is);
//	layer.write("image/png", 1.0, resp.getOutputStream());

    //resp.flushBuffer();

    }
}