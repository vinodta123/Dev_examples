/**
 * The <code>CQ.form.ImageMultiField</code> class represents an editable list
 * of form fields for editing multi value properties.
 *
 * @class CQ.form.ImageMultiField
 * @extends CQ.form.CompositeField
 */
CQ.form.ImageMultiField = CQ.Ext.extend(CQ.form.CompositeField, {

    /**
     * @cfg {Object} fieldConfig
     * The configuration options for the fields (optional).
     */
    fieldConfig: null,
    
    test: null,
    
    numberOfItems: null,
    
	name: null,

    /**
     * Creates a new <code>CQ.form.ImageMultiField</code>.
     * @constructor
     * @param {Object} config The config object
     */
    constructor: function(config) {
        var list = this;
//ME
        if (!config.name) {
        	config.name = "./numberofitems";
        }
        
        if (!config.value) {
        	config.value = 0;
        }
//END ME        
        if (!config.fieldConfig) {
            config.fieldConfig = {};
        }
        if (!config.fieldConfig.xtype) {
            config.fieldConfig.xtype = "customgenericlist";
        }
        config.fieldConfig.name = config.name;
        config.fieldConfig.style = "width:95%;";

        var items = new Array();
        //ME
        this.numberOfItems = new CQ.Ext.form.Hidden({
            "name": config.name,
            "value": config.value
        });
        items.push(this.numberOfItems);
        //END ME
        if(config.readOnly) {
            //if component is defined as readOnly, appy this to all items
            config.fieldConfig.readOnly = true;
        } else {
            items.push({
                "xtype":"button",
                "cls": "cq-multifield-btn",
                "text":"+",
                "handler":function() {
                    list.addItem();
                }
            });
        }

//        items.push({
//            "xtype":"hidden",
//            "name":config.name + CQ.Sling.DELETE_SUFFIX
//        });
this.name = config.name;
this.fieldConfig = config.fieldConfig;
for (var i  = 0; i<this.fieldConfig.length; i++){
	if (this.fieldConfig[i].autoDelete) {
		items.push({
			"xtype":"hidden",
			"name":this.fieldConfig[i].name + CQ.Sling.DELETE_SUFFIX
		});
	}
}   
        config = CQ.Util.applyDefaults(config, {
            "defaults":{
                "xtype":"imagemultifielditem",
                "fieldConfig":config.fieldConfig
            },
            "items":[
                {
                    "xtype":"panel",
                    "border":false,
                    "bodyStyle":"padding:4px",
                    "items":items
                }
            ]
        });
        CQ.form.ImageMultiField.superclass.constructor.call(this,config);
        if (this.defaults.fieldConfig.regex) {
            // somehow regex get broken in this.defaults, so fix it
            this.defaults.fieldConfig.regex = config.fieldConfig.regex;
        }
        this.addEvents(
            /**
             * @event change
             * Fires when the value is changed.
             * @param {CQ.form.ImageMultiField} this
             * @param {Mixed} newValue The new value
             * @param {Mixed} oldValue The original value
             */
            "change"
        );
    },

    /**
     * Adds a new field to the widget.
     * @param value The value of the field
     */
    addItem: function(value) {
        var item = this.insert(this.items.getCount() - 1, {});
        this.findParentByType("form").getForm().add(item.field);
        this.doLayout();
        if (value) {
            item.setValue(value);
        }
        if (item.field.isXType("trigger")) {
            item.field.wrap.setWidth("95%");
        }
        //ME
        this.setNumberOfItems();
        return item;
        //END ME
    },
    
    /**
     * Returns the data value.
     * @return {String[]} value The field value
     */
    getValue: function() {
        var value = new Array();
        this.items.each(function(item, index/*, length*/) {
            if (item instanceof CQ.form.ImageMultiField.Item) {
                value[index] = item.getValue();
                index++;
            }
        }, this);
        return value;
    },

    /**
     * Sets a data value into the field and validates it.
     * @param {Mixed} value The value to set
     */
    setValue: function(value) {
//        this.fireEvent("change", this, value, this.getValue());
//    	var oldItems = this.items;
//        oldItems.each(function(item/*, index, length*/) {
//            if (item instanceof CQ.form.ImageMultiField.Item) {
//                this.remove(item, true);
//                this.findParentByType("form").getForm().remove(item);
//            }
//        }, this);
//        this.doLayout();
//        if ((value != null) && (value != "")) {
//            if (value instanceof Array || CQ.Ext.isArray(value)) {
//                for (var i = 0; i < value.length; i++) {
//                    this.addItem(value[i]);
//                }
//            } else {
//            	this.addItem(value);
//            }
//        }
		this.fireEvent("change", this, value, this.getValue());    	
        this.doLayout();
        if ((value != null) && (value != "")) {
        	if (value instanceof Array || CQ.Ext.isArray(value)) {
              for (var i = 0; i < value.length; i++) {
                  this.addItem(value[i]);
              }
          } else {
          	this.addItem(value);
          }
        }
    }
     ,
     
     getNumberOfItems: function(){
     	return this.items.getCount() - 1;
     	
     },
     
     setNumberOfItems: function(num){
     	if (!num){
     		this.numberOfItems.setValue(this.getNumberOfItems()); 
     	}
     	else{
     		this.numberOfItems.setValue(num);
     	}
     },
     
     processRecord: function(record, path) {                   	
     	var oldItems = this.items;
     	var values = new Array();
         oldItems.each(function(item/*, index, length*/) {
             if (item instanceof CQ.form.CustomMultiField.Item) {
                 this.remove(item, true);
                 this.findParentByType("form").getForm().remove(item);
             }
         }, this);                 
         
                 
         var numItems = record.get(this.name);        
         if (!numItems){
         	numItems = 0;
         }
         
         if (numItems==1){
         		var item = this.addItem();
         		item.processRecord(record, path);
         }        
         else{
         	for (var i =0; i < numItems; i++){
         		var newRecord = record.copy();
         		for (c in newRecord.data){
         			
         			if (CQ.Ext.isArray(newRecord.data[c])){
         				newRecord.data[c] = newRecord.data[c][i];
         				
         			}
         		}
         		var item = this.addItem();
         		item.processRecord(newRecord, path);
         	}
         }
         	
                 
     	
     }

});

CQ.Ext.reg("imagemultifield", CQ.form.ImageMultiField);

/**
 * The <code>CQ.form.ImageMultiField.Item</code> class represents an item in a
 * <code>CQ.form.ImageMultiField</code>. This class is not intended for direct use.
 *
 * @private
 * @class CQ.form.ImageMultiField.Item
 * @extends CQ.Ext.Panel
 */
CQ.form.ImageMultiField.Item = CQ.Ext.extend(CQ.Ext.Panel, {

    /**
     * Creates a new <code>CQ.form.ImageMultiField.Item</code>.
     * @constructor
     * @param {Object} config The config object
     */
    constructor: function(config) {
        var item = this;
        this.field = CQ.Util.build(config.fieldConfig, true);
//alert('here2');
		
        var items = new Array();
        items.push({
            "xtype":"panel",
            "border":false,
            "cellCls":"cq-multifield-itemct",
            "items": item.field
        });

        if(!config.fieldConfig.readOnly) {
            items.push({
                "xtype":"panel",
                "border":false,
                "items":{
                    "xtype":"button",
                    "text":"Up",
                    "handler":function() {
                        var parent = item.ownerCt;
                        var index = parent.items.indexOf(item);

                        if (index > 0) {
                            item.reorder(parent.items.itemAt(index - 1));
                        }
                    }
                }
            });
            items.push({
                "xtype":"panel",
                "border":false,
                "items":{
                    "xtype":"button",
                    "text":"Down",
                    "handler":function() {
                        var parent = item.ownerCt;
                        var index = parent.items.indexOf(item);

                        if (index < parent.items.getCount() - 1) {
                            item.reorder(parent.items.itemAt(index + 1));
                        }
                    }
                }
            });
            items.push({
                "xtype":"panel",
                "border":false,
                "items":{
                    "xtype":"button",
                    "cls": "cq-multifield-btn",
                    "text":"-",
                    "handler":function() {
                        item.ownerCt.remove(item);
                    }
                }
            });
        }

        config = CQ.Util.applyDefaults(config, {
            "layout":"table",
            "anchor":"100%",
            "border":false,
            "layoutConfig":{
                "columns":4
            },
            "defaults":{
                "bodyStyle":"padding:3px"
            },
            "items":items
        });
        CQ.form.ImageMultiField.Item.superclass.constructor.call(this, config);

        if (config.value) {
            this.field.setValue(config.value);
        }
    },
    
    /**
     * Reorders the item above the specified item.
     * @param item The item to reorder above
     */
    reorder: function(item) {
        var value = item.field.getValue();
        item.field.setValue(this.field.getValue());
        this.field.setValue(value);
    },

    /**
     * Returns the data value.
     * @return {String} value The field value
     */
    getValue: function() {
        return this.field.getValue();
    },

    /**
     * Sets a data value into the field and validates it.
     * @param {String} value The value to set
     */
    setValue: function(value) {
        this.field.setValue(value);
    }
     ,
     processRecord : function(record, path){
     	this.field.processRecord(record, path);
   	}
//     ,
//   	setParName: function(value){
//   	this.field.setParName(value);
//   	}
});

CQ.Ext.reg("imagemultifielditem", CQ.form.ImageMultiField.Item);
