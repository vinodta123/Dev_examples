
/**
 * The <code>CQ.form.CustomBrowseField</code> class represents an imput field
 * with a button to open a <code>CQ.BrowseDialog</code> for browsing links.
 * @class
 * @extends CQ.Ext.form.TriggerField
 */
CQ.form.CustomBrowseField = CQ.Ext.extend(CQ.Ext.form.CustomTriggerField, {
    /**
     *  @cfg {String} content
     *  The expand-path of the tree
     */
    content: null,

    /**
     * The panel holding the link-browser.
     * @private
     * @type CQ.BrowseDialog
     */
    browseDialog: null,

    /**
     * The trigger action of the TriggerField.
     * Creates a new BrowseDialog if it has not been created before,
     * and/or shows it.
     * The client has to supply an "ok"-handler in the BrowseDialog
     * configuration.
     * The treeRoot and treeLoader config properties of this widget
     * get passed to the BrowseDialog on creation.
     **/
    onTriggerClick : function() {
        if (this.disabled) {
            return;
        }
        if(this.browseDialog == null){
            /* Create the BrowseDialog if it has not been created before */
            var browseDialogConfig = {
                "jcr:primaryType": "cq:BrowseDialog",
                "ok": function() {
                    /* The ok handler of the BrowseDialog. */
                    if(this.browseField){
                        if (this.browseField.formatHtmlLink) {
                            var anchor = this.browseField.getParagraphAnchor();
                            anchor = anchor == "" ? anchor : "#" + anchor; 
                            this.browseField.setValue(this.getSelectedPath() + ".html" + anchor);
                        } else {
                            this.browseField.setValue(this.getSelectedPath());
                        }
                        this.browseField.fireEvent("dialogSelect", this);
                    }
                    this.hide();
                },
                /* pass this to the BrowseDialog to make in configurable from 'outside' */
                "parBrowse": this.parBrowse,
                "treeRoot": this.treeRoot,
                "treeLoader": this.treeLoader,
                "listeners": {
                    "hide": function() {
                        if (this.browseField) {
                            this.browseField.fireEvent("browsedialog.closed");
                        }
                    }
                }
            };

           /* build the dialog and load its contents */
           this.browseDialog = new CQ.Util.build(browseDialogConfig);
           this.browseDialog.browseField = this;
           this.browseDialog.loadContent(this.content);
        }
        /* Show the Dialog */
        this.browseDialog.show();
        this.fireEvent("browsedialog.opened");
    },

    constructor : function(config){
        CQ.form.CustomBrowseField.superclass.constructor.call(this, config);
        this.addEvents("browsedialog.opened", "browssedialog.closed");
    },
    
    initComponent : function(){
        CQ.form.CustomBrowseField.superclass.initComponent.call(this);
        this.addEvents(
            /**
             * @event dialogSelect
             * Fires when a new value was selected from the dialog.
             * @param {CQ.form.CustomBrowseField} field The browse field that has thrown the event
             */
            'dialogSelect'
        );
    },
    
    getParagraphAnchor: function() {
        return this.browseDialog.getSelectedAnchor();
    }
});

CQ.Ext.reg("custombrowsefield", CQ.form.CustomBrowseField);
