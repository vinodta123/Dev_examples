
/*
CQ.Workflow.Console.FooPanel = CQ.Ext.extend(CQ.Workflow.Console.InboxPanel, {

     // all the other stuff

    constructor: function(config) {
        // other stuff
	    window.console.log("instantiating");
        CQ.Workflow.Console.FooPanel.superclass.constructor.call(this, config);
    }

});
*/