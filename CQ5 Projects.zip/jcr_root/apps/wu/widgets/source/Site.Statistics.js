/**
 * The <code>CQ.wcm.custom.SiteStatistics</code> class provides the admin console for
 * WCM site administration.
 *
 * @class CQ.wcm.custom.SiteStatistics
 * @extends CQ.Ext.Viewport
 */
CQ.wcm.SiteStatistics = CQ.Ext.extend(CQ.Ext.Viewport, {
	
	eastPanelHidden: null,
	westPanelHidden: null,
	westPanelBtn: null,
	eastPanelBtn: null,
	eastPanel: null,
	westPanel: null,
	containerPanel: null,
	viewport: null,
	tab1: null,
	tab2: null,
	detail2: null,
	invDetailPanel: null,
	mainTabPanel: null,
	detailsPanel: null,
	centerPanel: null,			
    
	constructor: function(config) {
	
/*	this.westPanel = new CQ.Ext.Panel({
		'region': 'west',
		'title': "Main West Panel",
		'width': '200',
		'autoEl': 'div'
	
	});
	
	this.eastPanel = new CQ.Ext.Panel({
		region: 'east',
		title: 'Main East Panel',
		width: '200',
		'autoEl': 'div'
	});
	*/
	var body = CQ.Ext.getBody();
    body.setStyle("margin", "0");
    if (CQ.Ext.isIE) {
        body.dom.scroll = "no";
    }
    else {
        body.setStyle("overflow", "hidden");
    }
    try{
    	//CQ.Ext.Msg.alert("FOOBAR");
  //  this.gridPanel = new CQ.Workflow.Console.FooPanel({});
    //this.fooPanel = new CQ.Workflow.Console.InboxPanel({});
    }
    catch(e){
    	var foo = 10;
    }
    this.fooPanel = new CQ.Workflow.Console.InboxPanel({});

    this.centerPanel = new CQ.Ext.TabPanel({
		
		region: 'center',
		activeTab: 0,
		items: [{
			title: 'Site Information',
			xtype: 'panel',
			id:'cq.wcm.sitestats',
			height: '700',	
			layout: 'border',
			items: [
			   {
				region: 'north',
				xtype: 'form',
				bodyStyle:'padding:15px',
				split: true,
				height: 200,
				  items: [{
					  xtype: 'pathcompletion',
					  fieldLabel: 'Foo',
					  name: 'bar'
					},
					{
						xtype: 'textfield',
						fieldLabel: 'Bar',
						name: 'bar2'			
					},
					{
						xtype: 'browsefield',
						fieldLabel: 'Browse',
						name: 'bar10',	
						"treeRoot":{
	                        "name": "/etc"
	                        //"text": ""
	                    }
					},
					{
						xtype: 'textfield',
						fieldLabel: 'FooBar',
						name: 'bar3'			
					}]
				},
				{
					region: 'center',
					xtype: 'panel',
					layout: 'fit',
					height: 200,
					items: [
						//this.gridPanel
						//this.fooPanel
						new CQ.Workflow.Console.InboxPanel({})
						]
						
				
						
			}
			//this.gridPanel
		]
					
						
	
		},
		
		{
			id:'cq.wcm.siteusers',
			title: 'Active Users',
			xtype: 'panel',
			html: 'Hello World'
			
		},
		{
			id:'cq.wcm.replicationstats',
			title: 'Replication Status',
			xtype: 'panel',
			html: 'Replication'
			
		}]
		
	});
	/*
	    this.containerPanel = {
	        //header: false,
	        title: 'Menu', 
	        //tbar: mainTBar,
	        border:true,
	        region:'center',
	        items:[
	                this.westPanel,
	                this.centerPanel,
	                this.eastPanel
	        ]
	    };  

	    */

	    CQ.wcm.SiteStatistics.superclass.constructor.call(this, {
	        "id":"site-statitics",
	        "layout":"border",
	        "renderTo":CQ.Util.ROOT_ID,
	        //"cls":"cq-siteadmin-wrapper",
	        "items": [ 
	                  {
	                	'region': 'north',
	                	'html': "North",
	                	'xtype': 'panel'
	                		},
	  	                  {
	    	                	'region': 'west',
	    	                	'html': "West",
	    	                	'xtype': 'panel',
	    	                	'title': "This is the West New Panel",
	    	                	"autoScroll":true,
	                            "containerScroll":true,
	                            "collapsible":true,
	                            //"collapseMode":"mini",
	                            "animCollapse":true,
	                            'split': true,
	                            
	                            
	    	                		'width': 200
	    	                		//'collapsible': true
	    	                		},
	    	  	                  this.centerPanel,
	    	    	                		/*{
	    	    	    	                	'region': 'east',
	    	    	    	                	'html': "East",
	    	    	    	                	'xtype': 'panel',
	    	    	    	                		'width': 200
	    	    	    	                		},*/
	    	    	    	                		{
	    	    	    	    	                	'region': 'south',
	    	    	    	    	                	'html': "South",
	    	    	    	    	                	'xtype': 'panel'
	    	    	    	    	                		}              
	                		  
	                		  
	                  
	                	  ]
		});
	    
	    //this.toggleEastPanel();
	    //this.toggleWestPanel();
	    //this.mainTabPanel.on('tabchange',onTabChange);
	    
	    
	    
},

	
setRecreationActivitiesCB: function() {
    try {
        var url = "/etc/recreation/activities.infinity.json";
        var json = CQ.Util.eval(CQ.HTTP.get(url));
        var opts = [];
        for (var name in json) {
            var activityObj = json[name];
            var title = activityObj.text;
            if (title) {
                var val = activityObj.value;
                opts.push({
                    value: val,
                    text: title
                });
            }
        }
        opts.sort(function(l1, l2) {
            if (l1.text < l2.text) {
                return -1;
            } else if (l1.text == l2.text) {
                return 0;
            } else {
                return 1;
            }
        });
        this.setOptions(opts);
    } catch (e) {
        CQ.Log.error("CQ.utils.WCM#setContentLanguageOptions failed: " + e.message);
    }
},	
        
        //window.CQ_SiteAdmin_id = id;
  

    initComponent : function() {
        CQ.wcm.SiteStatistics.superclass.initComponent.call(this);
    	//alert("HEllo Wolrd");
        
    }/*,
    
	toggleEastPanel: function () {     
	     if (this.eastPanel) {        
	       if (this.eastPanelHidden == false) {
	    	   this.eastPanel.hide(); 
	    	   this.eastPanel.ownerCt.doLayout();         
	       } else {
	    	   this.eastPanel.show();
	    	   this.eastPanel.ownerCt.doLayout();
	    	   this.eastPanel.expand();     
	       }
	       this.eastPanelHidden = !this.eastPanelHidden;
	     }     
	},
	toggleWestPanel: function () {  
	     if (this.westPanel) {   
	       if (this.westPanelHidden == false) {
	    	   this.westPanel.hide(); 
	    	   this.westPanel.ownerCt.doLayout();         
	       } else {
	    	   this.westPanel.show();
	    	   this.westPanel.ownerCt.doLayout();
	    	   this.westPanel.expand();            
	       }
	       this.westPanelHidden = !this.westPanelHidden;       
	     }     
	},

	onTabChange: function (tabPanel, tab) {
	    switch (tab.id) {
	        case 'tab-1':
	        	this.detail2.hide();
	        	this.invDetailPanel.show();
	            break;
	        case 'tab-2':
	        	this.invDetailPanel.hide();
	        	this.detail2.show();
	            break;
	    }
	}*/
});
    
//alert ("Hello World");
CQ.Ext.reg('sitestatistics', CQ.wcm.SiteStatistics);
//alert("registered");
