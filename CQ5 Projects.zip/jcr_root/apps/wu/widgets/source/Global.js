/*
 * Use to define global constants reusable on all admin
 */
BLM = {};

BLM.Global = {};

BLM.Global.ListPagesSortOrderChanged = function(path, record) {
	var parentDialog = this.findParentByType("dialog");

	alert('before submit?  path to  = ' + path + ', from dialog = ' + this.findByType('dialog').path + ', thispath11 = ' + this.path + ', form url = ' + this.form.url + ', record = ' + record + ', this = ' + this.getField('./path');
}