// JavaScript Document
/* Social Media script*/
$(document).ready(function () {
        window.fbAsyncInit = function () {
            FB.init({
                appId: 624475480901469, status: true, cookie: true,
                xfbml: true
            });
        };
        (function () {
            var e = document.createElement('script');
            e.async = true;
            e.src = document.location.protocol +
            '//connect.facebook.net/en_US/all.js';
            if(document.getElementById('fb-root')) {
                document.getElementById('fb-root').appendChild(e);
            }

        }());
        (function () {
            var po = document.createElement('script');
            po.type = 'text/javascript';
            po.async = true;
            po.src = 'https://apis.google.com/js/plusone.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(po, s);
        })();
});