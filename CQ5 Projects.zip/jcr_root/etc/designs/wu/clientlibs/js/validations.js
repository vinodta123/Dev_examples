$(document).ready(function () {
    var email = $("#validateEmail").val();
    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    var currentMonth = currentDate.getMonth() + 1;
    var currentDay = currentDate.getDate();

    // Contact-Us page Validations START
    $(".contactUs-container .errorbox").hide();
    $("#container .error-msg").hide();
    $("#firstName").change(function () {
        $(this).css("margin-bottom", "22px");
        document.getElementById("firstName").style.borderColor = "#BFBFBF";
        $(this).next('.error-message').remove();
        $(this).prev('label').css("color", "#525252");
        var name = $(this).val();
        if (!name.match(/^[a-zA-Z]+$/)) {
            $(this).after("<span class='error-message'>Enter Valid FirstName</span>")
            $(this).css("margin-bottom", "0px");
            document.getElementById("firstName").style.borderColor = "#cf1b24";
            $(this).prev('label').css("color", "#cf1b24");
            $(this).focus();
        }
    });
    $("#lastName").change(function () {
        $(this).css("margin-bottom", "22px");
        document.getElementById("lastName").style.borderColor = "#BFBFBF";
        $(this).next('.error-message').remove();
        $(this).prev('label').css("color", "#525252");
        var name = $(this).val();
        if (!name.match(/^[a-zA-Z]+$/)) {
            $(this).after("<span class='error-message'>Enter Valid LastName</span>")
            $(this).css("margin-bottom", "0px");
            document.getElementById("lastName").style.borderColor = "#cf1b24"
            $(this).prev('label').css("color", "#cf1b24");
            $(this).focus();
        }
    });
    function checkDecimal(num) {
        if (num.indexOf('.') !== -1) { return true; } else { return false; }
    }
    $("#validateEmail").change(function () {
        $(this).next('.error-message').remove();
        $(this).css("margin-bottom", "22px");
        document.getElementById("validateEmail").style.borderColor = "#BFBFBF";
        $(this).prev('label').css("color", "#525252");
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var firstchar = /^[a-zA-Z].*$/
        var email = $(this).val();
        if (!firstchar.test(email) || !emailPattern.test(email) || email.charAt(email.indexOf("_")) === email.charAt(email.indexOf("_") + 1) || email.charAt(email.indexOf(".")) === email.charAt(email.indexOf(".") + 1)) {
            $(this).after("<span class='error-message'>Enter Valid Email</span>");
            $(this).css("margin-bottom", "0px");
            document.getElementById("validateEmail").style.borderColor = "#cf1b24"
            $(this).prev('label').css("color", "#cf1b24");
            $(this).focus();
        }
    });


    $(".errorbox a").click(function () {
        $(".errorbox").hide();
    });
    $("#numberTrack").change(function () {
        $(this).next('.error-message').remove();
        $(this).css("margin-bottom", "22px");
        document.getElementById("numberTrack").style.borderColor = "#BFBFBF";
        $(this).parent().prev('label').css("color", "#525252");
        $(this).parent().prev('label').children('span').css("color", "#525252");

        var number = $(this).val();
        if (!number.match(/^[0-9]+$/)) {
            $(this).after("<span class='error-message'>Enter Valid Track Number</span>");
            $(this).css("margin-bottom", "0px");
            document.getElementById("numberTrack").style.borderColor = "#cf1b24"
            $(this).parent().prev('label').css("color", "#cf1b24");
            $(this).parent().prev('label').children('span').css("color", "#cf1b24");
            $(this).focus();
        }
    });
    $(".text-description").keyup(function () {
        var len = $(this).val().length;
        if (len >= 4000) {
            var value = $(this).val().substring(0, 4000);
            $(this).text(value);
        } else {
            $('#charCount').text(4000 - len);
        }
    });

    /* Dropdown Validations */
    $("#choosingStates").change(function () {
        $(this).next().css("margin-bottom", "22px");
        document.getElementById("lastName").style.borderColor = "#BFBFBF";
        $(this).next().next('.error-message').remove();
        $(this).prev('label').css("color", "#525252");
        var name = $(this).val();
        if ($(this).val() == "Select") {
            $(this).next().after("<span class='error-message'>Choose Service/Department</span>")
            $(this).next().css("margin-bottom", "0px");
            document.getElementById("choosingStates").style.borderColor = "#cf1b24"
            $(this).prev('label').css("color", "#cf1b24");
            $(this).focus();
        }
    });
    /* function DOBValidation() {
    $("#year").css('color', '#666');
    $("#year").after("<span class='error-message'> Enter valid Year</span>");
    $("#year").css("margin-bottom", "0px");
    document.getElementById("year").style.borderColor = "#cf1b24"
    $('.orderdate').css("color", "#cf1b24");
    $('.orderdate').children('span').css("color", "#cf1b24");
    $("#year").focus();
    }*/
    function DOBValidation(selDate, selMonth, year) {

        // get DD ID from identifier        
        var dateSelectorVal = $("#selectDate").next("div.sbHolder").find('a.current').text();
        var monthSelectorVal = $("#selectMonth").next("div.sbHolder").find('a.current').text();

        //sbSelector_                 
        var errorflag = false;
        var yearValidate = true;
        var currentDate = new Date();
        var currentYear = currentDate.getFullYear();
        var currentMonth = currentDate.getMonth() + 1;
        var currentDay = currentDate.getDate();


        /*Checking Day & month if year entered*/
        if (year != "YYYY" && (year != "" && isNaN(year) || year != "" && checkDecimal(year) || year.length != 4 || year > currentYear)) {
            $("#year").next(".error-message").toggle();
            $("#year").after("<span class='error-message'>Enter Valid Year</span>");
            $("#year").css({ "margin-bottom": "0px" });
            document.getElementById("year").style.borderColor = "#cf1b24";
            $("#year").prev('label').css("color", "#cf1b24");
            $("#year").focus();
            $(".errorbox").show();
            errorflag = true;
            yearValidate = false;
        }

        if (yearValidate && year != "" && year != "YYYY") {
            $("#year").next(".error-message").remove();
            $("#year").attr("style", "border:1px solid #BFBFBF");
            $("#selectDate").next("div.sbHolder").next("span.error-message").remove();
            $("#selectDate").next("div.sbHolder").attr("style", "border:1px solid #E1E1E1;margin-bottom:21px");
            $("#selectDate").prev('label').css("color", "#414141");
            $("#selectMonth").next("div.sbHolder").next("span.error-message").remove();
            $("#selectMonth").next("div.sbHolder").attr("style", "border:1px solid #E1E1E1;margin-bottom:21px");
            $("#selectMonth").prev('label').css("color", "#414141");


            if (selDate == 0 || selDate == "-1") {
               $("#selectDate").next("div.sbHolder").next("span.error-message").remove();
               $("#selectDate").next("div.sbHolder").after("<span class='error-message' style='margin-top:33px;'>Select Date</span>");
               $("#selectDate").next("div.sbHolder").attr("style","border:1px solid #cf1b24;margin-bottom:0px");
               $("#selectDate").prev('label').css("color", "#cf1b24");
               $("#selectDate").focus();
               $(".errorbox").show();
                errorflag = true;
            } else if (selDate > 0) {
                if (year == currentYear && monthSelectorVal == currentMonth && dateSelectorVal > currentDay) {
                   $("#selectDate").next("div.sbHolder").next("span.error-message").remove();
                   $("#selectDate").next("div.sbHolder").after("<span class='error-message' style='margin-top:33px;'>Not Valid Date</span>");
                   $("#selectDate").next("div.sbHolder").attr("style","border:1px solid #cf1b24;margin-bottom:0px");
                   $("#selectDate").prev('label').css("color", "#cf1b24");
                   $("#selectDate").focus();
                   $(".errorbox").show();
                   errorflag=true;    
                }
            }


            if (selMonth == 0 || selMonth == "-1") {
               $("#selectMonth").next("div.sbHolder").next("span.error-message").remove();
               $("#selectMonth").next("div.sbHolder").after("<span class='error-message' style='margin-top:33px;'>Select Month</span>");
               $("#selectMonth").next("div.sbHolder").attr("style","border:1px solid #cf1b24;margin-bottom:0px");
               $("#selectMonth").prev('label').css("color", "#cf1b24");
               $("#selectMonth").focus();
               $(".errorbox").show();
                errorflag = true;
            } else if (selMonth > 0) {
                if (year == currentYear && monthSelectorVal > currentMonth) {
                     $("#selectMonth").next("div.sbHolder").next("span.error-message").remove();
                             $("#selectMonth").next("div.sbHolder").after("<span class='error-message' style='margin-top:33px;'>Not Valid Month</span>");
                             $("#selectMonth").next("div.sbHolder").attr("style","border:1px solid #cf1b24;margin-bottom:0px");
                             $("#selectMonth").prev('label').css("color", "#cf1b24");
                             $("#selectMonth").focus();
                             $(".errorbox").show();
                    errorflag = true;
                }
            }
        }
        return errorflag;

    }
    /* $("#selectDate").change(function () {
        if ($("#selectMonth").val() != "MM" || this.value.match(/^([0-9]{4})$/) || $(this).val() <= currentYear || $(this).val() != "DD" || $("#year").val() != "YYYY") {
            $("#year").next('.error-message').remove();
            $("#year").css("margin-bottom", "21px");
            document.getElementById("year").style.borderColor = "#BFBFBF";
            $('.orderdate').css("color", "#525252");
            $('.orderdate').children('span').css("color", "#525252");
        }
        if ($("#year").val() == currentYear) {
            if ($("#selectMonth").val() > currentMonth || $("#selectDate").val() > currentDay) {
                DOBValidation();
            }
        }
    });
    $("#selectMonth").change(function () {
        if ($("#selectDate").val() != "DD" || this.value.match(/^([0-9]{4})$/) || $(this).val() <= currentYear || $(this).val() != "MM") {
            $("#year").next('.error-message').remove();
            $("#year").css("margin-bottom", "21px");
            document.getElementById("year").style.borderColor = "#BFBFBF";
            $('.orderdate').css("color", "#525252");
            $('.orderdate').children('span').css("color", "#525252");
        }
        if ($("#year").val() == currentYear) {
            if ($("#selectMonth").val() > currentMonth || $("#selectDate").val() > currentDay) {
                DOBValidation();
            }
        }
    }); */
    $("#captcha").change(function () {
        if ($(this).val() == "") {
            $(this).after("<span class='error-message'>Capcha required</span>");
            $("#captcha").attr("style", "border:1px solid #cf1b24;margin-bottom:0px");
            $(this).prev('label').css("color", "#cf1b24");
            $(this).focus();
        } else {
            $("#captcha").attr("style", "border:1px solid #bfbfbf;margin-bottom:21px");
            $(this).next('.error-message').remove();
            $(this).prev('label').css("color", "#525252");
        }
    });

    /* $('#year').each(function () {
        var default_value = this.value;
        $(this).css('color', '#666');

        $(this).focus(function () {
            if (this.value == default_value) {
                this.value = '';
                $(this).css('color', '#666');
            }
        });
        $(this).focusout(function () {
            if (this.value == '') {
                this.value = default_value;
            }
        });
        $(this).change(function () {
            $(this).next('.error-message').remove();
            $(this).css("margin-bottom", "21px");
            document.getElementById("year").style.borderColor = "#BFBFBF";
            $('.orderdate').css("color", "#525252");
            $('.orderdate').children('span').css("color", "#525252");

            if (!this.value.match(/^([0-9]{4})$/) || $(this).val() > currentYear || $("#selectDate").val() == "DD" || $("#selectMonth").val() == "MM") {
                DOBValidation();
            }
            if ($(this).val() == currentYear) {
                if ($("#selectMonth").val() > currentMonth || $("#selectDate").val() > currentDay) {
                    DOBValidation();
                }
            }
        });
    }); */

     $('#year').each(function () {
        var default_value = this.value;
        $(this).css('color', '#666');

        $(this).focus(function () {
            if (this.value == default_value) {
                this.value = '';
                $(this).css('color', '#666');
            }
        });
        $(this).focusout(function () {
            if (this.value == '') {
                this.value = default_value;
            }
        });
    });

    $('#year,#selectDate,#selectMonth').change(function () {  
    	 var selectedDate	=	"";
         var selectedMonth	=	"";       
         if(document.getElementById("selectDate")) {
         	selectedDate 	= document.getElementById("selectDate").selectedIndex;        	
         }
         if(document.getElementById("selectMonth")) {
         	selectedMonth 	= document.getElementById("selectMonth").selectedIndex;        	
         }
         var givenYear = $("#year").val();         
         if(!isNaN(givenYear) && givenYear!="") {        	 
         	if(DOBValidation(selectedDate,selectedMonth,givenYear)) {
         		return false;
         	}
         }    else {        	 
        	 $("#year").val("");    
         }
    });



    $("#contact-send").click(function () {
        var firstName = $("#firstName").val();
        var lastName = $("#lastName").val();
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var email = $("#validateEmail").val();
        var description = $(".text-description").val();
        var comments = $("#desc").val();
        var year = $("#year").val();
        var service = $("#choosingStates").val();
        var trackNumber = $("#numberTrack").val();
        var captchainput = $("#captcha").val();
        var selectedDate = null;
        var selectedMonth = null;
        if (document.getElementById("selectDate")) {
            selectedDate = document.getElementById("selectDate").selectedIndex;
        }
        if (document.getElementById("selectMonth")) {
            selectedMonth = document.getElementById("selectMonth").selectedIndex;
        }
        var errorflag = "false";
        if (firstName == "") {
            $("#firstName").next(".error-message").toggle();
            $("#firstName").after("<span class='error-message'>First Name is required</span>");
            $("#firstName").css({ "margin-bottom": "0px" });
            document.getElementById("firstName").style.borderColor = "#cf1b24"
            $("#firstName").prev('label').css("color", "#cf1b24");
            $("#firstName").focus();
            $(".errorbox").show();
        }
        if (lastName == "") {
            $("#lastName").next(".error-message").toggle();
            $("#lastName").after("<span class='error-message'>LastName is required</span>");
            $("#lastName").css({ "margin-bottom": "0px" });
            document.getElementById("lastName").style.borderColor = "#cf1b24"
            $("#lastName").prev('label').css("color", "#cf1b24");
            $("#lastName").focus();
            $(".errorbox").show();
        }
        if (email == "") {
            $("#validateEmail").next(".error-message").toggle();
            $("#validateEmail").after("<span class='error-message'>Email address is required</span>");
            $("#validateEmail").css({ "margin-bottom": "0px" });
            document.getElementById("validateEmail").style.borderColor = "#cf1b24"
            $("#validateEmail").prev('label').css("color", "#cf1b24");
            $("#validateEmail").focus();
            $(".errorbox").show();
        }
        if (service == "Select") {
            $("#choosingStates").next('div').next(".error-message").toggle();
            $("#choosingStates").next().after("<span class='error-message'>Choose Service/Department</span>")
            $("#choosingStates").next().css("margin-bottom", "0px");
            $("#choosingStates").prev('label').css("color", "#cf1b24");
            $(".errorbox").show();
        }
        /* if (year == "YYYY" || year == "") {
        $("#year").next(".error-message").toggle();
        $("#year").after("<span class='error-message'>Year required</span>");
        $("#year").css({ "margin-bottom": "0px" });
        document.getElementById("year").style.borderColor = "#cf1b24"
        $('.orderdate').css("color", "#cf1b24");
        $('.orderdate').children('span').css("color", "#cf1b24");
        $(".errorbox").show();
        }*/
        if (!isNaN(year) && year != "") {
            if (DOBValidation(selectedDate, selectedMonth, year)) {
                errorflag = "true";
            }
        }
        if (captchainput == "") {
            $("#captcha").next(".error-message").toggle();
            $("#captcha").after("<span class='error-message'>Captcha is required</span>");
            $("#captcha").css({ "margin-bottom": "0px" });
            document.getElementById("captcha").style.borderColor = "#cf1b24"
            $("#captcha").prev('label').css("color", "#cf1b24");
            $("#captcha").focus();
            $(".errorbox").show();
            errorflag = "true";
        } else {
            $("#captcha").next("span.error-message").remove();
            $("#captcha").attr("style", "border:1px solid #BFBFBF;margin-bottom:21px");
            $("#captcha").prev('label').css("color", "#414141");
        }

        /*if (!trackNumber.match(/^[0-9]+$/)) {
        $("#numberTrack").next(".error-message").toggle();
        $("#numberTrack").after("<span class='error-message'>Enter Valid Track Number</span>");
        $("#numberTrack").css("margin-bottom", "0px");
        document.getElementById("numberTrack").style.borderColor = "#cf1b24"
        $("#numberTrack").parent().prev('label').css("color", "#cf1b24");
        $("#numberTrack").parent().prev('label').children('span').css("color", "#cf1b24");
        $(".errorbox").show();
        $("#numberTrack").focus();
        }*/
        if (errorflag == "false") {
            if (year != "" && isNaN(year)) { $("#year").val(""); }
            if (isNaN($("#selectDate").val())) { $("#selectDate").val(""); }
            if (isNaN($("#selectMonth").val())) { $("#selectMonth").val(""); }
            $(".midWrap").next(".errorbox").hide();
            //return true;
            $("#contactusform").submit();
        }
        //return false;

    });
    /* Contact-Us page Validations END */



    //Track-Result Page validations START
    /* $(".Transfer-tabs li").click(function () {
    $(".Transfer-tabs li").not($(this)).removeClass("active");
    $(this).addClass("active");
    });  */

    $("#number_Track").change(function () {

        $(this).css("margin-bottom", "2px");
        document.getElementById("number_Track").style.borderColor = "#BFBFBF";
        $(this).next('.error-message').remove();
        $(this).prev('label').css("color", "#525252");
        var name = $(this).val();
        if (!name.match(/^[0-9]+$/)) {
            $(this).after("<span class='error-message'>Enter Valid Track Number</span>")
            $(this).css("margin-bottom", "0px");
            document.getElementById("number_Track").style.borderColor = "#cf1b24";
            $(this).prev('label').css("color", "#cf1b24");
            $(this).focus();
        }
    });

    $("#firstName_Transfer,#receivers_firstName").change(function () {
        $(this).css("margin-bottom", "2px");
        $(this).css('border', '1px solid #BFBFBF');
        $(this).next('.error-message').remove();
        $(this).prev('label').css("color", "#525252");
        var name = $(this).val();
        if (!name.match(/^[a-zA-Z]+$/)) {
            $(this).after("<span class='error-message'>Enter Valid FirstName</span>")
            $(this).css("margin-bottom", "0px");
            $(this).css('border', '1px solid #cf1b24');
            $(this).prev('label').css("color", "#cf1b24");
            $(this).focus();
        }

        if (name == "") {
            $(this).css("margin-bottom", "2px");
            $(this).css('border', '1px solid #BFBFBF');
            $(this).next('.error-message').remove();
            $(this).prev('label').css("color", "#525252");
        }
    });
    $("#lastName_Transfer,#receivers_lastName").change(function () {
        $(this).css("margin-bottom", "2px");
        $(this).css('border', '1px solid #BFBFBF');
        $(this).next('.error-message').remove();
        $(this).prev('label').css("color", "#525252");
        var name = $(this).val();
        if (!name.match(/^[a-zA-Z]+$/)) {
            $(this).after("<span class='error-message'>Enter Valid LastName</span>")
            $(this).css("margin-bottom", "0px");
            $(this).css('border', '1px solid #cf1b24');
            $(this).prev('label').css("color", "#cf1b24");
            $(this).focus();
        }
        if (name == "") {
            $(this).css("margin-bottom", "2px");
            $(this).css('border', '1px solid #BFBFBF');
            $(this).next('.error-message').remove();
            $(this).prev('label').css("color", "#525252");
        }
    });


    function checkDecimal(num) {
        if (num.indexOf('.') !== -1) { return true; } else { return false; }
    }
    $("#Track_submit").click(function () {
        var firstName = $("#firstName_Transfer").val();
        var lastName = $("#lastName_Transfer").val();
        var number = $("#number_Track").val();
        var recv_firstName = $("#receivers_firstName").val();
        var recv_lastName = $("#receivers_lastName").val();
        var input_capcha = $("input.input_capcha").val();
        var captcha_input = $("#captcha").val();
        var sender;
        sender = 0;
        var receiver;
        receiver = 0;
        var submit_t = true;
        // Remove span by default
        $("#number_Track").next('span.error-message').remove();
        $("#firstName_Transfer").next('span.error-message').remove();
        $("#lastName_Transfer").next('span.error-message').remove();
        $("#recv_firstName_Transfer").next('span.error-message').remove();
        $("#recv_lastName_Transfer").next('span.error-message').remove();
        $("#senderRecieverInfo").html("");
        $("#senderRecieverInfo").hide();

        if (captcha_input == "") {
            $("#captcha").next(".error-message").toggle();
            $("#captcha").after("<span class='error-message'>Captcha is required</span>");
            $("#captcha").css("margin-bottom", "0px");
            $("#captcha").css('border', '1px solid #cf1b24');
            $("#captcha").prev('label').css("color", "#cf1b24");
            //$("#number_Track").focus();
            $(".errorbox").show();
            submit_t = false;
        }
        if (number == "") {
            $("#number_Track").next(".error-message").toggle();
            $("#number_Track").after("<span class='error-message'>Tracking Number is required</span>");
            $("#number_Track").css("margin-bottom", "0px");
            $("#number_Track").css('border', '1px solid #cf1b24');
            $("#number_Track").prev('label').css("color", "#cf1b24");
            //$("#number_Track").focus();
            $(".errorbox").show();
            submit_t = false;
        } else if (number != "" && isNaN(number) || number != "" && checkDecimal(number)) {
            $("#number_Track").next(".error-message").toggle();
            $("#number_Track").after("<span class='error-message'>Enter Valid Track Number</span>");
            $("#number_Track").css("margin-bottom", "0px");
            document.getElementById("number_Track").style.borderColor = "#cf1b24";
            $("#number_Track").prev('label').css("color", "#cf1b24");
            $("#number_Track").prev('label').children('span').css("color", "#cf1b24");
            $("#number_Track").nextAll('.error').hide();
            // $("#number_Track").focus();
            submit_t = false;
        } else {
            $("#number_Track").prev('label').css("color", "#525252");
            $("#number_Track").next('span.error-message').remove();
            document.getElementById("number_Track").style.borderColor = "#BFBFBF";
        }
        if ((firstName == "") || (lastName == "")) {
            sender = sender + 1;
        }
        if ((recv_firstName == "") || (recv_lastName == "")) {
            receiver = receiver + 1;

        }
        if (((firstName == "") || (lastName == "")) && ((recv_firstName == "") || (recv_lastName == ""))) {
            $("#senderRecieverInfo").attr("style", "padding-left:5px;padding-top:10px;margin-bottom:-5px;");
            $("#senderRecieverInfo").html("Either Sender's detail or Receiver's Details is needed");
            $("#senderRecieverInfo").show();
        }
        if (((firstName != "") && (lastName != "")) && ((!firstName.match(/^[a-zA-Z]+$/))) && ((recv_firstName == "") || (recv_lastName == ""))) {
            $("#firstName_Transfer").next(".error-message").toggle();
            $("#firstName_Transfer").after("<span class='error-message'>Enter Valid FirstName</span>")
            $("#firstName_Transfer").css("margin-bottom", "0px");
            $("#firstName_Transfer").css('border', '1px solid #cf1b24');
            $("#firstName_Transfer").prev('label').css("color", "#cf1b24");
            // $("#firstName_Transfer").focus();

        }

        if (((firstName != "") && (lastName != "")) && ((!lastName.match(/^[a-zA-Z]+$/))) && ((recv_firstName == "") || (recv_lastName == ""))) {
            $("#lastName_Transfer").next(".error-message").toggle();
            $("#lastName_Transfer").after("<span class='error-message'>Enter Valid LastName</span>")
            $("#lastName_Transfer").css("margin-bottom", "0px");
            $("#lastName_Transfer").css('border', '1px solid #cf1b24');
            $("#lastName_Transfer").prev('label').css("color", "#cf1b24");
            // $("#lastName_Transfer").focus();

        }

        if (((recv_firstName != "") && (recv_lastName != "")) && ((!recv_firstName.match(/^[a-zA-Z]+$/))) && ((firstName == "") || (lastName == ""))) {
            $("#recv_firstName_Transfer").next(".error-message").toggle();
            $("#recv_firstName_Transfer").after("<span class='error-message'>Enter Valid FirstName</span>")
            $("#recv_firstName_Transfer").css("margin-bottom", "0px");
            $("#recv_firstName_Transfer").css('border', '1px solid #cf1b24');
            $("#recv_firstName_Transfer").prev('label').css("color", "#cf1b24");
            // $("#recv_firstName_Transfer").focus();

        }

        if (((recv_firstName != "") && (recv_lastName != "")) && ((!recv_lastName.match(/^[a-zA-Z]+$/))) && ((firstName == "") || (lastName == ""))) {
            $("#recv_lastName_Transfer").next(".error-message").toggle();
            $("#recv_lastName_Transfer").after("<span class='error-message'>Enter Valid LastName</span>")
            $("#recv_lastName_Transfer").css("margin-bottom", "0px");
            $("#recv_lastName_Transfer").css('border', '1px solid #cf1b24');
            $("#recv_lastName_Transfer").prev('label').css("color", "#cf1b24");
            // $("#recv_lastName_Transfer").focus();

        }
        if ((firstName != "") && (!firstName.match(/^[a-zA-Z]+$/))) {
            submit_t = false;

        }
        if ((lastName != "") && (!lastName.match(/^[a-zA-Z]+$/))) {
            submit_t = false;
        }
        if ((recv_firstName != "") && (!recv_firstName.match(/^[a-zA-Z]+$/))) {
            submit_t = false;

        }
        if ((recv_lastName != "") && (!recv_lastName.match(/^[a-zA-Z]+$/))) {
            submit_t = false;

        }

        if ((submit_t == true) && ((sender == 0) || (receiver == 0))) {
            return true;
        }
        else {
            return false;
        }
        //return false;
    });

    //Validations for Track_Result End

    //Validations for LoginEmail Verification Start
    $("#login_password").blur(function () {
        $(this).css("margin-bottom", "15px");
        document.getElementById("login_password").style.borderColor = "#BFBFBF";
        $(this).next('.error-message').remove();
        $(this).prev('label').css("color", "#525252");
        if ($(this).val() == "") {
            $(this).next(".error-message").toggle();
            $(this).after("<span class='error-message'>Password should not be empty</span>");
            $(this).css({ "margin-bottom": "0px" });
            document.getElementById("login_password").style.borderColor = "#cf1b24"
            $(this).prev('label').css("color", "#cf1b24");
        }
    })
    $("#login_Email").change(function () {
        $(this).next('.error-message').remove();
        $(this).css("margin-bottom", "15px");
        document.getElementById("login_Email").style.borderColor = "#BFBFBF";
        $(this).prev('label').css("color", "#525252");
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var firstchar = /^[a-zA-Z].*$/
        var email = $(this).val();
        if (!firstchar.test(email) || !emailPattern.test(email) || email.charAt(email.indexOf("_")) === email.charAt(email.indexOf("_") + 1) || email.charAt(email.indexOf(".")) === email.charAt(email.indexOf(".") + 1)) {
            $(this).after("<span class='error-message'>Enter Valid Email</span>");
            $(this).css("margin-bottom", "0px");
            document.getElementById("login_Email").style.borderColor = "#cf1b24"
            $(this).prev('label').css("color", "#cf1b24");
            $(this).focus();
        }
    });
    $("#loginEmail_verify").click(function () {
        var password = $("#login_password").val();
        var login_email = $("#login_Email").val();
        if (login_email == "") {
            $("#login_Email").next(".error-message").toggle();
            $("#login_Email").after("<span class='error-message'>Email address is required</span>");
            $("#login_Email").css({ "margin-bottom": "0px" });
            document.getElementById("login_Email").style.borderColor = "#cf1b24"
            $("#login_Email").prev('label').css("color", "#cf1b24");
        }
        if (password == "") {
            $("#login_password").next(".error-message").toggle();
            $("#login_password").after("<span class='error-message'>Please enter password</span>");
            $("#login_password").css({ "margin-bottom": "0px" });
            document.getElementById("login_password").style.borderColor = "#cf1b24"
            $("#login_password").prev('label').css("color", "#cf1b24");
        }
        return false;
    });

    $("#login_Error").click(function () {
        var password = $("#login_password").val();
        var login_email = $("#login_Email").val();
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var firstchar = /^[a-zA-Z].*$/
        if (login_email == "" || !firstchar.test(email) || !emailPattern.test(email) || email.charAt(email.indexOf("_")) === email.charAt(email.indexOf("_") + 1) || email.charAt(email.indexOf(".")) === email.charAt(email.indexOf(".") + 1)) {
            $("#login_Email").next(".error-message").toggle();
            $("#login_Email").after("<span class='error-message'>Email address is required</span>");
            $("#login_Email").css({ "margin-bottom": "0px" });
            document.getElementById("login_Email").style.borderColor = "#cf1b24"
            $("#login_Email").prev('label').css("color", "#cf1b24");
            $(".error-msg").show();
        }
        if (password == "") {
            $("#login_password").next(".error-message").toggle();
            $("#login_password").after("<span class='error-message'>Please enter password</span>");
            $("#login_password").css({ "margin-bottom": "0px" });
            document.getElementById("login_password").style.borderColor = "#cf1b24"
            $("#login_password").prev('label').css("color", "#cf1b24");
            $(".error-msg").show();
        }
        return false;
    });
    $(".error-msg a").click(function () {
        $(".error-msg").hide();
    });







    $("#login_reg_password").blur(function () {
        $(this).css("margin-bottom", "0px");
        document.getElementById("login_reg_password").style.borderColor = "#BFBFBF";
        $(this).next('.error-message').remove();
        $(this).prev('label').css("color", "#525252");
        if ($(this).val() == "") {
            $(this).next(".error-message").toggle();
            $(this).after("<span class='error-message'>Email address is required</span>");
            $(this).css({ "margin-bottom": "0px" });
            document.getElementById("login_reg_password").style.borderColor = "#cf1b24"
            $(this).prev('label').css("color", "#cf1b24");
        }
    })
    $("#login_reg_Email").change(function () {
        $(this).next('.error-message').remove();
        $(this).css("margin-bottom", "16px");
        document.getElementById("login_reg_Email").style.borderColor = "#BFBFBF";
        $(this).prev('label').css("color", "#525252");
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var firstchar = /^[a-zA-Z].*$/
        var email = $(this).val();
        if (!firstchar.test(email) || !emailPattern.test(email) || email.charAt(email.indexOf("_")) === email.charAt(email.indexOf("_") + 1) || email.charAt(email.indexOf(".")) === email.charAt(email.indexOf(".") + 1)) {
            $(this).after("<span class='error-message'>Enter Valid Email</span>");
            $(this).css("margin-bottom", "0px");
            document.getElementById("login_reg_Email").style.borderColor = "#cf1b24"
            $(this).prev('label').css("color", "#cf1b24");
            $(this).focus();
        }
    });
    $("#loginReg_verify").click(function () {
        var password = $("#login_reg_password").val();
        var login_email = $("#login_reg_Email").val();
        if (login_email == "") {
            $("#login_reg_Email").next(".error-message").toggle();
            $("#login_reg_Email").after("<span class='error-message'>Email address is required</span>");
            $("#login_reg_Email").css({ "margin-bottom": "0px" });
            document.getElementById("login_reg_Email").style.borderColor = "#cf1b24"
            $("#login_reg_Email").prev('label').css("color", "#cf1b24");
        }
        if (password == "") {
            $("#login_reg_password").next(".error-message").toggle();
            $("#login_reg_password").after("<span class='error-message'>Please enter password</span>");
            $("#login_reg_password").css({ "margin-bottom": "0px" });
            document.getElementById("login_reg_password").style.borderColor = "#cf1b24"
            $("#login_reg_password").prev('label').css("color", "#cf1b24");
        }
        return false;
    });
    //Validations for LoginEmail Verification End
});