$(document).ready(function(){
  /* nav */
 $('.mobile-menu a').click(function(e){
        var homeLinks = $('.app_ul.home-links').html();
        var extraLinks = $('.app_ul.extra-links').html();
        var megamenuLinks = $('.app_ul.megamenu').html();
        $('.app_ul.mobile-home-links').html(homeLinks);
        $('.app_ul.mobile-extra-links').html(extraLinks);
        $('.app_ul.mobile-megamenu').html(megamenuLinks);
        $('.app_ul.mobile-megamenu>li').css("width", "auto");

    $('.mobile-menu-list').show();
    e.preventDefault();
  });
  $('.mobile-menu-list a.close-menu').click(function(e){
    $('.mobile-menu-list').hide();
    e.preventDefault();
  });


  /* arrows */
  var promoHeight = ($('.promo-marketing').height()/2)-35;
  $('.next-prev-arrows .arrow a').css('top' , promoHeight);
  
  if ( $(window).width() < 768) {
    var navWidth = $('ul.nav').width()-80;
    $('ul.nav li.account-profile').width(navWidth);     
  };

  /* megamenu */
  $('ul.megamenu li').on('mouseenter mouseleave', function(e) {
   /* console.log(e.type);*/
  	if (/enter/i.test(e.type)) {
    	$(this).addClass('active');
    	$(this).children('div').slideDown(200);
    } else {
	    $(this).removeClass('active');
	    $(this).children('div').hide();
    }
  });

  $('.custom.dropdown a').click(function(){
    $(this).parent('div').find('ul').toggle(300);
  });
  
  $('#accountInfo').click(function(){
    $('#mobileHeaderAccountInfo a, #mobileHeaderAddressInfo a, #mobileHeaderSecurityInfo a').removeClass('active');
    $('#mobileHeaderAccountInfo').next('.large-bound').hide();
    $('#mobileHeaderAddressInfo a').addClass('active');
    $('#mobileHeaderAddressInfo').next('.large-bound').show();
  });
  
  
});
