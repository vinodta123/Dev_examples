/** ** Megamenu Script * */
$(document).ready(function () {
	/*RTE Pop up function implementation*/
	 var url="";
     $("a.Small, a.Medium, a.Big, a.Custom ").click(function(){     
           url=$(this).attr("href");
           url=url+"?wcmmode=disabled";
           var height=$(this).attr("height");
           var width=$(this).attr("width");
           var left = (screen.width/2)-(width/2);
           var top = (screen.height/2)-(height/2);

           var style=$(this).attr("class");
           window.open(url,style,"directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=no,resizable=no,width="+height+",height="+width+",top="+top+",left="+left);
           url="";
           return false;
     }); 

	/* Left navigation toggle implementation */
	/*
    $('.leftnavigation>ul>li>a').click(function(e){
		e.preventDefault();
        $('.leftnavigation>ul>li').removeClass('selected').addClass('notselected');
        $(this).parent().removeClass('notselected').addClass('selected');
    });*/

	//dropdown fix
    setTimeout(function(){
      $('select').each(function(){
                $this = $(this);
                if($this.children().length == 0){
                   $(this).closest("div").children().find(".current").first().text("");
                }
    });},500);

    /* adding class for ie8 rounded corners fix */

   $('ul.megamenu li:first a').addClass('css3Style_ie');

/* country language drop down redirection start */
	 // dropdown script
    if(document.getElementById("defaultcountry")) {
	 $("#preferredCountry").val($('#defaultcountry').val().toLowerCase());
    $("#preferredLanguage").val($('#defaultlanguage').val().toLowerCase());
    $("#SMO_shoppingCountryTo").val($('#defaultcountry').val().toLowerCase());
    }


    $("#preferredCountry,#preferredLanguage").change(function(){
    $("#countryCode").val($('#preferredCountry').val());
    if($('#preferredLanguage').val() != null){

    $("#languageCode").val($('#preferredLanguage').val());

    }
        else{

            $("#languageCode").val($("#onelanguageCode").val());

        }

    var country = $("#countryCode").val();
    var language = $("#languageCode").val();

    setCookie("WUCountryCookie_",country,1);
    setCookie("WULanguageCookie_",language,1);
    var queryURL = "path:"+$('#queryPath').val()+ " " + $("#countryCode").val() + " "+$("#languageCode").val();
    var currResource = $("#currResource").val()+".countrylangquery.json";

    $.ajax({
    type: "GET",
    data: { query:queryURL, cols:"RedirectionURL" },
    url: currResource,
	dataType:"json",
	success: function (data) {

    var redirectURL = data.hits[0].RedirectionURL; 

    if(redirectURL){
    window.location.replace(redirectURL);
    }
    else{


    $("#countryLanguageHeaderForm")[0].submit();
    }
    
   }
});
    });

    
// Add a custom common DD
//$("select, .selectBox").selectbox();     

function setCookie(c_name,value,exdays)
{
var exdate=new Date();
exdate.setDate(exdate.getDate() + exdays);
var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString())+";path=/";
document.cookie=c_name + "=" + c_value;
return;
}

	
/* country language drop down redirection end */
	
	/*var count = $("ul.megamenu li").length;
	
	if((count == 1)||(count == 2)||(count == 3)){
	$("ul.megamenu").css("width", count * 200);
	var w = ($("ul.megamenu").width() / count);
	$("ul.megamenu li").css("width", w + "px");
	            }
	
	if(count == 4){
	                $("ul.megamenu").css("width", count * 180);
	            var w = ($("ul.megamenu").width() / count);
	            $("ul.megamenu li").css("width", w + "px");
	}
	if(count == 5){
	                $("ul.megamenu").css("width", count * 144);
	            var w = ($("ul.megamenu").width() / count);
	            $("ul.megamenu li").css("width", w + "px");
	}*/

    $(".changeCountry").change(function () {
        window.location.href = '#';
    });


        /* Home Promo slide width script */ 
    $(window).resize(function(){
        if($(window).width() > 768) {            
            var findTotalHomePromoSlide = $(".promo-marketing ul").children().length; 
            var findTotalwidthHomePromo = $(".promo-marketing ul").width(); 
            var findParentWidthHomePromo = $(".promo-marketing ul").offsetParent().width(); 
            var findPercentFromHomePromo = Math.round(100*findTotalwidthHomePromo/findParentWidthHomePromo);
            var findSlideWidth = Math.round(findPercentFromHomePromo/findTotalHomePromoSlide); 
            $(".promo-marketing ul li").attr("style","width:"+findSlideWidth+"%");
        } else if(($(window).width() <=768 && $(window).width() > 480) || $(window).width() <=480) {
            /* Remove the width */    
            $(".promo-marketing ul li").css("width","");
        } 
		if ($(window).width() < 1023) {
            var count = $("ul.megamenu li").length;
            $("ul.megamenu").css("width", count * 200);
            var w = ($("ul.megamenu").width() / count);
            $("ul.megamenu li").css("width", w + "px");
        }
        else {
            $("ul.megamenu, ul.megamenu li").css("width", "auto");
        }
    }).resize();


    /*new changes for Cheetah Mail start*/
        if (!$.support.placeholder) {

        var active = document.activeElement;

            $('input').focus(function() {
            if ($(this).attr('placeholder') != '' && $(this).val() == $(this).attr('placeholder')) {
                $(this).val('').removeClass('hasPlaceholder');
            }
        }).blur(function() {
            if ($(this).attr('placeholder') != '' && ($(this).val() == '' || $(this).val() == $(this).attr('placeholder'))) {
                $(this).val($(this).attr('placeholder')).addClass('hasPlaceholder');
            }
        });
        $('input').blur();

        $(active).focus();

    }


        /*new changes for Cheetah Mail end*/

    /* Rounded corner script for IE8 */
    	if (window.PIE) {
    		$('.css3Style_ie,.rteBlueBTN,.rteSmallBlueBTN').each(function() {
                PIE.attach(this);
            });
    	}
    /* End of rounded corner script for IE8 */


//script for accordian in send money page
    var firstEleHeight = $(".accordion-item:first-child .accordion-wrap .innerWrap .accordContent").height();
    $(".accordion-item:first-child .accordion-wrap .innerWrap").css({ height: firstEleHeight + 20 });
    $(".accordion-item:first-child .accordion-wrap h3 .ui-icon-plus").css({ 'background-position': "0px 0px" });

    $(".accordion-wrap h3").click(function (e) {

       $(this).find('.ui-icon-plus').css({ 'background-position': "0px 0px" });
        var acc_ht = $(this).parent('.accordion-wrap').find('.accordContent').height();
        $(this).parent('.accordion-wrap').find('.innerWrap').css("height", acc_ht + 20);
        $(this).parents('.accordion-item').siblings().find(".innerWrap").animate({ height: 0 }, 600);
        $(this).parents('.accordion-item').siblings().find(".ui-icon-plus").css({ 'background-position': "0px -24px" });
    });



});
/** ** END Megamenu Script * */




function refreshCaptcha(reqPath){

    $.getJSON(reqPath, function(data) {
        
        document.getElementById("cscaptchaimg").src=data.img;
        document.getElementById("cssd").value=data.cssd;
        
    });
}	
