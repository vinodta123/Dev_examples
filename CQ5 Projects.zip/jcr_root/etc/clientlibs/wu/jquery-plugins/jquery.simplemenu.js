// jQuery Simple Menu Plugin
// by P.J. Onori

(function($) {
	
  $.simplemenu = function(element, options) {
    var defaults = {}
    var plugin = this;
	
    plugin.settings = {}

    var $element = $(element), element = element;

    plugin.init = function() {
      plugin.settings = $.extend({}, defaults, options);	
      $element.bind('click', handleClick);
      $element.bind('focus', handleFocus);
      $element.bind('blur', handleBlur);	
    }
		
		plugin.show = function() {
		  $element.parent().addClass('simplemenu-active');
      $element.next('.simplemenu').show();
      $.simplemenu.active=$element;
      $.simplemenu.menu=$element.next('.simplemenu');
    }
		
		plugin.hide = function() {
			$element.next('.simplemenu').hide();
			$.simplemenu.menu=null;
		}
		
		plugin.hideActive = function() {
			if($.simplemenu.active) {
				$.simplemenu.active.data('simplemenu').hide();
				$('.simplemenu-active').removeClass('simplemenu-active');
				$.simplemenu.active=null
			}
			if($.simplemenu.menu) {
				$.simplemenu.menu=null;
			}			
		}
		
		var handleClick = function() {
			plugin.hideActive();
			plugin.show();
			return false;
		}
		
		//breaking in IE7
		var handleFocus = function() {
			return;

			plugin.hideActive();
			plugin.show();
		}
		
		//breaking in IE7
		var handleBlur = function() {
			return; 

			plugin.hideActive();
		}
		
    plugin.init();
  }
  
	$.simplemenu.active = null;
	$.simplemenu.menu = null;


  $.fn.simplemenu = function(options) {
		
	  $(document.body).bind('click', function(e) { 
		  var t=$(e.target);
		  if($(e.target).parents().is($.simplemenu.menu)) return;
		  if($.simplemenu.active) $.simplemenu.active.data('simplemenu').hideActive();	
    });
		
    return this.each(function() {
      if (undefined == $(this).data('simplemenu')) {
        var plugin = new $.simplemenu(this, options);
        $(this).data('simplemenu', plugin);
      }
    });
  }

})(jQuery);