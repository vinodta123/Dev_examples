(function($) {

    $.fn.previewContainer = function() {

        this.each( function() {
            
        });

    }

}(jQuery));