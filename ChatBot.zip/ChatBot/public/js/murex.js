var userName="John";
var baseurl_chat = "http://aneychatbot.azurewebsites.net";
// checking user has been logged in via MS account or not if not
//redirect to login page

//debugger; 
//global variable goes here.. 

var botSocket;
var g_country="Germany";
var g_city="Frankfurt";
var todaydate =null;
var selected_event_id;//for cancel or update the calendar event
var cityName;
var dateDDMMYYYY='01/01/2001';
 //Weather Condition Labels
var sunny = "Images/sunny_cloud.png";
var cloudy = "Images/mostly_cloud.png";
var thunderStorm ="Images/isolated_thunderstorms.png";
var rain = "Images/showers_cloud.png";
var thunderShowers = "Images/isolated_thundershowers.png";
var rightPanel="#rightPanel";

$('body').on('click','.content_left li.list-group-item' , function(){
		$('.content_left li.list-group-item').removeClass('active');
		$(this).addClass('active');		
	});  
  
    $('.leftPanel li.list-group-item').on('click', function(e){
        var lbl=$(this).find('span').text();
 		$('.leftPanel li.list-group-item').removeClass('active');
		$(this).addClass('active');
       
          if(lbl =='My workspace') {
           display_workspace('rightPanel');        
        } 
        else if(lbl == 'My Calendar'){
           botReply('rightPanel','Here is your calendar for the week.');
             loadCalender();
             
                      scroller();
             
        }
        else if(lbl == 'My News'){
            //botReply('rightPanel','Here are the Top International News');
            // getNews();
            
        }
        else if(lbl == 'Resolve Now'){
          //radio_button_options('rightPanel',["Resolve Now","My Calendar","My News","Request Now","I can’t find the question I want to ask!"],"How can I help you?");
          
          botReply('rightPanel','Can you please specify the problem you are facing?');
          botReply('rightPanel','These are the top issues raised by users.');
          radio_button_options('rightPanel',["System Slow", "VPN issue","Reset My Password","Outlook issue","Network drive related issue","My problem is not listed"],"Can you please specify what kind of issue do you have?",'Resolve'); 
        }
        else if(lbl == 'Request Now'){
        
         $.get('ServiceOption.html', function(data){                     
           $(rightPanel).append(data);   
           $(rightPanel).find('.setTime .msgTime').text(formatAMPM(new Date()).split(" ")[0]); 
                     scroller();                                           
          });
          
          
                   scroller();     
        }
        else {
           getReports();
        } 
        
	}); 
    
/*Show window upon successful loading of DOM & its content */    
$(window).on('load', function(){
   //console.log('Window has been fully loaded'); 
   $(".rightPanel.hide").removeClass('hide');
   $('.typeResponse').removeClass('hide');
  
   //console.info('----------> DOM loaded along with content');
});
    
//loading news and creating connection to Bot
$(document).ready(function () {
    
            
   setInterval(function(){ initDateTime(); },1000);
    
    var uName =userName;
    // var allowedIDs = ['Murex demo1', 'murex demo2', 'Murex demo3'];//disabling this check 'abhinav 27th may'
    // var isAllowed = (allowedIDs.indexOf(uName) != -1);
    // if(!isAllowed){
    //     botReply('rightPanel','Sorry I do not recognize you. Please login with your credentials');
    //      window.location.href=baseurl_chat+'/login.html';
    //      return(false);
    // }else{
    // botReply('rightPanel',timeOfDay() + " " +userName+"! How can I help you?");
    // botWeatherCard(function(current,forcast){
    //     placeWeatherDetails(current);
    //     getNews();
    // });
    botWeatherCard(function(current,forcast){
        placeWeatherDetails(current);
        getNews();
    });
    //$('#travelDate').datepicker({dateFormat : "DD, MM d, yy"});
       
    console.log(userName);
    $.ajax({
        url: baseurl_chat + '/login',
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify({userId: userName}),
        success: function (res) {
            if (res.status) {
                
                $('.displayTime > .status').addClass('connected').removeClass('unconnected');
              
                initWebSocket(res.tokenDetail); 
            } else {
                alert(res.msg);
            }
        }
    });
    
    
    
   
});

$('input:file').on("change", function() {
    alert("abc");
    $('input:submit').prop('disabled', !$(this).val()); 
});


// user event handlers
$("body").on('click','.cardButton',function(e){
    var data=$(this).attr('data');
    //console.log(data);
});   
$("body").on('click','.botTextMsg',function(e){
    var Bdata=$(this).text();
    //console.log(Bdata);
    $(".uText").val(Bdata);
    $(".uText").focus();
    
    
});

$("body").on('click','.ultimatix',function(e){
    window.open("https://www.boehringer-ingelheim.com/");
    });
    
$("body").on('click','.smartTransform',function(e){
    window.open("https://www.boehringer-ingelheim.com/");
    });    
 $("body").on('click','.osi',function(e){
    window.open("http://www.osisoft.com/");
    });    

$("body").on('click','.fresco',function(e){
    window.open("https://www.fresco.me");
});

$("body").on('click','.smartplant',function(e){
    window.open("http://www.intergraph.com/products/ppm/smartplant/foundation/web_portal/default.aspx/");
});


$("body").on('click','.primavera',function(e){
     window.open("https://www.oracle.com/applications/primavera/index.html/");
});

 $("body").on('click','.sap',function(e){
     window.open("https://www.sap.com/index.html/");
}); 

 $("body").on('click','.tcs',function(e){
     window.open("https://www.tcs.com/"); 
});

$('body').on('click','.travelSubmit' , function(){
    //console.log("Inside travel---->>>");
    //botReply('rightPanel','Help me plan your trip.');    
    var travelDate =document.getElementById("travelDate").value;
    var today = new Date(); 
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!
    var yyyy = today.getFullYear();
    if(dd<10){
        dd='0'+dd;
    } 
    if(mm<10){
        mm='0'+mm;
    } 
    var today = yyyy+'-'+mm+'-'+dd;
    console.log(today);
    //console.log(travelDate.getMonth());
    if (travelDate < today) {
        botReply('rightPanel','Oops!! Looks like you have not selected a valid date!');
        botReply('rightPanel','Please select a future date for your travel and click submit again.');
    }
    else{
    
    var travelCity =  'Trip to ' + cityName;
		serviceNowRequest('Travel',travelCity,'1','1');
    }		
	});  
$("body").on('click','.screenSubmit',function(){
   botReply('rightPanel','Ok. I will forward your ticket to the End User Operations team to ensure your issue is resolved');
    botReply('rightPanel','Your ticket number is INC002398 and the ticket will be resolved within 8 hours');
    });  
//send data on enter 
$("textarea").keydown(function(e){
    if((e.keyCode || e.which) == 13) { 
        e.preventDefault();
        $(".send").click();
    }
});

$(".send").click(function () {
    var uText = $(".uText").val();

    if (uText.length === 0 || !uText.replace(/\s/g, '').length) {
        return;
    } else {
        
   $(".uText").val('');
   userReply('rightPanel',uText);
       
 // for calendar cancel event
//this event is for cancel the calendar event 
// this is kind of static event catch it can only trigger 
// when user click on bot reply message 'Yes, Cancel the meeting' 
// define in calendar.html line 155, and 
//he has picked on event if($(this).html()==="Yes, Cancel the meeting"){ 
//don't change this message exact string matching is being done here 
    if(uText==="Yes,Cancel the meeting"){
    if(selected_event_id){
        outlookCalendarCancel(selected_event_id,function(res){
             console.log("Cancel status:"  + res); 
             if(res.status){ 
                 botReply('rightPanel',"I have cancelled your meeting."); 
                 loadCalender();
             }else{
                 //botReply('rightPanel',"I have cancelled your meeting."); 
                  console.log("Some problem with connection."); 
             }
         }); 
     }
     }else if( (uText === "Yesterday") || (uText === "yesterday") ){
        var date = new Date();
        //console.log(date);
        var weekday = new Array(7);
        weekday[0] = "Sunday";
        weekday[1] = "Monday";
        weekday[2] = "Tuesday";
        weekday[3] = "Wednesday";
        weekday[4] = "Thursday";
        weekday[5] = "Friday";
        weekday[6] = "Saturday";
        var n = weekday[date.getDay()];
        date.setDate(date.getDate()-1);
        date = date.getDate() + '/' + (date.getMonth()+1) + '/' + date.getFullYear();
        botReply('rightPanel','Hey! Yesterday was ' + date + ', a ' + n);
     
     
     }else{
         //$(".murex-status").html("Processing...");
        //botSocket.send(uText);
         $('.displayTime > .status').addClass('connected').removeClass('unconnected');
       // $('#murex_status_image_connect').css('display','inline-block');
       // $('#murex_status_image_unconnect').css('display','none');
        $.ajax({
            url: baseurl_chat + '/sendMessage',
            type: 'POST',
            contentType: "application/json",
            data: JSON.stringify({"message": uText,"userId":userName}),
            success: function (res) {
                //console.log("Inside success----->>>>");
                //console.log(res);
            },
            error:function(err){
                 $('.displayTime > .status').addClass('unconnected').removeClass('connected');
                botReply('rightPane','Sorry! It seems I got distracted, Can you please repeat.');
                console.log(err);
            }
        });
     } 
    }
});




// card click event handler
$("body").on('click','.incident_item',function(){
   var text=$(this).text();
   var dataTyp = text.substr(0,4);
   //console.log(text);
   showIncidentRecordById(text, dataTyp);
});

$("body").on('click','.graphs',function(){
   botReply('rightPanel','Find your graphical reports here');
   appendStateDiv("incident");
   
});


$("body").on('click','.request_item',function(){
   var text=$(this).text();
   //console.log(text);
   showRequestRecordById(text);
});






$("body").on('click','.card-block a',function(){
   var text=$(this).text();
   if(text==="Update Ticket") {
       // handle incident show incident form
       showLogIncidentForm('rightPanel');
   }
   if(text==="Schedule a callback") {
       botReply('rightPanel','Please tell me a suitable time for a callback.');
   }
});


$("body").on('click','.hardware',function(){
    ///botReply('rightPanel','Following are the list of hardware to meet your business needs, including phones, tablets and laptops');
    
    radio_button_options('rightPanel',["Order New Hardware","Raise System Information Request"],"What would you like me to do?");
    
    //displayHardware('rightPanel');
  });
  
  
  $("body").on('click','.system',function(){
     requestSystemService('SystemInfo','9aaef20bdbe1ba40a6fe735daf9619e3','SystemInfo','HostName:DICHPSHEWI2K801','open');
  });
                      
 function requestSystemService(Item,assignment_group,u_item,short_description,state){
     
     botReply('rightPanel','I am going to raise a ticket for your concern');
     
     
     
     var conversation = '';
   getBotUserConversations(function(res){
        //console.log(JSON.parse(res));   
        var obj = JSON.parse(res);
         for (var i = 0; i < obj.activities.length; i++) {
                 var boolOption = obj.activities[i];
                 //console.log(boolOption.from.id + ":" + boolOption.text );
                 if(boolOption.from.id != 'MurexChatBot'){
                     conversation += boolOption.from.id + "-" + boolOption.text + '\n';
                 }
                 else if(boolOption.from.id === 'MurexChatBot'){
                    conversation += boolOption.from.id + "-" + JSON.parse(boolOption.text).msg + '\n';
                 }
                    }
               console.log(conversation); 
     
     
     
     $.ajax({
        url: baseurl_chat+ '/postRequest',
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify({"Item": Item,"assignment_group": assignment_group,"u_item":u_item,"short_description":short_description,"state":state,"description":conversation}),
        success: function (res) {
             if (res.status) {
                botReply('rightPanel',"Please note the incident Id: <span class='request_item' style='cursor:pointer;color:blue;' title='Click to check your ticket status.'>"+res.data+"</span>");
                 //console.log("I have raised the incident , please note the incident Id: "+res.data);
            } else {
                //console.log(res.data);
            }
        }
    });
    
   }); 
    
 } 
                      
                    
 $("body").on('click','.software',function(){
displaySoftware();
  });  
  
$("body").on('click','.admin',function(){
  
displayAdmin();
  });
$("body").on('click','.adminOptions',function(e){
 var Bdata=$(this).text();

if(Bdata === 'Travel Request'){
   
   botReply('rightPanel','Where do you want to travel?');
   
}else if(Bdata === 'Mover Request'){
   
 serviceNowMoverRequest('Movers','9aaef20bdbe1ba40a6fe735daf9619e3','Movers','UserID:John Smith\nStreet:\'403,Shell Headquarters Carel van Bylandtlaan 16\'\nCity:The Hague\nState:2596HR\nCountry:NL\nCompany:EU Shell Headquareters\nIP Phone:31703779000\nDepartment: EU Natural Gas Operations\nManager:Wilson Moras','open');	
                        
   
}

    //serviceNowRequest('Software',Bdata,'1','1');
  });
  
  
  
$("body").on('click','.accessOptions',function(e){
 var Bdata=$(this).text();
    
    
    if(Bdata === 'Mover Access'){
        serviceNowMoverRequest('Movers','9aaef20bdbe1ba40a6fe735daf9619e3','Movers','UserID:John Smith\nStreet:\'403,Shell Headquarters Carel van Bylandtlaan 16\'\nCity:The Hague\nState:2596HR\nCountry:NL\nCompany:EU Shell Headquareters\nIP Phone:31703779000\nDepartment: EU Natural Gas Operations\nManager:Wilson Moras','open');	
                    
    }else{
        serviceNowRequest('Access',Bdata,'1','1');
    }
    
  });         


  
  
$("body").on('click','.access',function(){
   
   displayAccess();

  });          
  
  


$("body").on('click','.softwareOptions',function(e){
 var Bdata=$(this).text();
//console.log(Bdata);

    serviceNowRequest('Software',Bdata,'1','1');
  });



   $("body").on('click','.mover',function(){
    var botUserConversation = getBotUserConversations();
    //console.log("Console output--->>",botUserConversation);
    requestMapRequest('MapNetworkDrive','e668c2f0dba53640a6fe735daf96193e','MapNetworkDrive','UserName:NivRaj01\nShareName:\\\\10.136.105.39\\c$\\SharedFolder','open');
  });


function serviceNowMoverRequest(Item,assignment_group,u_item,short_description,state){
      
      
      botReply('rightPanel','I am going to raise a ticket for your concern');
      
      
      var conversation = '';
   getBotUserConversations(function(res){
        //console.log(JSON.parse(res));   
        var obj = JSON.parse(res);
         for (var i = 0; i < obj.activities.length; i++) {
                 var boolOption = obj.activities[i];
                 //console.log(boolOption.from.id + ":" + boolOption.text );
                 if(boolOption.from.id != 'MurexChatBot'){
                     conversation += boolOption.from.id + "-" + boolOption.text + '\n';
                 }
                 else if(boolOption.from.id === 'MurexChatBot'){
                    conversation += boolOption.from.id + "-" + JSON.parse(boolOption.text).msg + '\n';
                 }
                    }
               console.log(conversation); 
      
      
     $.ajax({
        url: baseurl_chat + '/postRequest',
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify({"Item": Item,"assignment_group": assignment_group,"u_item":u_item,"short_description":short_description,"state":state,"description":conversation}),
        success: function (res) {
             if (res.status) {
                botReply('rightPanel',"Please note the ticket Id: <span class='request_item' style='cursor:pointer;color:blue;' title='Click to check your ticket status.'>"+res.data+"</span>");
                 //console.log("I have raised the incident , please note the incident Id: "+res.data);
                 
               botReply('rightPanel',"The status will be updated shortly");  
               
               
                setTimeout( function(){  
                    
                    botReply('rightPanel','Status Update for ticket number : '+ res.data);
                    
                    
                    showRequestRecordByIdTimeOut(res.data);
                    
                    
                    },180000); 
               
                 
                 
                 
                 
            } else {
                //console.log(res.data);
            }
        }
    });
   });
      
  }


function displayAccess(){

botReply('rightPanel','You can raise the following Access requests'); 
var option_arr = ["File system Access", "Application Access","Smart Card Access", "Non Standard Access","Map Network Drive Access","Mover Access"];
var html='<div class="col-lg-12 col-md-12 col-sm-12 speechBubble bot radioOpt paddingLeft0">';
html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div>'
+'<div class="calloutDown"></div>';
 html += '<div class="divContainerDown softWareOptions"><ul>';
 	for(var i=0;i<option_arr.length;i++){
    var src = 'https://cdn2.iconfinder.com/data/icons/plump-by-zerode_/256/Folder-My-documents-icon.png';
    
    
    if(option_arr[i] === 'File system Access'){
        src = 'Images/filed-sys-access.png';
    }else if(option_arr[i] === 'Application Access'){
        src = 'Images/app-access.png';
    }else if(option_arr[i] === 'Smart Card Access'){
        src = 'Images/smartcardaccess.png';
    }else if(option_arr[i] === 'Non Standard Access'){
        src = 'Images/non-standardaccess.png';
    }else if(option_arr[i] === 'Map Network Drive Access'){
        src = 'Images/app-access.png';
    }else if(option_arr[i] === 'Mover Access'){
       src = 'Images/card_access.png'; 
    }
    
    
        
    html += '<li><div class="optionGrid">';
            html += '<div>';
                html += '<img src="' +  src + '" alt="install-printer width="40px" height="40px">';
           html += ' </div>';
            html += '<div class="radio accessOptions marginTopBottom5 marginLeft">';
                 html+='<label>'+option_arr[i]+'</label>';
            html += '</div>';
        html += '</div>';
    }
html+='</ul></div>';
html+='</div>';
$(rightPanel).append(html);
//scrollFunc();
$(rightPanel).stop().animate({ scrollTop: $(rightPanel)[0].scrollHeight}, 500); 


}

function displayAdmin(){
botReply('rightPanel','You can raise the following admin requests');
var option_arr = ["Travel Request", "Mover Request","Meeting Room", "AV Room", "Non Standard Access"];
var html='<div class="col-lg-12 col-md-12 col-sm-12 speechBubble bot radioOpt paddingLeft0">';
html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div>'
+'<div class="calloutDown"></div>';
 html += '<div class="divContainerDown softWareOptions"><ul>';
 	for(var i=0;i<option_arr.length;i++){
    var src = 'https://cdn2.iconfinder.com/data/icons/plump-by-zerode_/256/Folder-My-documents-icon.png';    
    
    if(option_arr[i] === 'Travel Request'){
       src = 'Images/travel_request.png'; 
    }else if(option_arr[i] === 'Mover Request'){
       src = 'Images/card_access.png'; 
    }else if(option_arr[i] === 'Meeting Room'){
        src = 'Images/meeting_room.png';
    }else if(option_arr[i] === 'AV Room'){
        src = 'Images/av-room.png';
    }else if(option_arr[i] === 'Non Standard Access'){
        src = 'Images/non-standardaccess.png';
    }
      
    html += '<li><div class="optionGrid">';
            html += '<div>';
                html += '<img src="' +  src + '" alt="install-printer width="40px" height="40px">';
           html += ' </div>';
            html += '<div class="radio adminOptions marginTopBottom5 marginLeft">';
                 html+='<label>'+option_arr[i]+'</label>';
            html += '</div>';
        html += '</div>';
    }
html+='</ul></div>';
html+='</div>';
$(rightPanel).append(html);
//scrollFunc();
$(rightPanel).stop().animate({ scrollTop: $(rightPanel)[0].scrollHeight}, 500);

}


function requestMapRequest(Item,assignment_group,u_item,short_description,state){
botReply('rightPanel','I am going to raise a ticket for your concern');


var conversation = '';
   getBotUserConversations(function(res){
        //console.log(JSON.parse(res));   
        var obj = JSON.parse(res);
         for (var i = 0; i < obj.activities.length; i++) {
                 var boolOption = obj.activities[i];
                 //console.log(boolOption.from.id + ":" + boolOption.text );
                 if(boolOption.from.id != 'MurexChatBot'){
                     conversation += boolOption.from.id + "-" + boolOption.text + '\n';
                 }
                 else if(boolOption.from.id === 'MurexChatBot'){
                    conversation += boolOption.from.id + "-" + JSON.parse(boolOption.text).msg + '\n';
                 }
                    }
               console.log(conversation); 



$.ajax({
        url: baseurl_chat + '/postRequest',
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify({"Item": Item,"assignment_group": assignment_group,"u_item":u_item,"short_description":short_description,"state":state,"description":conversation}),
        success: function (res) {
             if (res.status) {
                botReply('rightPanel',"Please note the ticket Id: <span class='request_item' style='cursor:pointer;color:blue;' title='Click to check your ticket status.'>"+res.data+"</span>");
                 //console.log("I have raised the incident , please note the incident Id: "+res.data);
            } else {
                //console.log(res.data);
            }
        }
    }); 
   });

}
  

  function serviceNowRequest(category,description,quantity,price){
      
      botReply('rightPanel','I am going to raise a request for your concern.');
      
      
      var conversation ='';
       getBotUserConversations(function(res){
        //console.log(JSON.parse(res));   
        var obj = JSON.parse(res);
         for (var i = 0; i < obj.activities.length; i++) {
                 var boolOption = obj.activities[i];
                 //console.log(boolOption.from.id + ":" + boolOption.text );
                 if(boolOption.from.id != 'MurexChatBot'){
                     conversation += boolOption.from.id + "-" + boolOption.text + '\n';
                 }
                 else if(boolOption.from.id === 'MurexChatBot'){
                    conversation += boolOption.from.id + "-" + JSON.parse(boolOption.text).msg + '\n';
                 }
                    }
               console.log(conversation); 
      
      
     $.ajax({
        url: baseurl_chat + '/postRequest',
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify({"short_description": description,"category": category,"quantity":quantity,"price":price,"description":conversation}),
        success: function (res) {
             if (res.status) {
                botReply('rightPanel',"Please note the ticket Id: <span class='request_item' style='cursor:pointer;color:blue;' title='Click to check your ticket status.'>"+res.data+"</span>");
                 //console.log("I have raised the incident , please note the incident Id: "+res.data);
            } else {
                //console.log(res.data);
            }
        }
    });
       });
  }
  

function displaySoftware(){

    //botReply('rightPanel','Following are the list of Softwares to meet your business needs');
var option_arr = ["MS Office Professional Plus 2016", "Adobe Acrobat DC Standard","Microsoft Office Project Standard", "Microsoft Visio Standard", "Quick_View_Plus_13"];
var html='<div class="col-lg-12 col-md-12 col-sm-12 speechBubble bot radioOpt paddingLeft0">';
html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div>'
+'<div class="calloutDown"></div>';
 html += '<div class="divContainerDown softWareOptions"><ul>';
 	for(var i=0;i<option_arr.length;i++){
    var src = 'https://cdn2.iconfinder.com/data/icons/plump-by-zerode_/256/Folder-My-documents-icon.png';
    
     if(option_arr[i] === 'MS Office Professional Plus 2016'){
        src = 'Images/microsoft_office_2016.png';
    }else if(option_arr[i] === 'Adobe Acrobat DC Standard'){
        src = 'Images/acrobat-reader.png';
    }else if(option_arr[i] === 'Microsoft Office Project Standard'){
        src = 'Images/microsoft_office_2016.png';
    }else if(option_arr[i] === 'Microsoft Visio Standard'){
        src = 'Images/microsoft_office_2016.png';
    }else if(option_arr[i] === 'Quick_View_Plus_13'){
        src = 'Images/visio.png';
    }
        
    html += '<li><div class="optionGrid">';
            html += '<div>';
                html += '<img src="' +  src + '" alt="install-printer width="40px" height="40px">';
           html += ' </div>';
            html += '<div class="radio softwareOptions marginTopBottom5 marginLeft">';
                 html+='<label>'+option_arr[i]+'</label>';
            html += '</div>';
        html += '</div>';
    }
html+='</ul></div>';
html+='</div>';
$(rightPanel).append(html);
//scrollFunc();
$(rightPanel).stop().animate({ scrollTop: $(rightPanel)[0].scrollHeight}, 500);
}


function displayHardware(id){
    
    botReply('rightPanel','Following are the list of hardware to meet your business needs, including phones, tablets and laptops');
    
   var html ='<div class="speechBubble bot">';
	html += '<div class="bot-pic">';
		html += '<img src="images/bot.png" alt="bot">';
		html += '<p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p>';
	html += '</div>';

	html += '<div class="calloutDown"></div>';
	html += '<div class="divContainerDown previewStep"> ';
        html += '<div class="previewBtn ">';
           html += '<div class="arrow downArrow"></div><div>Preview</div> ';
        html += '</div> ';   
        html += '<div class="previewContainer">';
            html += '<div><img src="Images/HP645.jpg" alt="macBook"></img></div>';
            html += '<div class="desc">HP PROBOOK 645 G1';
           html += ' </div>';
           html += ' <div><button type="button" class="btn btn-success hardwareoption1">Order</button></div>';
        html += '</div>    ';
    html += '</div>';
   

html += '</div>';


html +='<div class="speechBubble bot">';
	html += '<div class="bot-pic">';
		html += '<img src="images/bot.png" alt="bot">';
		html += '<p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p>';
	html += '</div>';

	html += '<div class="calloutDown"></div>';
	html += '<div class="divContainerDown previewStep"> ';
        html += '<div class="previewBtn ">';
           html += '<div class="arrow downArrow"></div><div>Preview</div> ';
        html += '</div> ';   
        html += '<div class="previewContainer">';
            html += '<div><img src="Images/MacBook-Pro.jpg" alt="macBook"></img></div>';
            html += '<div class="desc">HP ELITEBOOK FOLIO 1040 G1';
           html += ' </div>';
           html += ' <div><button type="button" class="btn btn-success hardwareoption2">Order</button></div>';
        html += '</div>    ';
    html += '</div>';
   

html += '</div>';


    
    $(rightPanel).append(html);
             scroller();
    
   loadPreviewToggle();
    
}

 function loadPreviewToggle(){
        //  $('.previewBtn').on('click', function(){

        //     if($(this).find('.leftArrow').length==0)
        //     {
        //         $('.previewBtn > .arrow').addClass('leftArrow');
        //         $('.previewBtn > .arrow').removeClass('downArrow');
        //         $('.previewBtn + .previewContainer').fadeOut();
        //     }
        //     else
        //     {
        //          $('.previewBtn > .arrow').addClass('downArrow');
        //          $('.previewBtn > .arrow').removeClass('leftArrow');
        //          $('.previewBtn + .previewContainer').fadeIn();
        //     }
        // });
    }
$("body").on('click','.hardwareoption1',function(){
    
    
    
     var conversation ='';
       getBotUserConversations(function(res){
        //console.log(JSON.parse(res));   
        var obj = JSON.parse(res);
         for (var i = 0; i < obj.activities.length; i++) {
                 var boolOption = obj.activities[i];
                 //console.log(boolOption.from.id + ":" + boolOption.text );
                 if(boolOption.from.id != 'MurexChatBot'){
                     conversation += boolOption.from.id + "-" + boolOption.text + '\n';
                 }
                 else if(boolOption.from.id === 'MurexChatBot'){
                    conversation += boolOption.from.id + "-" + JSON.parse(boolOption.text).msg + '\n';
                 }
                    }
               console.log(conversation); 
    
    
     $.ajax({
    url: baseurl_chat + '/postRequest',
    type: 'POST',
    contentType: "application/json",
    data: JSON.stringify({"short_description":"HP ELITEBOOK FOLIO 1040 G1","description": conversation,"category": 'hardware',"quantity":'1',"price":'500',"description":conversation}),
    success: function (res) {
         if (res.status) {
            botReply('rightPanel',"Thank You  for ordering a new laptop , please note the ticket Id: <span class='request_item' style='cursor:pointer;color:blue;' title='Click to check your ticket status.'>"+res.data+"</span>");
             //console.log("I have raised the incident , please note the incident Id: "+res.data);
        } else {
            //console.log(res.data);
        }
    }
});
       });
  });
  
  $("body").on('click','.hardwareoption2',function(){
    
    
     var conversation ='';
       getBotUserConversations(function(res){
        //console.log(JSON.parse(res));   
        var obj = JSON.parse(res);
         for (var i = 0; i < obj.activities.length; i++) {
                 var boolOption = obj.activities[i];
                 //console.log(boolOption.from.id + ":" + boolOption.text );
                 if(boolOption.from.id != 'MurexChatBot'){
                     conversation += boolOption.from.id + "-" + boolOption.text + '\n';
                 }
                 else if(boolOption.from.id === 'MurexChatBot'){
                    conversation += boolOption.from.id + "-" + JSON.parse(boolOption.text).msg + '\n';
                 }
                    }
               console.log(conversation); 
    
    
     $.ajax({
    url: baseurl_chat + '/postRequest',
    type: 'POST',
    contentType: "application/json",
    data: JSON.stringify({"short_description":"HP PROBOOK 645 G1","description": conversation,"category": 'hardware',"quantity":'1',"price":'500'}),
    success: function (res) {
         if (res.status) {
            botReply('rightPanel',"Thank You  for ordering a new laptop , please note the ticket Id: <span class='request_item' style='cursor:pointer;color:blue;' title='Click to check your ticket status.'>"+res.data+"</span>");
             //console.log("I have raised the incident , please note the incident Id: "+res.data);
        } else {
            //console.log(res.data);
        }
    }
});
  });
  });
  
function showIncidentRecordById(id, dtype){
    console.log(dtype);
    var myUrl = (dtype === 'TASK')?baseurl_chat + '/reqItem':baseurl_chat + '/inciItem';
    $.ajax({
    url: myUrl, //baseurl_chat+'/inciItem',
    type: 'GET',
    contentType: "application/json",
    data: {"itemId":id,"type":dtype},
    success: function (res) {
        if (res.status) {
             //console.log(res.data);
             createIncidentCard('rightPanel',res.data);
             
           
             
             
        } else {
            //console.log(res.data);
        }
    }
});
    
    
}


function getBotUserConversations(callback){

    //var ret ;
     $.ajax({
    url: baseurl_chat + '/getconversation',
    type: 'GET',
    contentType: "application/json",
    data: {"userId":'chesta'},
    success: function (res) {
        if (res.status) {
            callback(res.data)
        } else {
            callback(res.data);
        }
    }
});
     
    
}





function createIncidentCard(id,data){


botReply('rightPanel','Here is the status for your ticket.');
console.log(data);
var html = '<div class="speechBubble bot">';
	html += '<div class="bot-pic">';
		html += '<img src="images/bot.png" alt="bot">';
		html += '<p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+ '</p>';
	html += '</div>';

	html += '<div class="divContainerDown ticketQueue"> ';
		html += '<div class="header">';
			html += '<div>';
				html += '<p class="title">Status for your ticket</p>';
				
			html += '</div>';
		html += '</div>';
		html += '<div class="content">';
		html += '<div class="row marginLeftRight0 ">';
			html += '<div class="col-lg-4 col-md-3 col-sm-3">';
				html += '<h6 class="sub">Number</h6>';
				html += '<h5>'+data[0].number+'</h5>';
			html += '</div>';
			html += '<div class="col-lg-4 col-md-3 col-sm-3">';
				html += '<h6>Request State</h6>';
				html += '<h5>'+getStateDesc(data[0].state)+'</h5>';
			html += '</div>';
			html += '<div class="col-lg-4 col-md-3 col-sm-3">';
				html += '<h6>State</h6>';
				html += '<h5>'+getStateDesc(data[0].state)+'</h5>';
			html += '</div>';
		html += '</div>';
		html += '<div class="row marginLeftRight0 ">';
		 	html += '<div class="col-lg-4 col-md-3 col-sm-3">';
		 		html += '<h6 class="sub">Priority</h6>';
		 		html += '<h5> '+getPriorityDesc(data[0].priority)+'</h5>';
		 	html += '</div>';
		 	html += '<div class="col-lg-4 col-md-3 col-sm-3">';
		 		html += '<h6>Last Update</h6>';
		 		html += '<h5>'+data[0].sys_updated_on+'</h5>';
		 	html += '</div>';

		 html += '</div>';
		html += '<div class="row marginLeftRight0">';
			html += '<div class="col-lg-4 col-md-3 col-sm-3">';
				html += '<h6 class="sub">Description</h6>';
				html += '<h5>'+data[0].short_description+'</h5>';
			html += '</div>';
            html += '<div class="col-lg-4 col-md-3 col-sm-3">';
		 		html += '<h6>Created At</h6>';
		 		html += '<h5>'+data[0].sys_created_on+'</h5>';
		 	html += '</div>';
		html += '</div>';
		html += '</div>';
	html += '</div>';
html += '</div>';

$(rightPanel).append(html);
$(rightPanel).stop().animate({ scrollTop: $(rightPanel)[0].scrollHeight}, 500);


}


function showLogIncidentForm(id){
   getBotUserConversations(function(res){
        //console.log(JSON.parse(res));   
        var obj = JSON.parse(res);
        var conversation = '';
        var userConversation = [];
         for (var i = 0; i < obj.activities.length; i++) {
                 var boolOption = obj.activities[i];
                 console.log(boolOption);
                 //console.log("Options : " + boolOption.text);
                 conversation += boolOption.from.id + ":" + boolOption.text + '\n';
                 
                 if(boolOption.from.id != 'MurexChatBot'){
                     
                     userConversation.push(boolOption.text);
                     
                 }
                 
                    }
                    
                    
                    
    botReply('rightPanel','Do you want to update your ticket with the following information?');
    var html='<div class="speechBubble bot">';
        html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div>'
	        html += '<div class="calloutDown blue"></div>';
	
	  //  html += '<div class="divContainerDown raiseIncident"> ';
		//  html += '<p class="heading"> Raise an Incident</p>';
			//html += '<hr>';
            html += '<div class="divContainerDown ticketQueue marginLeft0"> ';
		    html += '<div class="header">';
			html += '<div>';
				html += '<p class="title" id="changeTitleRT">Raise Ticket</p>';      							
			html += '</div>';
		   html += '</div>';
		    //html += '<form class="form padding5">';
			html += '<div class="form-group paddingLeftRight15">';
				html += '<label for="inci_desc">Description</label><br>';
				html += '<textarea class="inci_desc"></textarea>';
			html += '</div>	';
			
			//html += '<div class="form-group row marginLeft0">';							
				//html += '<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 paddingLeftRight0 marginBottom10">';
				// 	html += '<label for="inci_impact">Impact</label>';
				// 	html += '<select class="inci_impact">';
				// 		html += '<option>1</option>';
				// 		html += '<option>2</option>';
				// 		html += '<option>3</option>';
				// 	html += '</select>';
				// html += '</div>';
				
				// html += '<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 paddingLeftRight0 marginBottom10">';
				// 	html += '<label for="inci_urgency">Urgency</label>';
				// 	html += '<select class="inci_urgency">';
				// 		html += '<option>1</option>';
				// 		html += '<option>2</option>';
				// 		html += '<option>3</option>';
				// 	html += '</select>';
				// html += '</div>	';
			//html += '</div>';
			
			html += '<div class="form-group paddingLeftRight15">';
				html += '<button class="btn btn-default inci_submit">Update</button>';
			html += '</div>';	
			//html += '</form>';
	html += '</div>';
    html += '</div></div>';
    
    
   $(".divContainerDown raiseIncident").remove(); 
   $(rightPanel).append("<br>" + html);
   $(rightPanel).stop().animate({ scrollTop: $(rightPanel)[0].scrollHeight}, 500);        
   if(window.localStorage.getItem('id')){
       $("#changeTitleRT").html("Update Ticket");
       $(".inci_submit").html("Update Ticket");
       
   }         
                    
                    
   });
    
    
}
//form handles
$("body").on('click','.inci_submit',function(){
   var  des=$(".inci_desc").val();
    var  urg=$(".inci_urgency").val();
     var  imp=$(".inci_urgency").val();
   var conversation = '';
   getBotUserConversations(function(res){
        //console.log(JSON.parse(res));   
        var obj = JSON.parse(res);
         for (var i = 0; i < obj.activities.length; i++) {
                 var boolOption = obj.activities[i];
                 //console.log(boolOption.from.id + ":" + boolOption.text );
                 if(boolOption.from.id != 'MurexChatBot'){
                     conversation += boolOption.from.id + "-" + boolOption.text + '\n';
                 }
                 else if(boolOption.from.id === 'MurexChatBot'){
                    conversation += boolOption.from.id + "-" + JSON.parse(boolOption.text).msg + '\n';
                 }
                    }
               console.log(conversation);  
                           // conversation = 'chesta-noMurexChatBot-It looks like my suggestions havent been helpful. I am trying to improve my knowledge.MurexChatBot-We would like to ensure you received the support you expected and that your problem was solved or your questions answered.MurexChatBot-Click to callMurexChatBot-Click to chatMurexChatBot-Schedule a callbackMurexChatBot-Log a new incident';
               var obj={"short_description": des,"urgency": urg,"impact":imp,"u_chatbot_worknotes":conversation};
               if(window.localStorage.getItem('id')){
                   console.log("Update true");
                   var idToUpdate=window.localStorage.getItem('id');;
                   
                   
                   $("#changeTitleRT").html("Update Ticket");
                   $(".inci_submit").html("Update Ticket");
                   obj.update=true;
                   obj.number=idToUpdate;
                   //window.localStorage.removeItem("id");
               }
               
                  $.ajax({
                url: baseurl_chat+'/postIncident',
                type: 'POST',
                contentType: "application/json",
                data: JSON.stringify(obj),
                success: function (res) {
                    //botReply('rightPanel',"I have raised the incident , please note the incident Id: "+res.data);
                    
                    // if (res.status) {
                        if(obj.update){
                            botReply('rightPanel',"I have updated the incident , please note the incident Id: <span class='incident_item' style='cursor:pointer;color:blue;' title='CLick to check your ticket status.'>"+idToUpdate+"</span>");
                        }else{
                            botReply('rightPanel',"I have raised the incident , please note the incident Id: <span class='incident_item' style='cursor:pointer;color:blue;' title='CLick to check your ticket status.'>"+idToUpdate+"</span>");
                        }
                       window.localStorage.removeItem("id"); 
                         //console.log("I have raised the incident , please note the incident Id: "+res.data);
                    // } else {
                    //     //console.log(res.data);
                    // }
                }
            });   
            
            
//          var id = localStorage.getItem("id");   
//          console.log(id);
//     $.ajax({
//     url: baseurl_chat+'/updateIncident',
//     type: 'PUT',
//     contentType: "application/json",
//     data: JSON.stringify({"id":id,"short_description": des,"urgency": urg,"impact":imp,"u_chatbot_worknotes":conversation}),
//     success: function (res) {
//         //botReply('rightPanel',"I have raised the incident , please note the incident Id: "+res.data);
        
//         if (res.status) {
//             botReply('rightPanel',"I have raised the incident , please note the incident Id: <span class='incident_item' style='cursor:pointer;color:blue;' title='CLick to check your ticket status.'>"+res.data+"</span>");
//              console.log("I have raised the incident , please note the incident Id: "+res.data);
//         } else {
//             console.log(res.data);
//         }
//     }
// });
            
            
            
            
   });
   
   
     
});
                
 
function closeTicket(){
    var  des=$(".inci_desc").val();
    var  urg=$(".inci_urgency").val();
     var  imp=$(".inci_urgency").val();
   var conversation = '';
   getBotUserConversations(function(res){
        //console.log(JSON.parse(res));   
        var obj = JSON.parse(res);
         for (var i = 0; i < obj.activities.length; i++) {
                 var boolOption = obj.activities[i];
                 if(boolOption.from.id != 'MurexChatBot'){
                     conversation += boolOption.from.id + "-" + boolOption.text + '\n';
                 }
                 else if(boolOption.from.id === 'MurexChatBot'){
                    conversation += boolOption.from.id + "-" + JSON.parse(boolOption.text).msg + '\n';
                 }
                    }
               var obj={"short_description": des,"urgency": urg,"impact":imp,"u_chatbot_worknotes":conversation};
               if(window.localStorage.getItem('id')){
                   console.log("Update true");
                   var idToUpdate=window.localStorage.getItem('id');;
                   obj.update=true;
                   obj.number=idToUpdate;
                   obj.state = '4';
               }
               
                  $.ajax({
                url: baseurl_chat+'/postIncident',
                type: 'POST',
                contentType: "application/json",
                data: JSON.stringify(obj),
                success: function (res) {
                        if(obj.update){
                            botReply('rightPanel',"I have closed the incident , please note the incident Id: <span class='incident_item' style='cursor:pointer;color:blue;' title='CLick to check your ticket status.'>"+idToUpdate+"</span>");
                        }else{
                            botReply('rightPanel',"I have closed the incident , please note the incident Id: <span class='incident_item' style='cursor:pointer;color:blue;' title='CLick to check your ticket status.'>"+idToUpdate+"</span>");
                        }
                       window.localStorage.removeItem("id"); 
                }
            });   
   });
} 
 
 
                
//web sockets for handle conversations

function initWebSocket(tokenDetail) {
    tokenDetail = JSON.parse(tokenDetail);
    
    botSocket = new WebSocket(tokenDetail.streamUrl);
    botSocket.onopen = function ()
    {
        //console.log("connection is open...");
        //console.log(botSocket);
    };

    botSocket.onmessage = function (evt)
    {
        //console.log(evt)
        if (evt.data === '') {
            return;
        } else {
            var received_msg = JSON.parse(evt.data);
            var allMsg = received_msg.activities;
            //console.log("Message received--->>>",received_msg);
            if (received_msg.hasOwnProperty('watermark') ) {
                var len = received_msg.activities.length;
                //console.log(len);
                if(typeof allMsg[len - 1].text != 'undefined'){
                    var jsonData = JSON.parse(allMsg[len - 1].text);
                    console.log(jsonData);
                    // for cancel meeting 
                    
                    
                    
                    
                    if(jsonData.type == 'boolean'){
                        var optionsArray = [];
                        for (var i = 0; i < jsonData.Options.length; i++) {
                            var boolOption = jsonData.Options[i];
                           optionsArray.push(radioOption);
                           //console.log("Options : " + boolOption);
                        }
                        
                        bot_booleanOption('rightPanel',jsonData.msg);
                        
                    }
                    try{
                        checkCategory(jsonData.category);
                    }catch(e){
                        console.log(e)
                        //console.log(e);
                    }
                    if(jsonData.type==='meetingCancel'){
                        var meeting=jsonData.meeting;
                        var day=jsonData.day;
                        cancelMeetingFromChat(meeting,day);
                    }
                    if(jsonData.type == 'radioOption'){
                        //console.log("Entered");
                        var optionsArray = [];
                        for (var i = 0; i < jsonData.Options.length; i++) {
                            var radioOption = jsonData.Options[i].Option;
                            //console.log("Options;" + radioOption);
                            optionsArray.push(radioOption);
                        }
                        radio_button_options('rightPanel',optionsArray,jsonData.msg, 'printer');
                       
                    }
                    
                     if(jsonData.type == 'Steps'){
                        //console.log("Entered");
                        var optionsArray = [];
                        for (var i = 0; i < jsonData.Options.length; i++) {
                            var radioOption = jsonData.Options[i].Option;
                            //console.log("Options;" + radioOption);
                            optionsArray.push(radioOption);
                        }
                        bot_steps_Reply('rightPanel',optionsArray,jsonData.msg);
                        
                    }                           
                    if(jsonData.type == 'message'){
                        //console.log(jsonData.msg);
                        botReply('rightPanel',jsonData.msg);
                        if(jsonData.hasOwnProperty('id')){
                            window.localStorage.setItem('id',jsonData.id);
                            //jsonData.id;
                            botReply('rightPanel',"I have raised the issue, please note the ticket Id:<span class='incident_item' style='cursor:pointer;color:blue;' title='Click to check your ticket status.'>"+jsonData.id+"</span>");
                        }
                        
                        
                    } 
                    //for screenshot upload
                     if(jsonData.type==='screenshot'){
                        screenShot('rightPanel',jsonData.msg);
                    }
                    //display sample screen for windows ip address
                    if(jsonData.type==='windowsSample')
                    {
                        winSample('rightPanel',jsonData.msg);
                    }
                    
                    //display sample screen for windows ip address
                    if(jsonData.type==='macSample')
                    {
                        macSample('rightPanel',jsonData.msg);
                    }
                    
                    //for displaying ip address image
                    if(jsonData.type==='ipaddress'){
                        ipAddress('rightPanel',jsonData.msg);
                    }
                    
                   if(jsonData.type == 'Card'){
                       
                       //console.log("Summary--->",jsonData.summary);
                       console.log(jsonData.url)
                       card_display("rightPanel",jsonData.url,jsonData.msg);
          
                     }
                     if(jsonData.type == 'RACard'){
                       console.log("RACard");
                       //console.log("Summary--->",jsonData.summary);
                       RAcard_display("rightPanel",jsonData.url,jsonData.msg,jsonData.doc_id);
          
                     }
                   if(jsonData.type == 'calendar'){
                       //botReply('rightPanel',jsonData.msg);
                       //display_calendar('rightPanel');
                       botReply('rightPanel','Here is your calendar for the week.');
                         loadCalender();
                     }  
                   if(jsonData.type == 'news'){
                       
                       //botReply('rightPanel',jsonData.msg);
                       //botReply('rightPanel','Here are the Top International News');
                       getNews();
          
                    }
                    
                    if(jsonData.type == 'weather'){
                       
                       botReply('rightPanel',jsonData.msg);
                       botWeatherCard(function(current,forcast){
                       placeWeatherDetails(current);
                        });
          
                    }
                    
                    
                    if(jsonData.type == 'mostused'){
                       
                      showMostUsedApps($(".most_used_tab"));
          
                    }
                    
                    
                    if(jsonData.type == 'workspace'){
                       
                       
                       display_workspace('rightPanel');
          
                    }
                    
                    
                    if(jsonData.type == 'application'){
                       
                       botReply('rightPanel',jsonData.msg);
                       //display_workspace('rightPanel');
                       window.open(jsonData.app);
          
                    }
                    
                    
                    if(jsonData.type == 'report'){
                       botReply('rightPanel',jsonData.msg);
                       getReports();
          
                    }
                    if(jsonData.type == 'statistics'){
                       //console.log("statisccsscscs");
                       botReply('rightPanel',jsonData.msg);
                       //pass entity to show title
                       appendStateDiv("incident");
          
                    }
                    if(jsonData.type == 'systeminfo'){
                      botReply('rightPanel',jsonData.msg);
                      requestSystemService('SystemInfo','9aaef20bdbe1ba40a6fe735daf9619e3','SystemInfo','HostName:DICHPSHEWI2K801','open');
                    }
                    
                    if(jsonData.type == 'mapdrive'){
                      botReply('rightPanel',jsonData.msg);
                      requestMapRequest('MapNetworkDrive','e668c2f0dba53640a6fe735daf96193e','MapNetworkDrive','UserName:NivRaj01\nShareName:\\\\10.136.105.39\\c$\\SharedFolder','open');
                    }
                    
                    if(jsonData.type == 'hardwarereq'){
                      botReply('rightPanel',jsonData.msg);
                      //radio_button_options('rightPanel',["Order New Hardware","Raise System Information Request"],"What would you like me to do?");
                      displayHardware('rightPanel');
                    }
                    
                     if(jsonData.type == 'softwarereq'){
                      botReply('rightPanel',jsonData.msg);
                      displaySoftware();
                    }
                    
                    if(jsonData.type == 'yesClose'){
                      botReply('rightPanel',jsonData.msg);
                      closeTicket();
                      
                    }
                    
                    if(jsonData.type === 'updateTicket'){
                         $(".inci_submit").click();
                    }
                    
                    
                    if(jsonData.type === 'showEvent'){
                         var dateCal = jsonData.date;
                         var showToEvent=getOutlookCalenderFilter(dateCal);
                         var arr=[];
                         for(var i=0;i<showToEvent.length;i++){
                             var a=new Date(showToEvent[i].Start);
                             a=a.toTimeString();
                             a=a.split(":")[0]+":"+a.split(":")[0];
                             arr.push(showToEvent[i].Subject+" at "+a);
                         }
                         if(arr.length===0){
                             botReply('rightPanel',"You have no meeting planned on "+dateCal);
                         }else{
                             //bot reply here
                             botReply('rightPanel',"These are the events for  "+dateCal);
                             radio_button_options('rightPanel',arr,"Can you please specify the event?",'Event'); 
                         }
                         
                    }
                    
                    //  if(jsonData.type == 'Shell news'){
                    //  OnlySHellNews();
                      
                    // }
                    //  if(jsonData.type == 'IT news'){
                    //   addCustomITNews();
                    // }
                    if(jsonData.type == 'International news'){
                     getInternationalNews();
                      
                    }
                    
                    
                    
                    
                     if(jsonData.type == 'skype'){
                      botReply('rightPanel',jsonData.msg);
                      window.open("skype:live:murexsd1?call");
                      
                        //var idToUpdate=window.localStorage.getItem('id');;
                    }
                    
                    
                    if(jsonData.type == 'skypeques'){
                      botReply('rightPanel',jsonData.msg);
                      //window.open("skype:live:murexsd1?call");
                      
                        var idToUpdate=window.localStorage.getItem('id');
                        botReply('rightPanel',idToUpdate);
                        
                    }
                    
                    
                    if(jsonData.type == 'shellopen'){
                      botReply('rightPanel',jsonData.msg);
                      window.open("http://www.shell.com/");
                    }
                    
                    
                   /* if(jsonData.type == 'office'){
                      botReply('rightPanel',jsonData.msg);
                      window.open("https://office.live.com/start/Word.aspx");
                      
                      
                    }*/
                    /****Adding seprate apps for office applications
                     * Doing it using intents now but to be taken care with entity later
                    *** */
                      if(jsonData.type == 'word_office'){
                      botReply('rightPanel',jsonData.msg);
                      window.open("https://office.live.com/start/Word.aspx");
                    }
                       if(jsonData.type == 'excel_office'){
                      botReply('rightPanel',jsonData.msg);
                      window.open("https://office.live.com/start/Excel.aspx");
                    }
                      if(jsonData.type == 'powerpoint_office'){
                      botReply('rightPanel',jsonData.msg);
                      window.open("https://office.live.com/start/powerpoint.aspx");
                    }
                     
                     
                     /**************************** end office apps*/
                     if(jsonData.type == 'callback'){
                      botReply('rightPanel',jsonData.msg + ' ' + jsonData.time);
                     
                    }
                    
                    if(jsonData.type == 'softwareinstall'){
                      botReply('rightPanel',jsonData.msg);
                      serviceNowRequest('Software',jsonData.software,'1','1');
                    }
                     if(jsonData.type == 'adminreq'){
                      //botReply('rightPanel',jsonData.msg);
                      displayAdmin();
                    }
                    
                    
                     if(jsonData.type == 'incidentticket'){
                     
                     if(jsonData.ticket.substr(0,3) === 'inc'){
                         
                        showIncidentRecordById(jsonData.ticket); 
                         
                     }else if(jsonData.ticket.substr(0,4) === 'task'){
                          showRequestRecordById(jsonData.ticket);
                     }
                     
                  
                                                          
                    }
                    
                    
                    if(jsonData.type == 'ticket'){
                     
                     botReply('rightPanel',jsonData.msg);
                                                          
                    }
                    
                    
                     if(jsonData.type == 'taskticket'){
                     if(jsonData.ticket.substr(0,3) === 'inc'){
                         
                        showIncidentRecordById(jsonData.ticket); 
                         
                     }else if(jsonData.ticket.substr(0,4) === 'task'){
                          showRequestRecordById(jsonData.ticket);
                     }
                    }
                    
                     if(jsonData.type == 'accessreq'){
                         
                         if(jsonData.accesstype === 'default'){
                             displayAccess();
                         }else {
                             
                             serviceNowRequest('Access',jsonData.accesstype,'1','1');
                             
                         }
                         
                      
                    }
                    
                    if(jsonData.type == 'admintype'){
                      
                      if(jsonData.admin === 'travel'){
                          
                          botReply('rightPanel','Where are you travelling?');
                          //travelForm('Please tell me the date for your travel');
                          
                      }else if(jsonData.admin === 'premise'){
                          
                           serviceNowMoverRequest('Movers','9aaef20bdbe1ba40a6fe735daf9619e3','Movers','UserID:Mike Jordan\nStreet:\'403,Shell Headquarters Carel van Bylandtlaan 16\'\nCity:The Hague\nState:2596HR\nCountry:NL\nCompany:EU Shell Headquareters\nIP Phone:31703779000\nDepartment: EU Natural Gas Operations\nManager:Wilson Moras','open');	
                          
                      }
                      
                      else{
                          
                          serviceNowRequest('Admin',jsonData.admin,'1','1');	
                          
                      }
                      
                    }
                    
                    
                    
                    if(jsonData.type == 'travel'){
                       //botReply('rightPanel',jsonData.msg);
                      
                      cityName = jsonData.city;
                     travelForm(jsonData.msg,jsonData.city);
          
                    }
                    
                    
                     if(jsonData.type == 'request'){
                       botReply('rightPanel',jsonData.msg);
                      
                       
                      $.get('ServiceOption.html', function(data){                     
                       $(rightPanel).append(data);   
                       $(rightPanel).find('.setTime .msgTime').text(formatAMPM(new Date()).split(" ")[0]);                                            
                      });
                      
                      
                               scroller();
                       
                       
                       
                       //display_calendar('rightPanel');
                     } 
                    
                    
                    
                     
                    //$(".murex-status").html("Connected");
                     $('.displayTime > .status').addClass('connected').removeClass('unconnected');
                }
                
            }


        }
    };
    botSocket.onclose = function ()
    {
        //console.log("in closse")
       // $(".murex-status").html("Connection lost.. ");
        //call to regenerate the token for exiting conversation
          $('.displayTime > .status').addClass('unconnected').removeClass('connected');
        // $('#murex_status_image_connect').css('display','none');
        // $('#murex_status_image_unconnect').css('display','inline-block');
         //refreshToke();
    };
}
function checkCategory(cat){
    $(".list-group li").removeClass("active");
    if(cat==='My News'){
        $($(".list-group li")[0]).addClass('active')
    }else if(cat==='My Calendar'){
        $($(".list-group li")[1]).addClass('active');
       
    }else if(cat==='My workspace'){
        $($(".list-group li")[2]).addClass('active')
    }else if(cat==='Resolve Now'){
        $($(".list-group li")[3]).addClass('active')
    }else if(cat==='Request Now'){
        $($(".list-group li")[4]).addClass('active')
    }else if(cat==='Report Now'){
        $($(".list-group li")[5]).addClass('active')
    }
}
                /*function refreshToke(){
                    
                    $.ajax({
                        url: baseurl_chat+'/refreshToken',
                        type: 'POST',
                        contentType: "application/json",
                        data: JSON.stringify({userId: userName}),
                        success: function (res) {
                            if (res.status) {
                                console.log(res);
                                 $('#murex_status_image_connect').css('display','inline-block');
                                 $('#murex_status_image_unconnect').css('display','none');
                                console.log(res.tokenDetail)
                                initWebSocket(res.tokenDetail);                                
                            } else {
                                alert(res.msg);
                            }
                        }
                    });
                }*/
function getNews(){
    
    $.ajax({
            url:baseurl_chat+'/getNews',
            type: 'GET',
            contentType: "application/json",
            success: function (res) {
             //  botReply('rightPanel','Here are the Top IT News'); 
              // addCustomITNews("rightPanel",JSON.parse(res.data).articles);
                        scroller();
                makeNewsCard("rightPanel",JSON.parse(res.data).articles);
            }
        });
        
        
        
}


function getInternationalNews(){
    
    $.ajax({
            url:baseurl_chat+'/getNews',
            type: 'GET',
            contentType: "application/json",
            success: function (res) {
             //  botReply('rightPanel','Here are the Top IT News'); 
              // addCustomITNews("rightPanel",JSON.parse(res.data).articles);
                        scroller();
                makeInterNewsCard("rightPanel",JSON.parse(res.data).articles);
            }
        });
        
        
        
}


                
                
function travelForm(msg,city){
    
    
     var html='<div class="col-lg-12 col-md-12 col-sm-12 speechBubble bot radioOpt paddingLeft0">';
        				html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div>'
                        +'<div class="calloutDown"></div>';
        				 html += '<div class="divContainerDown">';
                         html += '<b>Trip to ' + city +'</b><br>';
                        html += '<span>'+ msg + ':' +'</span><br>';
                        html += '<input type="date" name="bday" id="travelDate" class="marginTop10"><br>';
                         // html += '<input type="text" id="travelDate" name="bday"><br>';
                         html += '<button class="btn btn-default travelSubmit marginTop10">Submit</button>';
                      html += '</div></div>';
                      $(rightPanel).append(html);
                               scroller();
    
}
                
function timeOfDay(){
    var myDate = new Date();
    /* hour is before noon */
    if ( myDate.getHours() < 12 )  
    { 
        return("Good Morning"); 
    } 
    else  /* Hour is from noon to 5pm (actually to 5:59 pm) */
    if ( myDate.getHours() >= 12 && myDate.getHours() <= 17 ) 
    { 
        return("Good Afternoon"); 
    } 
    else  /* the hour is after 5pm, so it is between 6pm and midnight */
    if ( myDate.getHours() > 17 && myDate.getHours() <= 24 ) 
    { 
        return("Good Evening"); 
    } 
    else  /* the hour is not between 0 and 24, so something is wrong */
    { 
        return("I'm not sure what time it is!"); 
    } 
      
    
    
}
function display_workspace(id){
    //console.log("Here I come");
    botReply('rightPanel','Find all your applications here in the Application Dashboard');
    var html= '<div class="speechBubble bot">';
                html += '<div class="bot-pic">';
	               html +='<img src="images/bot.png" alt="bot">';
	               html += '<p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p>';
               html +='</div>';

html += '<div class="calloutDown"></div>';
html += '<div class="divContainerDown workspace">'; 
 html += '<div class="most_used">';
 html += '<p><span class="most_used_tab">MOST USED</span></p><p><span class="selected all_applications_tab">ALL APPLICATIONS</span></p>';
 html += '</div>';
html += '<div class="bubble_content row">';

html += '<div>';
//	 html += '<div class="service_now">';
//html += '<button type="submit" class="button_service_now"><p class="button_text_servicenow">Service now<img src="Images/Service-Arrow.png" style="margin-left:10px;"/></p></button>';
// html += '</div>';
html += '</div>';




// html += '<ul class="list-group content_left">  ';
//   html += '<p class="marginLeft15"><span>CATEGORIES</span></p>';
//   html += '<li class="list-group-item"><span class="paddingLeft10">Business</span></li>';
//   //html += '<li class="list-group-item"><span class="paddingLeft10">Enertainment</span></li>';
//   //html += '<li class="list-group-item"><span class="paddingLeft10">Finance</span></li>';
//   //html += '<li class="list-group-item"><span class="paddingLeft10">Productivity</span></li>';
//   //html += '<li class="list-group-item"><span class="paddingLeft10">Social Networking</span></li>';
//   //html += '<li class="list-group-item"><span class="paddingLeft10">Travel</span></li>';
//   html += '<li class="list-group-item"><span class="paddingLeft10">Utilities</span></li>';
// html += '</ul>';


html += '</div>';

html += '<div class="content_right">';

html += '<div class="exploration_insight">';
html += '<img class="ultimatix" src="Images/jreview.png" >';
html += '<div class="bottom_content_exploration_insight">';
html += '<span class="vAlign ultimatix">Jreview</span>';
html += '</div>';
html += '</div>';



html += '<div class="sapMM">';
html += '<img class="sap" src="Images/cdr.png" >';
html += '<div class="bottom_content_sapMM">';
html += '<span class="vAlign sap">CDR</span>';
html += '</div>';
html += '</div>';

html += '<div class="sapWM most_used_app">';
html += '<img src="Images/clinergize_logo.png" >';
html += '<div class="bottom_content_sapWM">';
html += '<span class="vAlign tcs">Clinergize</span>';
html += '</div>';
html += '</div>';

// html += '<div class="primavera most_used_app">';
// html += '<img src="Images/Primavera.png">';
// html += '<div class="bottom_content_primavera">';
// html += '<span class="vAlign primavera">Primavera</span>';
// html += '</div>';
// html += '</div>';


html += '<div class="meriduim">';
html += '<img src="Images/bictms.png">';
html += '<div class="bottom_content_meriduim">';
html += '<span class="vAlign fresco">BICTMS</span>';
html += '</div>';
html += '</div>';


html += '<div class="smartTransform clearFloat">';
html += '<img src="Images/oracle_clinical.png" >';
html += '<div class="bottom_content_smartTransform">';
html += '<span class="vAlign">Oracle Clinical</span>';
html += '</div>';
html += '</div>';

html += '<div class="OSIsoft ">';
html += '<img src="Images/go_track.png" class="width90perc">';
html += '<div class="bottom_content_OSIsoft">';
html += '<span class="vAlign osi">Go Track</span>';
html += '</div>';
html += '</div>';

html += '<div class="smartplant">';
html += '<img src="Images/smartplant.png" class="width90perc">';
html += '<div class="bottom_content_smartplant">';
html += '<span class="vAlign">SmartPlant Ent.</span>';
html +='</div>';
html +='</div>';

html += '<div class="powerpoint most_used_app">';
html += '<img class="office365" src="Images/powerpoint_icon.png" >';
html += '<div class="bottom_content_exploration_insight">';
html += '<span class="vAlign office365">MS Powerpoint</span>';
html += '</div>';
html += '</div>';

html += '<div class="powerpoint clearFloat">';
html += '<img class="skypeWork" src="Images/skype_icon.png" >';
html += '<div class="bottom_content_exploration_insight">';
html += '<span class="vAlign skypeWork">Skype</span>';
html += '</div>';
html += '</div>';

html += '<div class="powerpoint">';
html += '<img class="office365" src="Images/Word_icon.png" >';
html += '<div class="bottom_content_exploration_insight">';
html += '<span class="vAlign office365">MS Word</span>';
html += '</div>';
html += '</div>';

html += '<div class="powerpoint most_used_app">';
html += '<img class="office365" src="Images/Outlook_icon.png" >';
html += '<div class="bottom_content_exploration_insight">';
html += '<span class="vAlign office365">MS Outlook</span>';
html += '</div>';
html += '</div>';

html += '<div class="powerpoint most_used_app">';
html += '<img class="office365" src="Images/excel_icon.png" >';
html += '<div class="bottom_content_exploration_insight">';
html += '<span class="vAlign office365">MS Excel</span>';
html += '</div>';
html += '</div>';
html +='</div>';
html +='</div>';
             
             
  $(rightPanel).append(html);  
  $(rightPanel).stop().animate({ scrollTop: $(rightPanel)[0].scrollHeight}, 500);

botReply('rightPanel','Incase you do not find your required application here, please raise a ticket for the same in request now.');

}
function display_calendar(id){
    
     var html= '<div class="speechBubble bot">';
                html += '<div class="bot-pic">';
	               html +='<img src="images/bot.png" alt="bot">';
	               html += '<p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p>';
               html +='</div>';
               html += '<div class="divContainerDown">';
             html += '<div class="calloutDown"></div>';
             html+='<img class="img-fluid" src="images/my-calendar-schedule.png">';
             html+='</div>';
    html+='</div>';
    $(rightPanel).append(html);  
  $(rightPanel).stop().animate({ scrollTop: $(rightPanel)[0].scrollHeight}, 500);
  
}

function makeNewsCard(id,arr){
    
    
 //  botReply('rightPanel','Technology news are as follows'); 
 //  addCustomITNews();
    
    
//  setTimeout( function(){},3000); 
   
  //  botReply('rightPanel','International news are as follows'); 
  // var html='';
    var html='<div class=" speechBubble bot"> <div class="bot-pic"> <img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div><div class="divContainerDown noCallout news">';
    for(var i=0;i<3;i++){
        html+='<div class="col-md-4 col-lg-4 col-sm-4 col-xs-12 alignCard">';
            html+='<div class="card international">';
                html+='<img class="img-fluid" src="'+arr[i].urlToImage+'" alt="">';
                
              
                    html+='<div class="news-title">';
                      
                            /*html+='<a href="'+arr[i].url+'" target="_blank">'+arr[i].title+'</a>';*/
                            html+='<p>'+arr[i].title+'</p>';
                       
                    html+='</div>';
                    html+='<div class="readMoreContainer"><hr class="borderBtm0"><p class="readMore"><a href="'+arr[i].url+'" target="_blank">Read More</a></p></div>';                                  
                html+='</div>';
         
        html+='</div>';
    }
    html+='</div></div>';
    
    botReply('rightPanel','Here are the Top International News'); 
    $(rightPanel).append(html); 
             scroller();
 
    //addCustomShellNews();
}


function makeInterNewsCard(id,arr){
    
   var html='<div class=" speechBubble bot"> <div class="bot-pic"> <img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div><div class="divContainerDown noCallout news">';
    for(var i=0;i<3;i++){
        html+='<div class="col-md-4 col-lg-4 col-sm-4 col-xs-3 alignCard">';
            html+='<div class="card international">';
                html+='<img class="img-fluid" src="'+arr[i].urlToImage+'" alt="">';
                
              
                    html+='<div class="news-title">';
                      
                            /*html+='<a href="'+arr[i].url+'" target="_blank">'+arr[i].title+'</a>';*/
                            html+='<p>'+arr[i].title+'</p>';
                       
                    html+='</div>';
                    html+='<div class="readMoreContainer"><hr class="borderBtm0"><p class="readMore"><a href="'+arr[i].url+'" target="_blank">Read More</a></p></div>';                                  
                html+='</div>';
         
        html+='</div>';
    }
    html+='</div></div>';
    
    botReply('rightPanel','Here are the Top International News'); 
    $(rightPanel).append(html); 
             scroller();
    
}



//function addCustomITNews(id, arr){
function  addCustomITNews(){
     // var html='<div class=" speechBubble bot"> <div class="bot-pic"> <img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div><div class="divContainerDown noCallout newsIT"></div></div>';
      var html="";
      $.get('NewsTemplate_IT.html', function(data){                     
         //$('.noCallout.newsIT').append(data);   
         html='<div class=" speechBubble bot"> <div class="bot-pic"> <img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div><div class="divContainerDown noCallout newsIT">';
        html+=data;
        html+="</div></div>";
       // html+= stomITNews(){

       // console.log('After----->'+$('.news. > .alignCard:last-Child').prevAll().length);
       /* $.each( $('.news > .alignCard'), function( indx, value ) {                       
            if(indx%3==0)
            {
                $(this).addClass('clearFloat');
                 console.log(indx);
            }
        }); */             
         botReply('rightPanel','Here are the Top IT News'); 
         $(rightPanel).append(html);                                               
      });
      
   //   makeNewsCard(id,arr);
}


function OnlyInterNews(){
    
}


function addCustomShellNews(){
      //var html='<div class=" speechBubble bot"> <div class="bot-pic"> <img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div><div class="divContainerDown noCallout newsShell"></div></div>';
      var html="";
      $.get('NewsTemplate_Shell.html', function(data){    
         html='<div class=" speechBubble bot"> <div class="bot-pic"> <img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div><div class="divContainerDown noCallout newsIT">';
        html+=data;
        html+="</div></div>";
       // console.log('After----->'+$('.news > .alignCard:last-Child').prevAll().length);
       /* $.each( $('.news > .alignCard'), function( indx, value ) {                       
            if(indx%3==0)
            {
                $(this).addClass('clearFloat');
                 console.log(indx);
            }
        }); */     
         botReply('rightPanel','Here are the Top Shell News'); 
        $(rightPanel).append(html);                                                       
      });
      
     // addCustomITNews();
      
}


function OnlySHellNews(){
    
    var html="";
      $.get('NewsTemplate_Shell.html', function(data){    
         html='<div class=" speechBubble bot"> <div class="bot-pic"> <img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div><div class="divContainerDown noCallout newsIT">';
        html+=data;
        html+="</div></div>";
       // console.log('After----->'+$('.news > .alignCard:last-Child').prevAll().length);
       /* $.each( $('.news > .alignCard'), function( indx, value ) {                       
            if(indx%3==0)
            {
                $(this).addClass('clearFloat');
                 console.log(indx);
            }
        }); */     
         botReply('rightPanel','Here are the Top Shell News'); 
        $(rightPanel).append(html);                                                       
      });
    
    
}

// seperate funcitons goes here...

$("body").on('click','.meetingSubmit',function(){
        
    console.log(selected_event_id);
    
    
    var startDate =document.getElementById("rescheduleDate").value;
    var startTime =document.getElementById("rescheduleStartTime").value;
    var endTime =document.getElementById("rescheduleEndTime").value;
    console.log(startDate);
    
    var start = startDate + 'T' + startTime + ':00.0000000';
    var end = startDate + 'T' + endTime + ':00.0000000';
    console.log("Before send to update calena"+start,end,selected_event_id);
    outlookCalendarUpdate(start,end,selected_event_id);
    
    
    botReply('rightPanel','Your meeting has been rescheduled');
    loadCalender();
});
function createWeatherCard(id,city,Country){
   var html='<div class=" speechBubble bot" id="wcard">';
           html+='<div class="bot-pic"> <img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div>';
           html+=' <div class="divContainerDown noCallout">';
                html+='<div class="widget-header alignCard">';
                   
                          html+='<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 overlay-background">'; 
                            html+='<p  class="wC_C"><span class="cityCountry">'+city+", "+Country+'</span> </p>';
                               html+='<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 weatherInfo"><span class="wText"></span><div class="col-lg-5 col-md-4 col-sm-4 col-xs-4 paddingLeftRight0 alignLeft">';
                            // html+='<p class="wday col-lg-12 col-md-12 col-sm-12 col-xs-12 paddingLeft0"></p>';
                            html+='<p class="wdate col-lg-12 col-md-12 col-sm-12 col-xs-12 paddingLeftRight0 "></p>';
                             html+='<p class="windSpeed col-lg-12 col-md-12 col-sm-12 col-xs-12 paddingLeftRight0">Wind 21km/h</p>';
                           
                            //  html+='<p class="humidity col-lg-12 col-md-12 col-sm-12 col-xs-12 paddingLeft0 "><span>92</span><span>%</span></p>';
                               html+='</div>';
                            html+='<div  class="col-lg-7 col-md-8 col-sm-8 col-xs-8 pull-right temperature" >';
                              html+= '<img class="weatherImg pull-right">';
                                html+='<div class=""><span class="wmax"> </span><span class="degree">°</span>';
                                    html+='<span class="celcius">C</span>';
                                html+='</div>';

                            html+='</div></div>';
                           
                    html+='</div>';
                html+='</div>';
            html+='</div>';
        html+='</div>';
        
        html += '<div class = "row"></div>';
        
        $(rightPanel).append("<br>" + html);
       // scrollFunc();
                scroller();
}

// for showing reports and charts about incident table
function appendStateDiv(title){
    $.get('ChartTemplate.html', function(data){
        $(rightPanel).append('<div class="chartTemplate">'+data+'</div>');
        $(rightPanel).find('.msgTime').text(formatAMPM(new Date()).split(" ")[0]);
                  scroller();
        $(rightPanel).find('.highcharts-container').append('<span class="loading">loading...</span>'); 
        $(rightPanel).find('.chart-card')[0].click();
       // setTimeout(function(){$(rightPanel).find('.chart-card')[0].click();},5000);
      //  setTimeout(function(){$(rightPanel).find('.highcharts-container').remove('.loading');},8000);
        if($(rightPanel).find('.categoryDrpDown').css('display')!=='none')
        {
            
             $($(rightPanel).find('.categoryDrpDown > select')[0]).change(function(){
              var indx= $(this).find('option:selected').index()+1; 
            });
           
        }
        else{
            // $($(".chart-card")[0]).click();
        }
    });
    
   
   
}
            
        /**********apps show hide on most used */
         
         
$('body').on('click','.all_applications_tab', function(){
	$(this).parent().siblings().find('.selected').removeClass('selected');
	$(this).addClass('selected');
	$('.content_right>div').show();
	
});

$('body').on('click','.skypeWork', function(){
	
    window.open("skype:live:murexsd1?chat");
	
});
/*
$('body').on('click','.office365', function(){
	
    window.open("https://login.microsoftonline.com/");
	
});
*/
/****Adding individual links for office apps */

/****Adding individual links for office apps */
 $('body').on('click','.office365', function(){
     var _self = $(this).parent('div').find('span.office365');
     var appname = _self.text().split(' ')[1];
     var appurl = 'https://office.live.com/start/' + appname + '.aspx';
	console.log(appurl);
    window.open(appurl,"'"+appname+"'");
	
});


$('body').on('click','.most_used_tab', function(){
$(this).parent().siblings().find('.selected').removeClass('selected');

$(this).addClass('selected');

$('.content_right>div').hide();
$('.content_right .most_used_app').show();

});





/******************************************** */
    
    $('body').on('click','.chart-card',function(){
		var title=($(this).find('.chart_title').html());
         $('.chart-card').removeClass('active');
		var by;
        var arr=$(this).attr('class').split(" ");
        for(var i=0; i<arr.length; i++)
        {
            if((arr[i]=='list-group-item') || (arr[i]=='chart-card') || (arr[i]=='active'))
            {
                
            }
            else
            {
                by= arr[i];
                 $('.'+by).addClass('active');
                //console.log(arr[i]); 
            }
            
        }
		$.ajax({
			url: 'serviceNowReport',
            type: 'GET',
			contentType: "application/json",
			data:{"by":by},
            success: function(res) {
				if(res.status){
					load_barChart(title,res.data);
				}else{
					botReply('rightPanel',res.data);
				}
            }
        });
});



 
 

 $("body").on('click','.ra_card_link',function(){
    var id=$(this).attr('data-id');
    console.log(id);
    
    //making request
    $.ajax({
			url: '/getRADoc',
            method: 'GET',
			contentType: "application/json",
			data:{id:id},
            success: function(res) {
                
				if(res.status){
					var html='<html><head><title>Right answers help</title></head><body><h4>'+res.data.author+'</h4>';
                    for(var i=0;i<res.data.fields.length;i++){
                        html+='<h4>'+res.data.fields[i].name+'</h4>';
                        html+='<p>'+res.data.fields[i].content+'</p><br>';
                    }
                    html+="</body></html>";
                    var newWindow = window.open();
                    newWindow.document.write(html);
                    newWindow.document.close();
				}else{
					console.log("Unable to get the content.")
				}
            }
        });
     
 });
 

 
 

 
 
     

// ===============================independent function goes here..========================
// to convert string into camelcase
function toCamelCase(str){
  return str.split(' ').map(function(word){
    return word.charAt(0).toUpperCase() + word.slice(1);
  }).join(' ');
}
// to get the location from browser
function askLocation(callback){           
	if (navigator.geolocation) {
	    navigator.geolocation.getCurrentPosition(function(position){
	        //console.log(position)
	        var lat=position.coords.latitude;
	        var long=position.coords.longitude;
	        //console.log("hello")
	        $.ajax({
				url: 'https://maps.googleapis.com/maps/api/geocode/json?latlng='+lat+','+long+'&sensor=true',
	            type: 'GET',
	            success: function(res) {
					var address_arr=res.results[0].address_components;
	                
	                for(var i=0;i<address_arr.length;i++){
	                    //console.log(address_arr[i].types.includes('country'));
	                    //console.log(address_arr[i].types.includes('administrative_area_level_2'));
	                    if(address_arr[i].types.includes('country')){
	                        g_country=address_arr[i].long_name;
	                        
	                    }
	                    if(address_arr[i].types.includes('administrative_area_level_2')){
	                         g_city=address_arr[i].long_name;
	                    }
	                }
	                callback();
	            }
	        });
	    },function(err){
	        //console.log(err);
	        console.log("Error in Getting Location");
	        g_country='Germany';
            g_city='Frankfurt';
	        callback();
	    });
	} else { 
	    alert("Geolocation is not supported by this browser.");
         g_country='Germany';
         g_city='Frankfurt';
	    callback();
	}
}
var mon=[];
var tue=[];
var wed=[];
var thu=[];
var fri=[];


//for filtering calendar dates
 function getOutlookCalenderFilter(dateCal){
     var day=dateCal.split(" ")[0];
     if(day==="Mon"){
         return mon;
     }else if(day==="Tue"){
         return tue;
     }else if(day==="Wed"){
         return wed;
     }else if(day==="Thu"){
         return thu;
     }else if(day==="Fri"){
         return fri;
     }
 };

function cancelMeetingFromChat(m,day){
    console.log("cancel "+m+" from ;");
    var arraytOSearchForCancel=getOutlookCalenderFilter(day);
    console.log(arraytOSearchForCancel);
    var sub=m.split("at")[0].trim();
    var start=m.split("at")[1].trim();
    var idToCancel="";
    for(var i=0;i<arraytOSearchForCancel.length;i++){
        var a=new Date(arraytOSearchForCancel[i].Start);
        a=a.toTimeString();
        a=a.split(":")[0]+":"+a.split(":")[0];
        
        if(arraytOSearchForCancel[i].Subject.trim()===sub && a===start){
            console.log("match foud");
            idToCancel=arraytOSearchForCancel[i].EventId;
            break;
        }
        
    }
    if(idToCancel!==""){
        outlookCalendarCancel(idToCancel,function(res){
             console.log("Cancel status:"  + res); 
             if(res.status){ 
                 botReply('rightPanel',"I have cancelled your meeting."); 
                 loadCalender();
             }else{
                 //botReply('rightPanel',"I have cancelled your meeting."); 
                  console.log("Some problem with connection."); 
             }
         });
    }
}





// to get outlook calendar and parse the data
 //calnder
 function getOutlookCalender(){
     
     //console.log("In calendar");
     $.ajax({
			url: 'microsoft/calender',
            type: 'GET',
			contentType: "application/json",
            success: function(res) {
                console.log(res);
				if(res.status){
                    var allEvent=[];
                    mon=[];
                    tue=[];
                    wed=[];
                    thu=[];
                    fri=[];
                    for (var i = 0; i < res.data.length; i++){
                       var s=res.data[i].Start.DateTime;
                       var e=res.data[i].End.DateTime;
                       //console.log("Meeting data :  " + res.data[i]);
                       var obj={
                                Start:s.toLocaleString(),
                                End:e.toLocaleString(),
                                Subject:res.data[i].Subject,
                                day:new Date(s).getDay(),
                                EventId:res.data[i].Id
                                };
                       allEvent.push(obj);
                       //console.log("Meeting data day :  " + obj.day);
                       if(allEvent[i].day===1){
                            mon.push(allEvent[i]);   
                       }else if(allEvent[i].day===2){
                            tue.push(allEvent[i]);   
                       }else if(allEvent[i].day===3){
                            wed.push(allEvent[i]);   
                       }else if(allEvent[i].day===4){
                            thu.push(allEvent[i]);   
                       }else if(allEvent[i].day===5){
                            fri.push(allEvent[i]);   
                       }else{
                           console.log("else");
                           console.log(allEvent[i])
                       }
                       
                    }
                    var all=[mon.length,tue.length,wed.length,thu.length,fri.length];
                    var indexOfMaxValue = all.reduce((iMax, x, i, arr) => x > arr[iMax] ? i : iMax, 0);
               
                    var html='';
                    for(var i=0;i<all[indexOfMaxValue];i++){
                        html+='<tr>';
					html+='<td>';
						html+='<div class="cellColor"></div>';
						html+='<div class="cellText Monday"></div>';
						html+='<div class="cellMenu"><i class="fa fa-ellipsis-v"></i></div>';
					html+='</td>';
					html+='<td><div class="cellColor"></div>';
						html+='<div class="cellText Tuesday"></div>';
						html+='<div class="cellMenu"><i class="fa fa-ellipsis-v"></i></div></td>';
					html+='<td><div class="cellColor"></div>';
						html+='<div class="cellText Wednesday"></div>';
						html+='<div class="cellMenu"><i class="fa fa-ellipsis-v"></i></div></td>';
					html+='<td><div class="cellColor"></div>';
						html+='<div class="cellText Thursday"></div>';
						html+='<div class="cellMenu"><i class="fa fa-ellipsis-v"></i></div></td>';
					html+='<td><div class="cellColor"></div>';
						html+='<div class="cellText Friday"></div>';
						html+='<div class="cellMenu"><i class="fa fa-ellipsis-v"></i></div></td>';
				html+='</tr>';
                    }
                    $(".calendar #calTable").append(html);
                    for(var i=0;i<mon.length;i++){
                        var s=new Date(mon[i].Start);
                        var e=new Date(mon[i].End);
                        var shour = s.getHours();
                        var smin =  s.getMinutes();
                        var ehour = e.getHours();
                        var emin =  e.getMinutes();
                        smin = smin < 10 ? '0'+smin : smin;
                        emin = emin < 10 ? '0'+emin : emin;
                        
                        var stime = shour + ":" + smin;
                        var etime = ehour + ":" + emin;
                        
                        var out='<b data-id='+mon[i].EventId+'>'+mon[i].Subject+"</b> at "+stime+"  to "+etime;
                        $($(".calendar .Monday")[i]).attr('data-id',mon[i].EventId);
                        $($(".calendar .Monday")[i]).html(out);
                    }
                    for(var i=0;i<tue.length;i++){
                        
                        var s=new Date(tue[i].Start);
                        var e=new Date(tue[i].End);
                        
                        
                        var shour = s.getHours();
                        var smin =  s.getMinutes();
                        var ehour = e.getHours();
                        var emin =  e.getMinutes();
                        
                        smin = smin < 10 ? '0'+smin : smin;
                        emin = emin < 10 ? '0'+emin : emin;
                        var stime = shour + ":" + smin;
                        var etime = ehour + ":" + emin;
                        
                        
                        var out='<b>'+tue[i].Subject+"</b> at "+stime+"  to "+etime;
                        $($(".calendar .Tuesday")[i]).attr('data-id',tue[i].EventId);
                        $($(".calendar .Tuesday")[i]).html(out);
                    }
                    for(var i=0;i<wed.length;i++){
                        
                        var s=new Date(wed[i].Start);
                        var e=new Date(wed[i].End);
                        
                         var shour = s.getHours();
                        var smin =  s.getMinutes();
                        var ehour = e.getHours();
                        var emin =  e.getMinutes();
                        smin = smin < 10 ? '0'+smin : smin;
                        emin = emin < 10 ? '0'+emin : emin;
                        
                        var stime = shour + ":" + smin;
                        var etime = ehour + ":" + emin;
                        
                        var out='<b>'+wed[i].Subject+"</b> at "+stime+"  to "+etime;
                        $($(".calendar .Wednesday")[i]).attr('data-id',wed[i].EventId);
                        $($(".calendar .Wednesday")[i]).html(out);
                    }
                    for(var i=0;i<thu.length;i++){
                        var s=new Date(thu[i].Start);
                        var e=new Date(thu[i].End);
                        
                         var shour = s.getHours();
                        var smin =  s.getMinutes();
                        var ehour = e.getHours();
                        var emin =  e.getMinutes();
                        smin = smin < 10 ? '0'+smin : smin;
                        emin = emin < 10 ? '0'+emin : emin;
                        
                        var stime = shour + ":" + smin;
                        var etime = ehour + ":" + emin;
                        
                        var out='<b>'+thu[i].Subject+"</b> at "+stime+"  to "+etime;
                        $($(".calendar .Thursday")[i]).attr('data-id',thu[i].EventId);
                        $($(".calendar .Thursday")[i]).html(out);
                    }
                    for(var i=0;i<fri.length;i++){
                        var s=new Date(fri[i].Start);
                        var e=new Date(fri[i].End);
                        
                         var shour = s.getHours();
                        var smin =  s.getMinutes();
                        var ehour = e.getHours();
                        var emin =  e.getMinutes();
                        smin = smin < 10 ? '0'+smin : smin;
                        emin = emin < 10 ? '0'+emin : emin;
                        
                        var stime = shour + ":" + smin;
                        var etime = ehour + ":" + emin;
                        
                        var out='<b>'+fri[i].Subject+"</b> at "+stime+"  to "+etime;
                        $($(".calendar .Friday")[i]).attr('data-id',fri[i].EventId);
                        $($(".calendar .Friday")[i]).html(out);
                    }
				}
                else{
					console.log("calendar data parse error");
				}
            }
        });
 };
 
 function load_barChart(title,result){
			
    var charArr=new Array();
	var valArray=new Array();
	//console.log("---------------"+result);
	
	for(var i=0;i<result.length;i++){
		if(result[i].groupby_fields[0].value!==''){
			valArray.push(parseInt(result[i].stats.count));
			
			if(result[i].groupby_fields[0].display_value==='undefined'){
				charArr.push(result[i].groupby_fields[0].value);
			}else{
				charArr.push(result[i].groupby_fields[0].display_value);
			}
			
		}
		
	}
    console.log(charArr)
    console.log(valArray)
	Highcharts.chart('chart-div', {
		chart: {
			type: 'column'
		},
		title: {
			text: title
		},
		xAxis: {
			categories: charArr,
			crosshair: true
		},
		yAxis: {
			min: 0,
			title: {
				text: 'Incident Count'
			}
		},
		tooltip: {
			headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
			pointFormat: '<tr><td style="color:{series.color};padding:0"></td>' +
				'<td style="padding:0"><b>{point.y}</b></td></tr>',
			footerFormat: '</table>',
			shared: true,
			useHTML: true
		},
		plotOptions: {
			column: {
				pointPadding: 0.2,
				borderWidth: 0
			}
		},
		series: [{
			name: title,
			data: valArray

		}]
	});
 }
 // to show most use apps
 function showMostUsedApps(ele){
    
    $(ele).parent().siblings().find('.selected').removeClass('selected');

	$(ele).addClass('selected');

	$('.content_right>div').hide();
	$('.content_right .most_used_app').show();
    
}
function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  return strTime;
}
// init itmes and date
function initDateTime(){
    $(".time").html(formatAMPM(new Date()).split(" ")[0]);
    
    $(".time_format").html(formatAMPM(new Date()).split(" ")[1].toLowerCase());
    var date=new Date().toDateString();
    date=date.split(" ");
    //console.log(date[0]+" "+date[2]+", "+date[1]+" "+date[3]);
    $(".date").html(date[0]+" "+date[2]+", "+date[1]+" "+date[3]);
    $(".displayTime.hide").removeClass('hide');
}
function placeWeatherDetails(current){
   var cd=current.date.split(",")[1].split(" ")[1]+" "+current.date.split(",")[1].split(" ")[2]+" "+current.date.split(",")[1].split(" ")[3];
   var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var d = new Date(cd);
    var dayName = days[d.getDay()];
    var date=current.date;
    date=date.split(" ");
   todaydate = dayName + " "+date[2]+" "+date[1]+","+date[3];
    var monthNum= ((new Date()).getMonth() +1); 
                   
  // $(".wdate").html(date[0]+" "+date[2]+" "+date[1]+", "+date[3]);
   $(".wdate").html(dayName+"\n" +date[1] + "/"+ (monthNum<10? "0"+monthNum: monthNum) + "/"+date[3]);
   dateDDMMYYYY= date[1] + "/"+ (monthNum<10? "0"+monthNum: monthNum) + "/"+date[3];
  // $(".wdate").html(date[0]+" "+date[2]+" "+date[1]+", "+date[3]);
   //$(".wdate").html(todaydate);
   $(".wday").html(dayName);
   $(".wmin").html(toCelsius(current.temp)-10);
   $(".wmax").html(toCelsius(current.temp));
   $(".wText").html("  " + current.text);
   
   
   if(current.text === 'Sunny'){
        $('#wcard .weatherImg').attr('src', sunny);
   }else if(current.text === 'Cloudy'){
       $('#wcard .weatherImg').attr('src', cloudy);
   }else if(current.text === 'Partly Cloudy'){
       $('#wcard .weatherImg').attr('src', cloudy);
   }
   else if(current.text === 'Mostly Cloudy'){
       $('#wcard .weatherImg').attr('src', cloudy);
   }else if(current.text === 'Rainy'){
       $('#wcard .weatherImg').attr('src', rain);
   }
   else if(current.text === 'Thunderstorm'){
       $('#wcard .weatherImg').attr('src', thunderStorm);
   }else if(current.text === 'Thundershowers'){
       $('#wcard .weatherImg').attr('src', thunderShowers);
   }else if(current.text === 'Mostly Sunny'){
       $('#wcard .weatherImg').attr('src', sunny);
   }else{
       $('#wcard .weatherImg').attr('src', sunny);
   }
   
    $('.weatherInfo.hide').removeClass('hide');
}
function toCelsius(f) {
     return ((5/9) * (f-32)).toFixed(0);
}

//screenshot function
function screenShot(id,text){
    var html='<div class="speechBubble bot">';
	html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+ formatAMPM(new Date()).split(" ")[0]+'</p></div>';
    html+='<div class="calloutDown"></div>';
	html+='<div class="divContainerDown">'+text;
    
		
		html+='<input type="file" name="my_file" id="my-file" class="screenAttach" value="upload">';
        html+='<button class="btn btn-success screenSubmit marginTop10" value="submit">Submit</button>';
		html+='</div>';
       
     html+='</div>';
    $(rightPanel).append(html);
    //scrollFunc();
    scroller();   
    
}

//windows screen sample function
function winSample(id,text){
    var html='<div class="speechBubble bot">';
	html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+ formatAMPM(new Date()).split(" ")[0]+'</p></div>';
    html+='<div class="calloutDown"></div>';
	html+='<div class="divContainerDown">'+text;
    
		html+='<br><img src="images/ipaddress.jpg" >';
		html+='</div>';
       
     html+='</div>';
    $(rightPanel).append(html);
    //scrollFunc();
    scroller();   
    
}


//mac screen sample function
function macSample(id,text){
    var html='<div class="speechBubble bot">';
	html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+ formatAMPM(new Date()).split(" ")[0]+'</p></div>';
    html+='<div class="calloutDown"></div>';
	html+='<div class="divContainerDown">'+text;
    
		html+='<br><img src="images/macSample.jpg" >';
		html+='</div>';
       
     html+='</div>';
    $(rightPanel).append(html);
    //scrollFunc();
    scroller();   
    
}

//Ip address display function
function ipAddress(id,text){
    var html='<div class="speechBubble bot">';
	html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+ formatAMPM(new Date()).split(" ")[0]+'</p></div>';
    html+='<div class="calloutDown"></div>';
	html+='<div class="divContainerDown">'+text;
    
		
		html+='<br><img src="images/ipaddress.jpg" >';
		html+='</div>';
       
     html+='</div>';
    $(rightPanel).append(html);
    //scrollFunc();
    scroller();   
    
}

//send message and append to HTML
function botReply(id,text){
    var html='<div class="speechBubble bot">';
	html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+ formatAMPM(new Date()).split(" ")[0]+'</p></div>';
    html+='<div class="calloutDown"></div>';
	html+='<div class="divContainerDown">'+text+'</div>';
     html+='</div>';
    $(rightPanel).append(html);
    //scrollFunc();
    scroller();     
}

function scroller(){
    try{
       $("#rightPanel").stop().animate({ scrollTop: $("#rightPanel")[0].scrollHeight}, 500);
    }
    catch(error)
    {
        console.log("Error While Scrolling..."+error.message);
    }   
}
function userReply(id,text){
    var html='<div class="speechBubble user">';
	//html+='<div class="calloutDown"></div>';
	html+='<div class="divContainerDown">'+text+'</div>';
    html+='<div class="calloutDown"></div>'
           +'<div class="user-pic">'
           +'<img src="images/customer.png" alt="customer">'
	       + '<p class=" msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p>'
           + '</div>';
html+='</div>';
$(rightPanel).append(html);
// scrollFunc();
             scroller();
}
function bot_booleanOption(id,question){
    var html='<div class="row"><div class="col-lg-12 col-md-12 speechBubble bot choice">';
	html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div>'

+'<div class="calloutDown"></div>';
	html+='<div class="divContainerDown">'+question;
		html+='<div class="btn-set">';
		html+='<button type="button" class="btn btn-default botTextMsg">No</button>';
		html+='<button type="button" class="btn btn-success botTextMsg">Yes</button>';
		html+='</div>';
	html+='</div>';
html+='</div></div>';
$(rightPanel).append(html);
//scrollFunc();
              scroller();

}
function bot_steps_Reply(id,arr,title){
    
    var html='<div class="speechBubble bot steps">';
	html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div>'

+'<div class="calloutDown"></div>';
	html+='<div class="divContainerDown">';
    html+='<div class="step"><div class=""></div><b>'+title+'</b></div>';
    for(var i=0;i<arr.length;i++){
        html+='<div class="step"><div class="stepAnchor"></div><p>'+(i+1)+' .'+arr[i]+'</p></div>';
    }
										
	html+='</div>';
html+='</div>';
 $(rightPanel).append(html);
  //scrollFunc();
             scroller();

}
function radio_button_options(id,option_arr,question,lbl){
    var html='<div class="col-lg-12 col-md-12 col-sm-12 speechBubble bot radioOpt paddingLeft0">';
	html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div>'
    +'<div class="calloutDown"></div>';
	//html+='<div class="divContainerDown">'+question;
     html += '<div class="divContainerDown">';
     
		for(var i=0;i<option_arr.length;i++){
        //var src = 'https://cdn2.iconfinder.com/data/icons/plump-by-zerode_/256/Folder-My-documents-icon.png'; 
        var src = '';   
        if(option_arr[i] === 'I need help installing a printer'){
            //src = 'Images/Printer-Install.png';
            src = '<img src="Images/Printer-Install.png" alt="install-printer width="60px" height="60px">';
            
        } else if(option_arr[i] === 'My printer does not print at all'){
            
            //src = 'Images/Printer-Failed.png';
            src = '<img src="Images/Printer-Failed.png" alt="install-printer width="60px" height="60px">';
        }  else if(option_arr[i] === 'My printer has a paper jam'){
            
            //src = 'Images/Printer-Jam.png';
            src = '<img src="Images/Printer-Jam.png" alt="install-printer width="60px" height="60px">';
        }   
        else if(option_arr[i] === 'My printer need toner replacement'){
            
            //src = 'Images/Printer-Toner-Repl.png';
            src = '<img src="Images/Printer-Toner-Repl.png" alt="install-printer width="60px" height="60px">';
        }   
          
        html += '<div class="optionGrid">';
            
                html += '<div>';
                    //html += '<img src="' +  src + '" alt="install-printer width="40px" height="40px">';
                    //html += src;
               html += ' </div>';
                html += '<div class="radio botTextMsg marginTopBottom5 ">';
                     //html+='<label><input type="radio" name="optradio" class="">'+option_arr[i]+'</label>';
                     html+='<label class="paddingLeft0">';
                     
                     html+='<a href = "#" name="optradio" class="">'+option_arr[i] ;
                     
                    
                     html+='</label>';
                html += '</div>';
               //html += ' <p>I need help installing a Printer</p>';
               
            html += '</div>';
           
           
        }
	html+='</div>';
html+='</div>';
$(rightPanel).append(html);
           // if($('.optionGrid img').length>0)
           // {
            //     $('.optionGrid').css('display','inline-block');
           // }
           // else
           // {
            //     $('.optionGrid').css('display','block');
           // }
           
//scrollFunc();
             scroller();

}


function card_display(id,url,title){
   
   var imgClass = '';
   var listener = '';
   var html = '';
   var link = '#';
   var newTab = '';
   var src = "https://cdn2.iconfinder.com/data/icons/plump-by-zerode_/256/Folder-My-documents-icon.png";
   
   if(title === 'Update Ticket'){
       src = 'Images/smartcardaccess.png';
         
   }
   
   if(title != 'Update Ticket'){
       
       //link = url;
       newTab = ' target = "_blank"';
       //var html ;
       
       if(title === 'Click to call'){
           src = 'Images/Click_Call.png';
           imgClass = 'SkypeButton_Call';
           link='skype:live:murexsd1?call';
       }
       else if(title === 'Click to chat'){
           src = 'Images/Click_Chat.png';
            link='skype:live:murexsd1?chat';
       }
       else if(title === 'Schedule a callback'){
           src = 'Images/Click_Schedule_Call.png';
           //listener = 'class = "callback"';
           //link = "";
           newTab ='';
       } 
       else if(title === 'Optimise system performance'){
           src = 'Images/card-for-system-performance.png';
       }
        else if(title === 'Refresh the operating system'){
           src = 'Images/internet.png';
       }else{
           
            src = 'Images/card-for-system-performance.png';
           
       }
       
   }
   
   // $(rightPanel).append('<br><div class="card small speechBubble"><img src="https://cdn2.iconfinder.com/data/icons/plump-by-zerode_/256/Folder-My-documents-icon.png" alt="Avatar"  class = "cardButton" data="getWeather"> <div class="container"> <h4><b> <p class="test">' + title + '</p> <div class="card-action"><a href='+ url + ' target="_blank">Click Here</a> </div>' +'</div></div><br>');			
  html='<div class="alignImgCard">';
            html+='<div class="card imgCard" >';
                html+='<img class= "padding5 '+ imgClass +'" src="'+ src + '"alt="">';
                
               html+=' <div class="card-block">';
                    html+='<div class="news-title">';
                        html+='<p class=" title-small alignCenter">';
                            html+='<a href="' + link + '"' + newTab + '>'+title+'</a>';
                            //console.log(html);
                        html+='</p>';
                    html+='</div>';
                    
                html+='</div>';
            html+='</div>';
        html+='</div>';

$(rightPanel).append(html);
// scrollFunc();
             scroller();

}
function RAcard_display(id,url,title,doc_id){
   
   var imgClass = '';
   var html = '';
   var link = '#';
   var newTab = '';
   var src = "https://cdn2.iconfinder.com/data/icons/plump-by-zerode_/256/Folder-My-documents-icon.png";
   
   if(title === 'Update Ticket'){
       src = 'Images/smartcardaccess.png';
         
   }
   
   if(title != 'Update Ticket'){
       
       link = url;
       newTab = ' target = "_blank"';
       //var html ;
       
       if(title === 'Click to call'){
           src = 'Images/Click_Call.png';
           imgClass = 'SkypeButton_Call';
           link='skype:live:murexsd1?call';
       }
       else if(title === 'Click to chat'){
           src = 'Images/Click_Chat.png';
            link='skype:live:murexsd1?chat';
       }
       else if(title === 'Schedule a callback'){
           src = 'Images/Click_Schedule_Call.png';
       } 
       else if(title === 'Optimise system performance'){
           src = 'Images/card-for-system-performance.png';
       }
        else if(title === 'Refresh the operating system'){
           src = 'Images/internet.png';
       }else{
            src = 'Images/card-for-system-performance.png';
       }
   }
  /***Create options HTML**** */ 		
  html='<div class="alignImgCard">';
            html+='<div class="card imgCard" >';
                html+='<img class= "padding5 '+ imgClass +'" src="'+ src + '"alt="">';
                
               html+=' <div class="card-block">';
                    html+='<div class="news-title">';
                        html+='<p class=" title-small alignCenter">';
                            html+='<p data-id='+doc_id+' class="ra_card_link">'+title+'</p>';
                         
                        html+='</p>';
                    html+='</div>';
                    
                html+='</div>';
            html+='</div>';
        html+='</div>';

    $(rightPanel).append(html);
             scroller();
}




function scrollFunc(){
    $('div').animate({ scrollTop: $(".rightPanel div").last().offset().bottom }, 'slow');
}

function botWeatherCard(callback){
   askLocation(function(){
        
    
    //  var city = "Amsterdam";
    //  var country="Netherlands";
     createWeatherCard("rightPanel",g_city,g_country);
     $.ajax({
        url: baseurl_chat+'/getWeather',
        type: 'GET',
        contentType: "application/json",
        data: {city: g_city,country: g_country},
        success: function (res) {
            if (res.status) {
                 var Wjson=JSON.parse(res.data);
                 var current=Wjson.query.results.channel.item.condition;
                 var forcast=Wjson.query.results.channel.item.forecast; 
                 callback(current,forcast);
            } else {
                alert(res.msg);
            }
        }
    });
   })
    
}


function outlookCalendarUpdate(start,end,eventId){
    $.ajax({
	url: 'microsoft/calenderUpdate',
    type: 'POST',
	contentType: "application/json",
    data:JSON.stringify({start:start,end:end,eventId:eventId}),
    success: function(res) {
        console.log("update cal:" + res)
    }
    });
}
function outlookCalendarCancel(eventId,callback){
    $.ajax({
	url: 'microsoft/calenderCancel',
    type: 'POST',
	contentType: "application/json",
    data:JSON.stringify({eventId:eventId}),
    success: function(res) {
        callback(res)
    }
    });
}
//to laod calendar
function loadCalender(){
   try{
       $(rightPanel).find(".calendar").removeClass('calendar').addClass('prevcalendar');
   }catch(e){
       
   }
   $.get('Calender.html', function(data){  
                       
   $(rightPanel).append(data);
   
      
   var today=new Date();
   var current_day=today.getDay();
   var mndy=new Date();
   mndy.setDate(today.getDate()-current_day+1);
   mndy=mndy.toString();
   var tues=new Date();
   tues.setDate(today.getDate()-current_day+2);
   tues=tues.toString();
   var wed=new Date();
   wed.setDate(today.getDate()-current_day+3);
   wed=wed.toString();
   var thus=new Date();
   thus.setDate(today.getDate()-current_day+4);
   thus=thus.toString();
   var fri=new Date();
   fri.setDate(today.getDate()-current_day+5);
   fri=fri.toString();
   var calHead='<tr><td class="col-md-2 calHead">'+mndy.split(" ")[0]+" "+mndy.split(" ")[2]+" "+mndy.split(" ")[1]+'</td>';
   calHead+='<td class="col-md-2 calHead">'+tues.split(" ")[0]+" "+tues.split(" ")[2]+" "+tues.split(" ")[1]+'</td>';
   calHead+='<td class="col-md-2 calHead">'+wed.split(" ")[0]+" "+wed.split(" ")[2]+" "+wed.split(" ")[1]+'</td>';
   calHead+='<td class="col-md-2 calHead">'+thus.split(" ")[0]+" "+thus.split(" ")[2]+" "+thus.split(" ")[1]+'</td>';
   calHead+='<td class="col-md-2 calHead">'+fri.split(" ")[0]+" "+fri.split(" ")[2]+" "+fri.split(" ")[1]+'</td></tr>';
   $(".calendar #calTable").append(calHead);
   getOutlookCalender(); 
    
   
   
//   setTimeout(function(){$( "#rightPanel .chats #insertDate" ).datepicker()},30000);  
   // $( "#rightPanel .chats #insertDate" ).datepicker({ defaultDate: new Date() });
    $( "#insertDate").text(dateDDMMYYYY);
  //  $( "#rightPanel  #insertDate" ).datepicker({'setDate': $(".wdate").html(),'dateFormat': "DD, MM d, yy"});
   // $( "#rightPanel .chats #insertDate").val($(".wdate").html());
    $('.calendar').find('.msgTime').text(formatAMPM(new Date()).split(" ")[0]);
    //"setDate", new Date()
    
    $('body').on('click','.cellMenu', function(){
        //console.log($(this).parent().find('.cellText').attr('data-id'));
        selected_event_id=$(this).parent().find('.cellText').attr('data-id');
		$('.calenderOptions').css('display','inline');
		$('.calenderOptions').offset({ top: $(this).offset().top + 10, left: $(this).offset().left-100 });
		//console.log($(this).offset().top+'---------'+$(this).offset().left);                  		
                       
	});
    
	$('.calenderOptions .close').on('click', function(){
		$('.calenderOptions').css('display','none');
	});
    
    $('.calenderOptions .list-group button').on('click', function(){
        $('.calenderOptions').css('display','none');
    });
    // calling calender function to get events from outlook  
        $('div').animate({ scrollTop: $(".rightPanel div").last().offset().bottom }, 'slow');                                     
  });
}
function loadService(){
  $.get('ServiceOption.html', function(data){                     
   $(rightPanel).append(data);   
                                               
  });
}                
function getReports(){
    botReply('rightPanel','Here are your last 5 incidents, to show all incidents please click on view all');
                      
     $.ajax({
            url:baseurl_chat+'/getReports',
            type: 'GET',
            contentType: "application/json",
            success: function (res) {
               bot_Table('rightPanel',res);
               getMyTasks();
            }
        });
     function getMyTasks(){   
      botReply('rightPanel','Here are your last 5 tasks, to show all incidents please click on view more');
                        
       $.ajax({
            url:baseurl_chat+'/getTasks',
            type: 'GET',
            contentType: "application/json",
            success: function (res) {
               bot_Table('rightPanel',res);
               getGraphReports();
            }
        });
     }
    
}




function getGraphReports(){
    
    botReply('rightPanel','<span class="graphs" style="cursor:pointer;color:blue;" title="Click here">Click here to get a graphical view for your reports<span>');
}

function display_service_category(id){
    var html= '<div class="speechBubble bot">';
                html += '<div class="bot-pic">';
	               html +='<img src="images/bot.png" alt="bot">';
	               html += '<p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p>';
               html +='</div>';
html += '<div class="divContainerDown servicerequest">'; 
html += '<div class="bubble_content">';
html += '<h3>Raise Requests</h3>';
html += '<div class="content_right">';
html += '<div class="exploration_insight">';
//html += '<img src="Images/hardware.png" >';
html += '<div class="bottom_content_exploration_insight">';
html += '<span class="vAlign hardware">Hardware Request</span>';
html += '</div>';
html += '</div>';
html += '<div class="sapMM">';
//html += '<img src="Images/software.png" >';
html += '<div class="bottom_content_sapMM">';
html += '<span class="vAlign software">Software Request</span>';
html += '</div>';
html += '</div>';
html += '<div class="sapWM">';
//html += '<img src="Images/access.jpeg" >';
html += '<div class="bottom_content_sapWM">';
html += '<span class="vAlign access">Access Request</span>';
html += '</div>';
html += '</div>';
html += '<div class="mover">';
//html += '<img src="Images/mover.png">';
html += '<div class="bottom_content_primavera">';
html += '<span class="vAlign mover">Mover Request</span>';
html += '</div>';
html += '</div>';
html += '<div class="meriduim">';
//html += '<img src="Images/admin.jpeg">';
html += '<div class="bottom_content_meriduim">';
html += '<span class="vAlign system">System Information</span>';
html += '</div>';
html += '</div>';
html += '<div class="smartTransform">';
//html += '<img src="Images/admin.jpeg" >';
html += '<div class="bottom_content_smartTransform">';
html += '<span class="vAlign admin">Admin Request</span>';
html += '</div>';
html += '</div>';

html +='</div>';
html +='</div>';
  $(rightPanel).append(html);  
             scroller();

}



function minuteCorrect(){
    var min = new Date().getMinutes();
    var correctMin = min < 10 ? '0'+min : min;
    return correctMin;
}

  function bot_Table(id,res){
      
    			var html='<div class="speechBubble bot">';
	        html+='	<div class="bot-pic"><img src="images/bot.png" alt="bot"><p class="msgTime">'+formatAMPM(new Date()).split(" ")[0]+'</p></div>';
		        html += '<div class="calloutDown"></div>';
    				html += '<div class="divContainerDown table-responsive ">';
                      // html+='<div class="reportTableContainer">';
    					html += '<table class="table table-bordered table-striped reportTable">';
    						html += '<thead>';
    						  html += '<tr>';
    							html += '<th><i class="fa fa-bars" aria-hidden="true"></i>Number</th>';
    							html += '<th><i class="fa fa-bars" aria-hidden="true"></i>Description</th>';
    							html += '<th><i class="fa fa-bars" aria-hidden="true"></i>Work Notes</th>';
    							html += '<th><i class="fa fa-bars" aria-hidden="true"></i>State</th>';
    							html += '<th><i class="fa fa-bars" aria-hidden="true"></i>Last Updated</th>';
    						  html += '</tr>';
    						html += '</thead>';
                            html += '<tbody>';
                            
                             for(var i=res.data.length-1;i>=0;i--){
                              var dataClass = (i>res.data.length-6)?'showData':'hideData';
                             
    						  html += '<tr class=' + dataClass + ' >';
    							html += '<td class="incident_item" style="cursor:pointer" title="click here to get details.">'+ res.data[i].number +'</td>';
    							html += '<td>'+ res.data[i].short_description + '</td>';
                                html += '<td>'+res.data[i].u_my_work_notes+'</td>';
                                html += '<td>'+getStateDesc(res.data[i].state)+'</td>';
    							//html += '<td><div class="status pending"></div>'+res.data[i].opened_at+'</td>';
                                html += '<td></div>'+res.data[i].sys_updated_on+'</td>';
    							
    							//html += '<td>'+getStateDesc(res.data[i].state)+'</td>';
    						  html += '</tr>';
                         
                     }
				html += ' <tr><td class="actionButtonsContainer" colspan="5"><input type="button" value="View all"></input></td></tr>';
				html += '</tbody>';
			  html += '</table>';            
		html += '</div>';
	html += '</div>';
 $(rightPanel).append(html);
 scroller();
    $(".hideData").hide();
    $(".actionButtonsContainer input").on('click',function(){
        var _self = $(this);
        _self.hide();
        $(".hideData").show();
    });
}       
function getStateDesc(a){
    a=parseInt(a);
    if(a===1){
        return "Open";
    }else if(a===2){
        return "Known Error";
    }else if(a===3){
        return "Pending Change";
    }else if(a===4){
        return "Closed/Resolved";
    }else if(a===7){
        return "Closed";
    }
}



function getPriorityDesc(a){
    a=parseInt(a);
    if(a===1){
        return "Critical";
    }else if(a===2){
        return "High";
    }else if(a===3){
        return "Moderate";
    }else if(a===4){
        return "Low";
    }else if(a===5){
        return "Planning";
    }
}
function showRequestRecordById(id){
    $.ajax({
        url: baseurl_chat+'/reqItem',
        type: 'GET',
        contentType: "application/json",
        data: {"itemId":id},
        success: function (res) {
            if (res.status) {
                 //console.log(res.data);
                 createIncidentCard('rightPanel',res.data);
            } else {
                //console.log(res.data);
            }
        }
    });
}


function showRequestRecordByIdTimeOut(id){
    $.ajax({
        url: baseurl_chat+'/reqItem',
        type: 'GET',
        contentType: "application/json",
        data: {"itemId":id},
        success: function (res) {
            if (res.status === 4 || res.status === 7) {
                 //console.log(res.data);
                 createIncidentCard('rightPanel',res.data);
            } else {
                //console.log(res.data);
            }
        }
    });
}