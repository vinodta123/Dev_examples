var credentials = {
  client: {
    id: '94565e8e-7009-44db-9d07-ad2688a1522d',
    secret: 'R6zQK6cvwA6RcGLq1ucWSX1',
  },
  auth: {
    tokenHost: 'https://login.microsoftonline.com',
    authorizePath: 'common/oauth2/v2.0/authorize',
    tokenPath: 'common/oauth2/v2.0/token'
  }
};
var oauth2 = require('simple-oauth2').create(credentials);

//var redirectUri = 'https://outlookmurex.azurewebsites.net/authorize';
var redirectUri = 'https://aneychatbot.azurewebsites.net/microsoft/authorize';
// The scopes the app requires

var scopes = [ 'openid',
               'offline_access',
               'https://outlook.office.com/mail.read' ,
               'https://outlook.office.com/mail.readwrite',
               'https://outlook.office.com/calendars.read',
               'https://outlook.office.com/calendars.readwrite'];

    
function getAuthUrl() {
  var returnVal = oauth2.authorizationCode.authorizeURL({
    redirect_uri: redirectUri,
    scope: scopes.join(' ')
  });
  return returnVal;
}
function getTokenFromCode(auth_code, callback, response) {
  var token;
  oauth2.authorizationCode.getToken({
    code: auth_code,
    redirect_uri: redirectUri,
    scope: scopes.join(' ')
  }, function (error, result) {
    if (error) {
      console.log('Access token error: ', error.message);
      callback(response, error, null);
    } else {
      token = oauth2.accessToken.create(result);
      console.log('Token created: ', token.token);
      callback(response, null, token);
    }
  });
}

function refreshAccessToken(refreshToken, callback) {
  var tokenObj = oauth2.accessToken.create({refresh_token: refreshToken});
  tokenObj.refresh(callback);
}

exports.refreshAccessToken = refreshAccessToken;


exports.getTokenFromCode = getTokenFromCode;
exports.getAuthUrl = getAuthUrl;