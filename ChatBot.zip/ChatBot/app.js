const finalBaseUrl = "https://directline.botframework.com";
//const proxy='http://proxy.tcs.com:8080';// or blank for without proxy
        const proxy = '';
        var request = require('request');
var secret = 'zHSpUGCrpHM.cwA.J6Y.EEDr32UlF7Kx9RdQuigCymlK7JXTRWrIbYJv_Ne398M'; //aney secret key
//var secret = 'KnH8GQzHGIY.cwA.0lE.OqbHPnUs21aIDg5IgrOXE738_dfsCgBE-Hb6pDaA8D8';//abhinav allen bot
//var secret='ZGP0pE_Vcp0.cwA.GW4.g4A52WJ20_a3sx9JaOmuwysQrrfQ_4ScW1QkT-gO-4k';//LUise allen bot
exports.initConvo = function (callback) {
//function initConvo(callback){
    request({
        method: 'POST',
        uri: finalBaseUrl + '/v3/directline/conversations',
        proxy: proxy,
        headers: {
            'Authorization': ' Bearer ' + secret,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    }, function (err, response, body) {
        //console.loge.log(err)
        if (err) {
            callback(true, err)
        } else {
            callback(false, response.body);
        }
    });
};

exports.translationToken = function (result,callback) {
    request({
        method: 'POST',
        uri: 'https://api.cognitive.microsoft.com/sts/v1.0/issueToken',
        
        headers: {
            'Ocp-Apim-Subscription-Key':'1401c7ac5fee4b57b333ef8194e8e967'
        }
    }, function (err, response, body) {
        //console.loge.log(err)
        if (!err && response.statusCode ==200) {
          console.log(response.body);
        } else {
            console.log(response.body);
            
        }
    });
};

exports.refreshToken = function (result,callback) {
    result = JSON.parse(result);
//function initConvo(callback){
    request({
        method: 'POST',
        uri: finalBaseUrl + '/v3/directline/tokens/refresh',
        proxy: proxy,
        headers: {
            'Authorization': ' Bearer ' + result.token,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    }, function (err, response, body) {
        //console.loge.log(err)
        if (err) {
            callback(true, err)
        } else {
            
            callback(false, response.body);
        }
    });
};

exports.postActivity = function (result, msg, userId, callback) {
//function postActivity(result,msg,userId,callback){
console.log("hello send messges I am here")
console.log(typeof result);
try{
    result = JSON.parse(result);
}catch(e){
    result=result;
}
    
    var url = finalBaseUrl + '/v3/directline/conversations/' + result.conversationId + '/activities';
    //console.loge.log(url);
    //console.log("Url above");


//     request({
//         method: 'POST',
//         uri: 'https://api.api.ai/v1/query?v=2015910',
//         body: JSON.stringify({
//  query: msg, lang: "en", sessionId: "somerandomthing" 
          
//         }),
//         proxy: proxy,
//         headers: {
//             'Authorization': "Bearer"+'2d5b625cea2e4fedb26badf6653acb35',
//             'Content-Type': 'application/json'
//         }
//     }, function (err, response, body) {
//         if (err) {
            
//             console.log("error",err);
//             callback(true, err)
//         } else {
            
//             console.log(response.body);
//             callback(false, response.body);
//         }
//     });



    request({
        method: 'POST',
        uri: finalBaseUrl + '/v3/directline/conversations/' + result.conversationId + '/activities',
        body: JSON.stringify({
            "type": "message",
            "channelId": "directline",
            "from": {
                "id": userId
            },
            "text": msg
        }),
        proxy: proxy,
        headers: {
            'Authorization': ' Bearer ' + result.token,
            'Content-Type': 'application/json'
        }
    }, function (err, response, body) {
        if (err) {
            callback(true, err)
        } else {
            
            //console.log(response.body);
            callback(false, response.body);
        }
    });
}
exports.getBotMessage = function (conDetail, callback) {
//	function getBotMessage(conDetail,callback){
    conDetail = JSON.parse(conDetail);
    request({
        method: 'GET',
        uri: finalBaseUrl + '/v3/directline/conversations/' + conDetail.conversationId + '/activities ',
        proxy: proxy,
        headers: {
            'Authorization': ' Bearer ' + conDetail.token,
            'Content-Type': 'application/json'
        }
    }, function (err, response, body) {
        if (err) {
            callback(true, err)
        } else {
            
            callback(false, response.body);
        }
    });


};

exports.getConversations=function (conDetail,callback){
//	function getBotMessage(conDetail,callback){
//console.log(conDetail);
	conDetail=JSON.parse(conDetail);
			request({
				method: 'GET',
				uri: finalBaseUrl+'/v3/directline/conversations/'+conDetail.conversationId+'/activities ',
				proxy:proxy,
				headers: {
					'Authorization': ' Bearer ' + conDetail.token,
					'Content-Type': 'application/json'
				}
			}, function(err, response,body) {
				if (err){
					callback(true,err)
				}else{
                    console.log("In app -->>>",response.body);
					callback(false,response.body);
				}
		});
};


//Right Answer
exports.getRightAnswer=function(query,callback){
//function getOneRow(tableName,callback){
	request({
			method: 'GET',
			uri:'https://tcsdemo.rightanswers.com/portal/api/rest/search?companyCode=tcs&appInterface=ss&queryText='+query,
			headers: {
				'Authorization': 'Basic VENTRW5kVXNlcjpVc2VyQDEyMw==',
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			}
		}, function(err, response,body) {
			if (err){
				callback(true,err);
			}else{
				if(response.statusCode===200){
					//console.log(response);
					callback(false,JSON.parse(response.body));
				}else{
					callback(true,response.body);
				}
			}
	});
};

exports.getRightAnswerDoc=function(id,callback){
//function getOneRow(tableName,callback){
console.log("RA Doc id is"+id);
id=id;
var url='https://tcsdemo.rightanswers.com/portal/api/rest/solution/'+id+'?companyCode=tcs&appInterface=ss';
	request({
			method: 'GET',
			uri:url,
			headers: {
				'Authorization': 'Basic VENTRW5kVXNlcjpVc2VyQDEyMw==',
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			}
		}, function(err, response,body) {
			if (err){
				callback(true,err);
			}else{
				if(response.statusCode===200){
					//console.log(response);
					callback(false,JSON.parse(response.body));
				}else{
					callback(true,response.body);
				}
			}
	});
};

exports.dummy=function() {
    
    console.log("Hellooooooooo!!!");
}




exports.getWeatherDetails = function (city, country, callback) {
//	function getBotMessage(conDetail,callback){
    //url = JSON.parse(url);
    var searchtext ="https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%3D%22"+city+" "+country+"%22)&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";
     request({
        method: 'GET',
        uri: searchtext,
        proxy: proxy,
        headers: {
           
            'Content-Type': 'application/json'
        }
        
    }, function (err, response, body) {
        if (err) {
            callback(true, err);
        } else {
            
            //console.loge.log(response.body);
            callback(false, response.body);
        }
    });
};

exports.getNews = function (callback) {
    var available_src=["abc-news-au", "ars-technica", "associated-press", "bbc-news", "bbc-sport", "bild", "bloomberg", "business-insider", "business-insider-uk", "buzzfeed", "cnbc", "cnn", "daily-mail", "der-tagesspiegel", "die-zeit", "engadget", "entertainment-weekly", "espn", "espn-cric-info", "financial-times", "focus", "football-italia", "fortune", "four-four-two", "fox-sports", "google-news", "gruenderszene", "hacker-news", "handelsblatt", "ign", "independent", "mashable", "metro", "mirror", "mtv-news", "mtv-news-uk", "national-geographic", "new-scientist", "newsweek", "new-york-magazine", "nfl-news", "polygon", "recode", "reddit-r-all", "reuters", "sky-news", "sky-sports-news", "spiegel-online", "t3n", "talksport", "techcrunch", "techradar", "the-economist", "the-guardian-au", "the-guardian-uk", "the-hindu", "the-huffington-post", "the-lad-bible", "the-new-york-times", "the-next-web", "the-sport-bible", "the-telegraph", "the-times-of-india", "the-verge", "the-wall-street-journal", "the-washington-post", "time", "usa-today", "wired-de", "wirtschafts-woche"];
    var key='1f70656895bd432581995b79eb28a85c';
    var url='https://newsapi.org/v1/articles?source='+available_src[3]+'&apiKey='+key;
    
     request({
        method: 'GET',
        uri: url,
        proxy: proxy,
        headers: {
           
            'Content-Type': 'application/json'
        }
        
    }, function (err, response, body) {
        if (err) {
            callback(true, err);
        } else {
            callback(false, response.body);
        }
    });
};

