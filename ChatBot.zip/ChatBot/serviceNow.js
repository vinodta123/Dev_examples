const finalBaseUrlCRUD = "https://tcscbc1.service-now.com/api/now/v1/table/";
const reportBaseUrl='https://tcscbc1.service-now.com/api/now/v1/stats/';
const proxy='http://proxy.tcs.com:8080';// or blank for without proxy
const user='ignio_SHELL';
const password='Ignio03@2017';
var request = require('request');
var request = require('request');
//request=request.defaults({'proxy':proxy});//for TCS proxy
//console.log(new Buffer(user+":"+password).toString('base64'))
//console.log(new Buffer(password).toString('base64'))
//completed
/*getAllRow('incident',function(err,res){
	console.log(res);
});*/

/*addNewItem('incident','I have problme with my pc.',function(err,number){
	console.log(number);
});*/

/*getOneRow('incident','INC0010014',function(err,res){
	console.log(res);
});*/

exports.getAllRow=function(tableName,callback){
//function getOneRow(tableName,callback){
	request({
			method: 'GET',
			uri: finalBaseUrlCRUD+tableName+"?sys_created_by="+user,
			headers: {
				'Authorization': 'Basic ' + new Buffer(user+":"+password).toString('base64'),
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			}
		}, function(err, response,body) {
			if (err){
				callback(true,err)
			}else{
				if(response.statusCode===200){
					//console.log(response);
					callback(false,JSON.parse(response.body).result);
				}else{
					callback(true,response.body);
				}
			}
	});
}



exports.addNewItem=function(tableName,obj,callback){

console.log(obj);
	request({
			method: 'POST',
			uri: finalBaseUrlCRUD+tableName,
			headers: {
				'Authorization': 'Basic ' + new Buffer(user+":"+password).toString('base64'),
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			},
			body:JSON.stringify(obj)
		}, function(err, response,body) {
			if (err){
				console.log('error',response);
				callback(true,err)
			}else{
				if(response.statusCode===201){
					console.log('201',response);
					callback(false,JSON.parse(response.body).result.number);
				}else{
					console.log(response);
					callback(true,response.body);
				}
			}
	});
}


exports.updateItem=function(tableName,obj,sysId,callback){

	request({
			method: 'PUT',
			uri: finalBaseUrlCRUD+tableName+'/'+sysId,
			headers: {
				'Authorization': 'Basic ' + new Buffer(user+":"+password).toString('base64'),
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			},
			body:JSON.stringify(obj)
		}, function(err, response,body) {
			if (err){
				console.log('error',response);
				callback(true,err)
			}else{
				if(response.statusCode===200){
					console.log('200 der',response);
					console.log('Response body: ' + response.body);
					callback(false,JSON.parse(response.body).result.number);
				}else{
					console.log(response);
					callback(true,response.body);
				}
			}
	});
}




exports.addNewServiceRequest=function(tableName,obj,callback){
//function addNewItem(tableName,des,callback){
	request({
			method: 'POST',
			uri: finalBaseUrlCRUD+tableName,
			headers: {
				'Authorization': 'Basic ' + new Buffer(user+":"+password).toString('base64'),
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			},
			body:JSON.stringify(obj)
		}, function(err, response,body) {
			if (err){
				callback(true,err)
			}else{
				if(response.statusCode===201){
					callback(false,JSON.parse(response.body).result.number);
				}else{
					callback(true,response.body);
				}
			}
	});
}


exports.getOneRow=function(tableName,id,callback){
//function getOneRow(tableName,number,callback){
	request({
			method: 'GET',
			uri: finalBaseUrlCRUD+tableName+"?number="+id,
			headers: {
				'Authorization': 'Basic ' + new Buffer(user+":"+password).toString('base64'),
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			}
		}, function(err, response,body) {
			if (err){
				callback(true,err)
			}else{
				if(response.statusCode===200){
					callback(false,JSON.parse(response.body).result);
				}else{
					callback(true,response.body);
				}
			}
	});
}

exports.incident_report=function(by,callback){
//function incident_report(by,callback){
	request({
			method: 'GET',
			uri: reportBaseUrl+"incident?sysparm_count=true&sysparm_display_value=all&sysparm_group_by="+by,
			headers: {
				'Authorization': 'Basic ' + new Buffer(user+":"+password).toString('base64'),
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			}
		}, function(err, response,body) {
			if (err){
				callback(true,err)
			}else{
				if(response.statusCode===200){
					callback(false,JSON.parse(response.body).result);
				}else{
					callback(true,response.body);
				}
			}
	});
}


