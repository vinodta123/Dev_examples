var express = require('express');
var builder = require('botbuilder');
var bodyParser = require('body-parser');
var session = require('express-session');
var botIntraction = require('./app.js');//bot interface
var serviceNow = require('./serviceNow.js');//Service Now interface
  var request = require('request');
//requires for MS AUth
var url = require('url');
var outlook = require('node-outlook');
var authHelper = require('./authHelper');
//
var translatorToken;
// Setup Express App Server
var app = express();
app.use(bodyParser.json());
app.use(express.static('public'));
app.use(bodyParser.json());

app.use(session({
    secret: 'somesecretgoeshere',
    resave: false,
    saveUninitialized: true
}));
// microsoft authentication appllication level
app.get('/auth/microsoft', function (req, res) {
    res.redirect(authHelper.getAuthUrl());
});
app.get('/microsoft/authorize', function (req, res) {
  // The authorization code is passed as a query parameter
  var url_parts = url.parse(req.url, true);
  var code = url_parts.query.code;
  //console.log('Code: ' + code);
  authHelper.getTokenFromCode(code, tokenReceived, res);
});
//getting calendar data and events
app.get('/microsoft/calender', function (request, response) {
    //console.log("In MS Calender");
    getAccessToken(request, response, function(error, token) {
    //console.log('Token found in cookie: ', token);
    var email = getValueFromCookie('node-tutorial-email', request.headers.cookie);
    //console.log('Email found in cookie: ', email);
    if (token) {
var queryParams = {
  '$select': 'Subject,Start,End,Location,BodyPreview',
  '$orderby': 'Start/DateTime asc',
  '$top':100
};

// Set the API endpoint to use the v2.0 endpoint
outlook.base.setApiEndpoint('https://outlook.office.com/api/v2.0');
// Set the anchor mailbox to the user's SMTP address
outlook.base.setAnchorMailbox(email);
// Set the preferred time zone.
// The API will return event date/times in this time zone.
outlook.base.setPreferredTimeZone('Eastern Standard Time');

outlook.calendar.getEvents({token: token, odataParams: queryParams},
  function(error, result){
    if (error) {
      //console.log('getEvents returned an error: ' + error);
      response.send({status:false,data:error});
      response.end();
    } else if (result) {
      //console.log('getEvents returned ' + result.value.length + ' events.');
      response.send({status:true,data:result.value});
      response.end();
    }
  });
  }
   });
});
//update calendar data and events
app.post('/microsoft/calenderUpdate', function (request, response) {
    var start=request.body.start;
    var end=request.body.end;
    var eventId=request.body.eventId;
    //console.log("=============== event id");
    console.log(start, end);
    getAccessToken(request, response, function(error, token) {
    //console.log('Token found in cookie: ', token);
    var email = getValueFromCookie('node-tutorial-email', request.headers.cookie);
    //console.log('Email found in cookie: ', email);
    if (token) {
        // Set the API endpoint to use the v2.0 endpoint
        outlook.base.setApiEndpoint('https://outlook.office.com/api/v2.0');
        //var eventId = 'AQMkADAwATM3ZmYAZS0wNWRjLTlkMWMtMDACLTAwCgBGAAADySAevMhDg06GL5icTrTqIwcA3xBmKP3f_0KgF44d3OjQlwAAAgENAAAA3xBmKP3f_0KgF44d3OjQlwAAABBavegAAAA=';
    
    // Update the location
    var update = {
      Start: {
        DateTime: start,
        TimeZone:"Eastern Standard Time"
      },
      End: {
        DateTime: end,
        TimeZone:"Eastern Standard Time"
      },
    };
    
    // Pass the user's email address
    var userInfo = {
      email: email
    };
    
    outlook.calendar.updateEvent({token: token, eventId: eventId, update: update, user: userInfo},
      function(error, result){
        if (error) {
          //console.log('updateEvent returned an error: ' + error);
          response.send({status:false,data:error});
        }
        else if (result) {
            //console.log(result);
          response.send({status:true,data:result});
          //console.log(result);
        }
        response.end();
      });
    }
   });
});
//Cancel calendar data and events
app.post('/microsoft/calenderCancel', function (request, response) {
    var eventId=request.body.eventId;
    //console.log("=============== event id");
    //console.log(eventId);
    getAccessToken(request, response, function(error, token) {
    //console.log('Token found in cookie: ', token);
    var email = getValueFromCookie('node-tutorial-email', request.headers.cookie);
    //console.log('Email found in cookie: ', email);
    if (token) {
        // Set the API endpoint to use the v2.0 endpoint
        outlook.base.setApiEndpoint('https://outlook.office.com/api/v2.0');
        //var eventId = 'AQMkADAwATM3ZmYAZS0wNWRjLTlkMWMtMDACLTAwCgBGAAADySAevMhDg06GL5icTrTqIwcA3xBmKP3f_0KgF44d3OjQlwAAAgENAAAA3xBmKP3f_0KgF44d3OjQlwAAABBavegAAAA=';
    
    // Pass the user's email address
    var userInfo = {
      email: email
    };
    
    outlook.calendar.deleteEvent({token: token, eventId: eventId, user: userInfo},
      function(error, result){
        if (error) {
          response.send({status:false,data:error});
          response.end();
        }
        else if (result) {
          response.send({status:false,data:result});
          response.end();
        }else{
            response.send({status:true,data:"deleted"});
        }
        
      });
    }
   });
});
//all common function regarding MS calender and Mail API
function getUserEmail(token, callback) {
  // Set the API endpoint to use the v2.0 endpoint
  outlook.base.setApiEndpoint('https://outlook.office.com/api/v2.0');

  // Set up oData parameters
  var queryParams = {
    '$select': 'DisplayName, EmailAddress',
  };
  outlook.base.getUser({token: token, odataParams: queryParams}, function(error, user){
    if (error) {
      callback(error, null);
    } else {
        //console.log("================");
        //console.log(user);
      callback(null, user.EmailAddress,user.DisplayName);
    }
  });
}

function tokenReceived(response, error, token) {
  if (error) {
    //console.log('Access token error: ', error.message);
    response.writeHead(200, {'Content-Type': 'text/html'});
    response.write('<p>ERROR: ' + error + '</p>');
    response.end();
  } else {
    getUserEmail(token.token.access_token, function(error, email,name){
      if (error) {
        //console.log('getUserEmail returned an error: ' + error);
        response.write('<p>ERROR: ' + error + '</p>');
        response.end();
      } else if (email) {
        //console.log(token.token.access_token);
        var cookies = ['node-tutorial-token=' + token.token.access_token + ';Max-Age=4000',
                       'node-tutorial-refresh-token=' + token.token.refresh_token + ';Max-Age=4000',
                       'node-tutorial-token-expires=' + token.token.expires_at.getTime() + ';Max-Age=4000',
                       'node-tutorial-name=##' + name + '##;Max-Age=4000',
                       'node-tutorial-email=' + email + ';Max-Age=4000'];
                       console.log(name );
        response.setHeader('Set-Cookie', cookies);
        response.cookie('cookie', cookies);
        response.writeHead(302, {'Location': 'http://aneychatbot.azurewebsites.net/chat.html'});
        response.end();
      }
    }); 
  }
}
function getValueFromCookie(valueName, cookie) {
  if (cookie.indexOf(valueName) !== -1) {
    var start = cookie.indexOf(valueName) + valueName.length + 1;
    var end = cookie.indexOf(';', start);
    end = end === -1 ? cookie.length : end;
    return cookie.substring(start, end);
  }
}


function getAccessToken(request, response, callback) {
  var expiration = new Date(parseFloat(getValueFromCookie('node-tutorial-token-expires', request.headers.cookie)));

  if (expiration <= new Date()) {
    // refresh token
    //console.log('TOKEN EXPIRED, REFRESHING');
    var refresh_token = getValueFromCookie('node-tutorial-refresh-token', request.headers.cookie);
    authHelper.refreshAccessToken(refresh_token, function(error, newToken){
      if (error) {
        callback(error, null);
      } else if (newToken) {
        var cookies = ['node-tutorial-token=' + newToken.token.access_token + ';Max-Age=4000',
                       'node-tutorial-refresh-token=' + newToken.token.refresh_token + ';Max-Age=4000',
                       'node-tutorial-token-expires=' + newToken.token.expires_at.getTime() + ';Max-Age=4000'];
        response.setHeader('Set-Cookie', cookies);
        callback(null, newToken.token.access_token);
      }
    });
  } else {
    // Return cached token
    var access_token = getValueFromCookie('node-tutorial-token', request.headers.cookie);
    callback(null, access_token);
  }
}





//End of MS Calender and Mails API
app.get('/getRA', function (req, res) {
   var query= req.query.query;
   //console.log(query);
    botIntraction.getRightAnswer(query,function(st,data){
        if(st){
            res.send({status:false,data:data});
        }
        else{
            res.send({status:true,data:data});
        }
        res.end();
    });
});
app.get('/getRADoc', function (req, res) {
   var id= req.query.id;
   //console.log(query);
    botIntraction.getRightAnswerDoc(id,function(st,data){
        if(st){
            res.send({status:false,data:data});
        }
        else{
            res.send({status:true,data:data});
        }
        res.end();
    });
});
app.post('/refreshToken', function (req, res) {
    var userId = req.body.userId;
    botIntraction.refreshToken(req.session.user_con_details,function (err, tokenDetail) {
        if (!err) {
            //tokenDetail=JSON.parse(tokenDetail);
            req.session.user_unique_id = userId;
            req.session.user_con_details = tokenDetail;
            //console.log("Unique User Id" + req.session.user_unique_id);
            //console.log("Unique Convo Token" + req.session.user_con_details);
            res.send({ status: true, msg: "You can now chat with bot.", tokenDetail: tokenDetail });
        } else {
            res.send({ status: false, msg: "Unable to initiate a chat" });
        }
        res.end();
    });
});

//genetrate a token for translation

// send message post request requred {msg,uId}
app.post('/login', function (req, res) {
    // passport.authenticate('azuread-openidconnect', { resourceURL: config.resourceURL, customState: 'my_state', failureRedirect: '/' }),
  // function(req, res) {
    var userId = req.body.userId;
    console.log('userId:' + userId);
    // var allowedIDs = ['Murex demo1', 'murex demo2', 'Murex demo3'];// disabling this in backend also 'abhianv 27th may'
    // var isAllowed = (allowedIDs.indexOf(userId) != -1);
   if(true){
    //match data with backend tables or any services.
   console.log('allowed Id');
    botIntraction.initConvo(function (err, tokenDetail) {
        if (!err) {
            //tokenDetail=JSON.parse(tokenDetail);
            req.session.user_unique_id = userId;
            req.session.user_con_details = tokenDetail;
            res.send({ status: true, msg: "You can now chat with bot.", tokenDetail: tokenDetail });
        } else {
            res.send({ status: false, msg: "Unable to initiate a chat" });
        }
        res.end();
    });
   }else{
        console.log('not allowed');//not allowed
        
         res.send({ status: false, msg: "Unable to initiate a chat" });
       
        res.end();
    }
});

app.get('/getconversation',function(req, res){
   // var message = req.body.message;
   // var userId = 'chesta';
    var user_con_details = req.session.user_con_details;
    console.log(user_con_details);
    botIntraction.getConversations(user_con_details, function (err, delivery) {
        if (!err) {
            //console.log("In server--->>>>", delivery);
            res.send({ status: true, data: delivery });
            res.end();
        } else {
            res.send({ status: false, msg: 'Unable to connect to bot.' });
            res.end();
        }

    });
 });

app.post('/sendMessage', function (req, res) {
    var message = req.body.message;
    var userId = req.body.userId;
    var user_con_details = req.session.user_con_details;
    // conversion
    request({
        method: 'POST',
        uri: 'https://api.cognitive.microsoft.com/sts/v1.0/issueToken',
        
        headers: {
            'Ocp-Apim-Subscription-Key':'1401c7ac5fee4b57b333ef8194e8e967'
        }
    }, function (err, response, body) {
        //console.loge.log(err)
        if (!err && response.statusCode ==200) {
          console.log(response.body);
          translatorToken=response.body;
          } else {
            console.log(err);
            
        }
    });
     request({
        method: 'GET',
        uri: 'https://api.microsofttranslator.com/V2/Http.svc/Translate',
        
        params: {
            'appid':'Bearer '+ translatorToken,
            'text':'hello',
            'to':'de'
        }
    }, function (err, response, body) {
        //console.loge.log(err)
        if (!err && response.statusCode ==200) {
          console.log(response.body);
            console.log('in get');
          } else {
            console.log(err);
            
        }
    });
   //end
    botIntraction.postActivity(user_con_details, message, userId, function (err, delivery) {
        if (!err) {
            //console.log("seeeeeeeeeeeeeeeeeeeeeeeeeerver",delivery); 
            //res.send({ status: true, msg:delivery.result.fulfillment.speech});// "Message Sent" });
            
            res.send({ status: true, msg:"Message Sent" });
            res.end();
        } else {
            //console.log(res);
            res.send({ status: false, msg: 'Unable to connect to bot.' });
            res.end();
        }
    });
});
 
//To get Weather from Yahoo API
app.get('/getWeather', function (req, res) {
     var city = req.query.city;
     var country = req.query.country;
    botIntraction.getWeatherDetails(city, country, function (err, delivery) {
        if (!err) {
            res.send({ status: true, data: delivery });
            res.end();
        } else {
            res.send({ status: false, msg: 'Unable to connect to bot.' });
            res.end();
        }

    });
});
app.get('/getNews', function (req, res) {
    botIntraction.getNews(function (err, delivery) {
        if (!err) {

            res.send({ status: true, data: delivery });
            res.end();
        } else {
            res.send({ status: false, msg: 'Unable to connect to bot.' });
            res.end();
        }

    });
});

app.get('/getReports', function (req, res) {
    serviceNow.getAllRow('incident',function (err, delivery) {
        if (!err) {
            //console.log(delivery);
            res.send({ status: true, data: delivery });
            res.end();
        } else {
            res.send({ status: false, msg: 'Unable to connect to bot.' });
            res.end();
        }

    });
});

app.get('/getTasks', function (req, res) {
    serviceNow.getAllRow('sc_task',function (err, delivery) {
        if (!err) {
            //console.log(delivery);
            res.send({ status: true, data: delivery });
            res.end();
        } else {
            res.send({ status: false, msg: 'Unable to connect to bot.' });
            res.end();
        }

    });
});

app.post('/postIncident', function (req, res) {
    if(req.body.update){
        //update case
        console.log('update case');
        
        serviceNow.getOneRow('incident',req.body.number,function(err,d){
            var sysid=d[0].sys_id;;
            console.log("Got sys id sednidng update");
            delete req.body.update;
            delete req.body.number;
            serviceNow.updateItem('incident',req.body,sysid,function (err, delivery) {
                if (!err) {
                    res.send({ status: true, data: delivery });
                    res.end();
                } else {
                    res.send({ status: false, data: 'Unable to rais the incident' });
                    res.end();
                }
             });  
        });
        
        
    }else{
        serviceNow.addNewItem('incident',req.body,function (err, delivery) {
        if (!err) {
            res.send({ status: true, data: delivery });
            res.end();
        } else {
            res.send({ status: false, data: 'Unable to rais the incident' });
            res.end();
        }

    });    
    }
    
});

app.post('/postRequest', function (req, res) {
    
    serviceNow.addNewItem('sc_task',req.body,function (err, delivery) {
        if (!err) {
            res.send({ status: true, data: delivery });
            res.end();
        } else {
            res.send({ status: false, data: 'Unable to raise the incident' });
            res.end();
        }

    });
});


app.put('/updateIncident', function (req, res) {

    serviceNow.updateItem('incident',req.body,req.body.id,function (err, delivery) {
        if (!err) {
            res.send({ status: true, data: delivery });
            res.end();
        } else {
            res.send({ status: false, data: 'Unable to raise the incident'});
            res.end();
        }

    });
});




app.get('/inciItem', function (req, res) {
    serviceNow.getOneRow('incident',req.query.itemId,function (err, delivery) {
        if (!err) {
            //console.log(delivery)
            res.send({ status: true, data: delivery });
            res.end();
        } else {
            res.send({ status: false, data: 'Unable to get incident details.' });
            res.end();
        }

    });
});

app.get('/reqItem', function (req, res) {
    serviceNow.getOneRow('sc_task',req.query.itemId,function (err, delivery) {
        if (!err) {
            //console.log(delivery)
            res.send({ status: true, data: delivery });
            res.end();
        } else {
            res.send({ status: false, data: 'Unable to get incident details.' });
            res.end();
        }

    });
});




app.get('/serviceNowReport',function(req,res){
	var by=req.query.by;
	serviceNow.incident_report(by,function(err,result){
		if(!err){
			res.send({"status":true,data:result});
			res.end();
		}else{
			res.send({"status":true,data:"Unable to get the report."});
			res.end();
		}
	});
	
});
app.listen(process.env.PORT, function () {
    console.log('Example app listening on port 8080!');
});

//=========================================================
// Bot Setup
//=========================================================

//**************************************************************BOT Dialogs*****************Bot Intents Config*********************Bot Response*************** 
// Create chat Allen Abhinav Login
var connector = new builder.ChatConnector({
    appId: 'e6b3e0cf-75d3-4935-b8c8-53a30fc483c1',
    appPassword: 'iWrk5nW2ph4BWCjmuZDD1RV'
    //appId: '4797a22b-ce48-4531-a99e-abaf7ad01a4f',
    //appPassword: 'kSsMV6NEbmcwQ2PfKccucfz'
});

var bot = new builder.UniversalBot(connector);
app.post('/api/messages', connector.listen());

//=========================================================
// Bots Dialogs
//=========================================================

/*bot.dialog('/', function (session) {
 session.send("Hello World");
 });*/

// Main dialog with LUIS
//Murex Lusi url
//var LuisModelUrl ='https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/ee6a8748-8d1a-4082-8aeb-a1487e5a6115?subscription-key=98d0ccbd6f1a4659af61cda595633442&verbose=true&q=';
//var LuisModelUrlRandom ='https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/8a9617d9-20b1-4aea-81a5-d5da8c899210?subscription-key=98d0ccbd6f1a4659af61cda595633442&verbose=true&q=';
//var LuisModelRequest ='https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/c09fb699-9ff3-45bb-b1be-fd813a048833?subscription-key=6efad75ac71e4df98148ad5f48062d16&verbose=true&spellCheck=true&q=';
var LuisModelUrlRandom='https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/4c95bcdc-e57a-4b12-8c54-8b1b9421f6a7?subscription-key=98d0ccbd6f1a4659af61cda595633442&verbose=true&timezoneOffset=0&q=';
var LuisModelUrl='https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/8e76281d-377c-4388-bc38-acbc57fd4709?subscription-key=98d0ccbd6f1a4659af61cda595633442&verbose=true&timezoneOffset=0&q=';

var recognizer = new builder.LuisRecognizer(LuisModelUrl);
var recognizerRandom = new builder.LuisRecognizer(LuisModelUrlRandom);
//var recognizerRequest = new builder.LuisRecognizer(LuisModelRequest);

var intents = new builder.IntentDialog( { recognizers: [recognizer,recognizerRandom] })
    .matches('None', function (session, args) {
         //console.log("In default now.............");
        defaultAction(session);

}).matches('Greeting', function (session, args) {
    //session.send('{"msg":"Hi John!, How can I help you?","type":"radioOption","Options": [{"Option":"Resolve Now"}, {"Option":"My Calendar"}, {"Option":"My News"}, {"Option":"Request Now"},{"Option":"I can’t find the question I want to ask!"}]}');
    //console.log(typeof session.message);
    //console.log(session.message);
    var name="Friend";
    //console.log(args);
    session.send('{"msg":"Hi '+name+' ! I am Aney, your virtual assistant! How may I assist you?","category":"Greetings","type":"message"}');

}) .matches('DateTime', function (session, args) {
    //console.log("======In date time=============");
   
    // if (!entity) {
            // Verify its in our set of alarms.
           session.send('Please specify meeting start time or Topic '); 
       // }
       // else{
        //   session.send('Please specify meeting start time or Topic');
         
        //}

}).matches('DateToRC', function (session, args) {
    //this is for both to show event either for cancel or reschedule
    
    
    //console.log("======In date time=============");
    //console.log(args);
    //session.send('{"msg":"Hi John!, How can I help you?","type":"radioOption","Options": [{"Option":"Resolve Now"}, {"Option":"My Calendar"}, {"Option":"My News"}, {"Option":"Request Now"},{"Option":"I can’t find the question I want to ask!"}]}');
    //session.send('{"msg":"Hi John ! I am Murex, your virtual assistant! How may I help you?","category":"My News","type":"message"}');
    // var entity = builder.EntityRecognizer.findEntity(args.entities, 'daterc'); 
    // console.log('ENtity',entity.entity);
    // if (!entity) {
            // Verify its in our set of alarms.s
           //session.send('{"msg":"Please specify the start time or topic","category":"MyCalendar","type":"message"}');
      // if (session.message.text.match('Mon(27 Mar)')) {
        console.log(session.message.text);
        //session.send('{"msg":"These are the events for '+session.message.text+'","category":"MyCalendar","type":"message"}');
        
        
        session.send('{"msg":"These are the events for '+session.message.text+'","category":"My Calendar","type":"showEvent","date":"'+ session.message.text +'"}');
        
        session.userData.MeetingDay=session.message.text;
        
        
        
        
        
     //session.send('{"msg":"Hi John!, How can I help you?","type":"radioOption","Options": [{"Option":"Resolve Now"}, {"Option":"My Calendar"}, {"Option":"My News"}, {"Option":"Request Now"},{"Option":"I can’t find the question I want to ask!"}]}');
       //session.send('{"msg":"Please specify ","category":"My Calendar", "type":"radioOption","Options": [{"Option":"Lunch meet 17.30"}, {"Option":"Shell Demo1 23:30"}, {"Option":"Shell call 7.30"}, {"Option":"Team Meeting1 9.30"}, {"Option":"Lunch 12.30"},{"Option":"Daily standup 15.30"},{"Option":"Shell demo1 20.30"}]}');
       
        // }
            
         /*if (session.message.text.match('Tue(28 Mar)')) {

        session.send('{"msg":"Your events for Tuesday","category":"MyCalendar","type":"message"}');
        session.send('{"msg":"Please specify ","category":"My Calendar", "type":"radioOption","Options": [{"Option":"Shell demo1(17.30)"}, {"Option":"Shell Demo2(22:30)"}, {"Option":"Shell call(7.30)"}, {"Option":"Demo Meet 2(13.30)"}, {"Option":"Murex Meet (16.30)"}]}');
             }*/
           
        //      if (session.message.text.match('Wed(29 Mar)')) {

        // session.send('{"msg":"Your events for Wednesday","category":"MyCalendar","type":"message"}');
       // session.send('{"msg":"Please specify ","category":"My Calendar", "type":"radioOption","Options": [{"Option":"Shell meeting(13.30)"}, {"Option":"Murex meet(8:30)"}]}');
        //     }
            
        //      if (session.message.text.match('Thu(30 Mar)')) {

        //        session.send('{"msg":"Your events for Thursday","category":"MyCalendar","type":"message"}');
        //         session.send('{"msg":"I could not find a meeting","category":"MyCalendar","type":"message"}');
       // //session.send('{"msg":"Please specify ","category":"My Calendar", "type":"radioOption","Options": [{"Option":"Shell meeting(13.30)"}, {"Option":"Murex meet(8:30)"}]}');
        //     }
            
        //     if (session.message.text.match('Fri(31 Mar)')) {

        //        session.send('{"msg":"Your events for Friday","category":"MyCalendar","type":"message"}');
        //         session.send('{"msg":"I could not find a meeting","category":"MyCalendar","type":"message"}');
       // //session.send('{"msg":"Please specify ","category":"My Calendar", "type":"radioOption","Options": [{"Option":"Shell meeting(13.30)"}, {"Option":"Murex meet(8:30)"}]}');
        //     }
       // //  };
         
         
        
            
       // }
       // else{
        //   session.send('Please specify meeting start time or Topic');
         
        //}

})
.matches('LoginIssue', function (session, args) {
    session.send('{"msg":"Have you tried using the disk cleanup wizard present in your system?","category":"Resolve Now","type":"message"}');
    session.send('{"msg":"It is available at Start -> Programs -> Cleanup wizard","category":"Resolve Now","type":"message"}');

})
.matches('AneyFinal', function (session, args) {
    session.send('{"msg":"Aney is good","category":"My News","type":"message"}');

})
.matches('Murex', function (session, args) {
    session.send('{"msg":"Who me? I am your virtual assistant - Aney","category":"My News","type":"message"}');

}) .matches('MeetingRes', function (session, args) {
    console.log(session);
    // this is common for both cancel or reschedule the meeting.
    if(session.userData.meetingAction==="Cancel"){
        // new one dynamic for cancel
        session.send('{"msg":"Okay Got it ! Cancelling your meeting '+session.message.text+' .","category":"My Calendar","type":"message"}');
        session.send('{"msg":"","type":"meetingCancel","meeting":"'+session.message.text+'","day":"'+session.userData.MeetingDay+'"}');
    }else if(session.userData.meetingAction==="Reschedule"){
        // static one old one
         //session.send('{"msg":"Meeting has been rescheduled","category":"My Calendar","type":"message"}');
         //session.send('{"msg":"To what time do you want to reschedule? Please choose available options ","category":"My Calendar","type":"message"}');
         //session.send('{"msg":"Choices","category":"My Calendar","type":"radioOption","Options": [{"Option":"Tue 28 March 8.30"}, {"Option":"Wed 29 Mar 14.00"}, {"Option":"Thu 30 Mar 9.30"}, {"Option":"Fri 31 Mar 14.00"}]}');
         
         session.send('{"msg":"Please specify the new time and date for the meeting.","category":"My Calendar","type":"message"}');
         
    }
    
   

})
.matches('ChangeMeeting', function (session, args) {
    //session.send('{"msg":"Hi John!, How can I help you?","type":"radioOption","Options": [{"Option":"Resolve Now"}, {"Option":"My Calendar"}, {"Option":"My News"}, {"Option":"Request Now"},{"Option":"I can’t find the question I want to ask!"}]}');
   var date = builder.EntityRecognizer.findEntity(args.entities, "builtin.datetime.date");
   var time = builder.EntityRecognizer.findEntity(args.entities, "builtin.datetime.time"); 
   //var entity = builder.EntityRecognizer.findEntity(args.entities, 'builtin.geography.city'); 
    console.log(date,time);
   //session.send('{"msg":"In change meeting '+date.entity+time.entity+'","category":"My Calendar","type":"message"}');
   console.log(date,time);
   if(!date || !time){
       session.send('{"msg":"Sorry I did not get the date and time properly , try putting it like : Reschedule to 27th March at 09:00","category":"My Calendar","type":"message"}');
   }else {
       // check fro past date//
       console.log(date)
        console.log(time)
   }

})
.matches('relatives', function (session, args) {
    //session.send('{"msg":"Hi John!, How can I help you?","type":"radioOption","Options": [{"Option":"Resolve Now"}, {"Option":"My Calendar"}, {"Option":"My News"}, {"Option":"Request Now"},{"Option":"I can’t find the question I want to ask!"}]}');
    session.send('{"msg":"MOM","category":"My News","type":"message"}');

})
.matches('MurexDevelopment', function (session, args) {
    session.send('{"msg":"I was designed by the Digital Team at TATA Consultancy Services","category":"My News","type":"message"}');

})
.matches('MurexExistence', function (session, args) {
    session.send('{"msg":"Sorry John! I have been told to not entertain any queries questioning my existence","category":"My News","type":"message"}');

})
.matches('MurexAge', function (session, args) {
    session.send('{"msg":"Do you really need to know that? I am aged enough to be your virtual assistant","category":"My News","type":"message"}');

})
.matches('MurexGod', function (session, args) {
    session.send('{"msg":"Interesting question! I just believe in zeros and ones","category":"My News","type":"message"}');

})
.matches('MurexAssistant', function (session, args) {
    session.send('{"msg":"Wait… Are there other assistants?","category":"My News","type":"message"}');

})
.matches('MurexCIO', function (session, args) {
    session.send('{"msg":"Harry De Grijs is the CIO of Shell","category":"My News","type":"message"}');

})
.matches('MurexCEO', function (session, args) {
    session.send('{"msg":"Ben van Beurden is the CEO of Shell","category":"My News","type":"message"}');

})

.matches('builtin.intent.alarm.set_alarm', function (session, args) {
    session.send('Hi! This is the Alarm intent handler. I said: \'%s\'.', session.message.text);
})

.matches('Resolve Now', function (session, args) {
    session.send('{"msg":"Can you please specify what kind of issue do you have?","category":"Resolve Now","type":"message"}');
    session.send('{"msg":"These are the top issues raised by users.","category":"Resolve Now","type":"message"}');
    session.send('{"msg":"Please click on an option?","category":"Resolve Now","type":"radioOption","Options": [{"Option":"I have issues with my system"}, {"Option":"My printer has issues"},{"Option":"I want to reset my password"},{"Option":"Outlook issue"},{"Option":"Network drive issue"},{"Option":"My problem is not listed"} ]}');
      
})
.matches('VPN issue', function (session, args) {
    //session.send('{"msg":"I need help configuring a new VPN connection","category":"Resolve Now","type":"RACard","url":"#","summary":"I need help configuring a new VPN connection","doc_id":"041536502390673" }');
    //session.send('{"msg":"I keep getting disconnected from VPN","category":"Resolve Now","type":"RACard","url":"#","summary":"I keep getting disconnected from VPN","doc_id":"041536502390673" }');  
    session.send('{"msg":"Here is some information I can help you with to resolve your issue.","category":"Resolve Now","type":"message"}');
    botIntraction.getRightAnswer(session.message.text,function(st,data){
            if(st){
            }
            else{
                 for(var i=0;i<data.solutions.length;i++){
                session.send('{"msg":"'+ data.solutions[i].title +'","category":"Resolve Now","type":"RACard","url":"#","summary":"'+data.solutions[i].title+'","doc_id":"'+data.solutions[i].id+'" }');
                 }
            }
        });
    
    serviceNow.addNewItem('incident',{"short_description": session.message.text},function (err, delivery) {
            if (!err) {
                session.send('{"msg":"Meanwhile I am raising a ticket for your concern.","category":"Resolve Now","type":"message","id":"'+delivery+'"}');
                session.send('{"msg":"Was I able to help?","category":"Resolve Now","type":"boolean","Options": {"Option 1":"Yes", "Option 2":"No"}}');
            } else {
                session.send({ status: false, data: 'Unable to raise the incident' });
            }
        });
})
.matches('Outlook issue', function (session, args) {
    // session.send('{"msg":"I can not  send or receive emails","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-us/help/286040/how-to-troubleshoot-outlook-when-you-cannot-send-or-receive-e-mail","summary":"I can not send or receive emails"}');
    // session.send('{"msg":"I can not open attachement","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-in/help/2271150/you-cannot-open-linked-file-attachments-in-outlook-outlook-blocked-access-to-the-following-potentially-unsafe-attachments","summary":"I can not open attachement"}');
    // session.send('{"msg":"I need help compacting my pst","category":"Resolve Now","type":"Card","url":"https://support.office.com/en-us/article/Fix-your-Outlook-email-connection-by-repairing-your-profile-4d5febf6-7623-486b-9a9f-d5cfc4264af3","summary":"I need help compacting my pst"}');
    // session.send('{"msg":"I need help setting up a new profile","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-us/help/286040/how-to-troubleshoot-outlook-when-you-cannot-send-or-receive-e-mail","summary":"I need help setting up a new profile"}');
    // session.send('{"msg":"My outlook keep freezing and does not respond","category":"Resolve Now","type":"Card","url":"https://support.office.com/en-us/article/Outlook-not-responding-stuck-at-Processing-stopped-working-freezes-or-hangs-5C313D04-64AF-4441-82D2-44E5A43EEE5A?ui=en-US&rs=en-US&ad=US","summary":"My outlook keep freezing and does not respond"}');
    // session.send('{"msg":"I need help archiving emails","category":"Resolve Now","type":"Card","url":"https://support.office.com/en-us/article/Archive-older-items-manually-in-Outlook-for-Windows-fa03020e-55af-4eeb-94fb-925f640d942d","summary":"I need help archiving emails"}');
    // session.send('{"msg":"Create an email signature in Outlook","category":"Resolve Now","type":"Card","url":"https://www.youtube.com/watch?v=SBRk2VHQdlA","summary":"Create an email signature in Outlook"}');
    
    
    
    //session.send('{"msg":"I do not see the right option to choose","category":"Resolve Now","type":"Card","url":"#","summary":"I do not see the right option to choose" }');  
 session.send('{"msg":"Here is some information I can help you with to resolve your issue.","category":"Resolve Now","type":"message"}');

botIntraction.getRightAnswer(session.message.text,function(st,data){
        if(st){
            //console.log("In RA-->>", data);
            //session.send({status:false,data:data});
            //session.send('{"msg":data.title,"type":"Card","url":"#","summary":data.summary}');
        }
        else{
            
            //console.log("In RA else-->>", data);
            //console.log(typeof data);
            //session.send({status:true,data:data});
            
             for(var i=0;i<data.solutions.length;i++){
            
            session.send('{"msg":"'+ data.solutions[i].title +'","category":"Resolve Now","type":"RACard","url":"#","summary":"'+data.solutions[i].title+'","doc_id":"'+data.solutions[i].id+'" }');
             }
             
             //session.send('{"msg":"Please click on an option?","category":"Resolve Now","type":"radioOption","Options": [{"Option":"My computer starts slowly"}, {"Option":"My computer is very slow when browsing over the internet"}]}');
             
             
        }
        //session.end();
    });


serviceNow.addNewItem('incident',{"short_description": session.message.text},function (err, delivery) {
        if (!err) {
            session.send('{"msg":"Meanwhile I am raising a ticket for your concern.","category":"Resolve Now","type":"message","id":"'+delivery+'"}');
            session.send('{"msg":"Was I able to help?","category":"Resolve Now","type":"boolean","Options": {"Option 1":"Yes", "Option 2":"No"}}');
            //session.end();
        } else {
            //console.log("error!",err);
            session.send({ status: false, data: 'Unable to raise the incident' });
            //session.end();
        }

    });




})

.matches('Password Reset', function (session, args) {
    session.send('{"msg":"Please help me with the following information to reset your password","category":"Resolve Now","type":"message"}');
    //console.log("Password Reset");
         serviceNow.addNewItem('incident',{"short_description": session.message.text},function (err, delivery) {
        if (!err) {
            session.send('{"msg":"Meanwhile I am raising a ticket for your concern.","category":"Resolve Now","type":"message","id":"'+delivery+'"}');
             session.send('{"msg":"Please share your email id","category":"Resolve Now","type":"message"}');
            
            //session.end();
        } else {
            //console.log("error!",err);
            session.send({ status: false, data: 'Unable to raise the incident' });
            //session.end();
        }

    });
     
       
})



.matches('System Issue', function (session, args) {
    //changes for only RA
    session.send('{"msg":"Here is some information I can help you with to resolve your issue.","category":"Resolve Now","type":"message"}');
    //console.log("Password Reset");
    botIntraction.getRightAnswer(session.message.text,function(st,data){
        if(st){
            //console.log("In RA-->>", data);
            //session.send({status:false,data:data});
            //session.send('{"msg":data.title,"type":"Card","url":"#","summary":data.summary}');
        }
        else{
            
            //console.log("In RA else-->>", data);
            //console.log(typeof data);
            //session.send({status:true,data:data});
            
             for(var i=0;i<data.solutions.length;i++){
            
            session.send('{"msg":"'+ data.solutions[i].title +'","category":"Resolve Now","type":"RACard","url":"#","summary":"'+data.solutions[i].title+'","doc_id":"'+data.solutions[i].id+'" }');
             }
             
             //session.send('{"msg":"Please click on an option?","category":"Resolve Now","type":"radioOption","Options": [{"Option":"My computer starts slowly"}, {"Option":"My computer is very slow when browsing over the internet"}]}');
             
             
        }
        //session.end();
    });
    
    
    
    
    
    //session.send('{"msg":"What issues are you facing with your system?","category":"Resolve Now","type":"message"}');
    //session.send('{"msg":"Please click on an option?","category":"Resolve Now","type":"radioOption","Options": [{"Option":"My computer starts slowly"}, {"Option":"My computer is very slow when browsing over the internet"}]}');
    
    
    serviceNow.addNewItem('incident',{"short_description": session.message.text},function (err, delivery) {
        if (!err) {
            session.send('{"msg":"Meanwhile I am raising a ticket for your concern.","category":"Resolve Now","type":"message","id":"'+delivery+'"}');
            session.send('{"msg":"Was I able to help?","category":"Resolve Now","type":"boolean","Options": {"Option 1":"Yes", "Option 2":"No"}}');
            //session.end();
        } else {
            //console.log("error!",err);
            session.send({ status: false, data: 'Unable to raise the incident' });
            //session.end();
        }

    });
    

})
    .matches('My Calendar', function (session, args) {
    session.send('{"msg":"Feature not available! Will update you soon","category":"My Calendar","type":"calendar"}');

})
 .matches('AneyTest', function (session, args) {
    session.send('{"msg":"Aney Test is workin","category":"My Calendar","type":"message"}');

})


 .matches('IpAddress', function (session, args) {
    session.send('{"msg":"Sure. Will help you with that","category":"Resolve Now","type":"message"}');
    session.send('{"msg":"What is the Operating system of your PC","category":"Resolve Now","type":"message"}');
})
 .matches('OperatingSystem', function (session, args) {
     session.send('{"msg":"Please follow the following steps to know the IP Address of your system:","category":"Resolve Now","type":"Steps","Options": [{"Option":"Click the Start  button, and in the search box type cmd and press enter"}, {"Option":"Command prompt window will open."}, {"Option":"Type ipconfig in the command prompt and then press enter"}]}');
     session.send('{"msg":"A sample for the same is shown below","category":"My Calendar","type":"windowsSample"}');
})
.matches('MacOS', function (session, args) {
     session.send('{"msg":"Please follow the following steps to know the IP Address of your system:","category":"Resolve Now","type":"Steps","Options": [{"Option":"Click on the Apple icon on the upper-left corner of the screen."}, {"Option":"Scroll down and select System Preferences."}, {"Option":"Click Network. This should be on the third row."},{"Option":"Select your connection. Typically you will be connected to the network via AirPort (wireless), or Ethernet (wired). The connection you are using will say Connected next to it. Your IP address will be listed directly beneath your connection status, in smaller print.Your active connection will typically be selected by default."}]}');
    session.send('{"msg":"A sample screen for the same is shown below","category":"My Calendar","type":"macSample"}');
})
.matches('LotOfInfo', function (session, args) {
    session.send('{"msg":"Please look for the line IPv4 Address... The number across from that text is your local IP address","category":"My Calendar","type":"message"}');
    session.send('{"msg":"A sample is shown below","category":"My Calendar","type":"ipaddress"}');

})
 .matches('ipadDamaged', function (session, args) {
    session.send('{"msg":"Can you please share your contact number","category":"My Calendar","type":"message"}');

})
.matches('ContactAgent', function (session, args) {
    session.send('{"msg":"What is your favorite color","category":"My Calendar","type":"message"}');

})

.matches('FavoriteColor', function (session, args) {
    session.send('{"msg":"Phone number of X is 1212121212","category":"My Calendar","type":"message"}');

})

 .matches('BackupData', function (session, args) {
    session.send('{"msg":"No, the iPad/Repair team will NOT backup any data on the iPad. Request you to backup all the data on the iPad using iTunes prior to shipping in the iPad ","category":"My Calendar","type":"message"}');

})
 .matches('LoanerIpad', function (session, args) {
    session.send('{"msg":"Damaged iPads are replaced and you will receive a different iPad once you ship your device","category":"My Calendar","type":"message"}');
    session.send('{"msg":"Once you ship you damaged iPad, please forward the Fedex# and the ticket will be assigned to the sales team to provide you a replacement","category":"My Calendar","type":"message"}');

})
 .matches('PhoneNo', function (session, args) {
    session.send('{"msg":"Thank you for the information","category":"My Calendar","type":"message"}');
    session.send('{"msg":"You will need to Fedex your device to the following address with your contact name, phone number and your address","category":"My Calendar","type":"message"}');
    session.send('{"msg":"The shipping address for your iPad is","category":"My Calendar","type":"message"}');
    session.send('{"msg":"101 Park Ave, New York, NY 10178, USA","category":"My Calendar","type":"message"}');
})
.matches('EmailId', function (session, args) {
    session.send('{"msg":"Please respond to the following security questions before I reset your password","category":"Resolve Now","type":"message"}');
    session.send('{"msg":"What is your favorite movie?","category":"Resolve Now","type":"message"}');

})

.matches('Screenshot', function (session, args) {
    session.send('{"msg":"Please share the screenshot of your error message","category":"Resolve Now","type":"screenshot"}');
    

})


.matches('Movies', function (session, args) {
    session.send('{"msg":"I have send you a link on your registered e-mail id.The link will help you in resetting your password.","category":"Resolve Now","type":"message"}');
    session.send('{"msg":"Were you able to reset your password successfully?","category":"Resolve Now","type":"message"}');
    session.send('{"msg":"Were you able to reset your password successfully?","category":"Resolve Now","type":"radioOption","Options": [{"Option":"Yes, my password has been successfully reset"}, {"Option":"No, I am still unable to reset it"}]}');
    
    
})
.matches('PasswordSet', function (session, args) {
    if (session.message.text.match('Yes, my password has been successfully reset')) {
        session.send('{"msg":"I am glad I was able to help you with your issue. Have a great day.","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"I will be closing the ticket for the same.","category":"Resolve Now","type":"yesClose"}');
    }

    if (session.message.text.match('No, I am still unable to reset it')) {
         session.send('{"msg":"I hope following information will help you in resolving your password issue","category":"Resolve Now","type":"message"}');
   
    botIntraction.getRightAnswer(session.message.text,function(st,data){
        if(st){
            //console.log("In RA-->>", data);
            //session.send({status:false,data:data});
            //session.send('{"msg":data.title,"type":"Card","url":"#","summary":data.summary}');
        }
        else{
            
            //console.log("In RA else-->>", data);
            //console.log(typeof data);
            //session.send({status:true,data:data});
            
             for(var i=0;i<data.solutions.length;i++){
            
            session.send('{"msg":"'+ data.solutions[i].title +'","category":"Resolve Now","type":"RACard","url":"#","summary":"'+data.solutions[i].title+'","doc_id":"'+data.solutions[i].id+'" }');
             }
             session.send('{"msg":"Was I able to help?","category":"Resolve Now","type":"boolean","Options": {"Option 1":"Yes", "Option 2":"No"}}');
             //session.send('{"msg":"Please click on an option?","category":"Resolve Now","type":"radioOption","Options": [{"Option":"My computer starts slowly"}, {"Option":"My computer is very slow when browsing over the internet"}]}');
             
             
        }
        //session.end();
        
    });
       
    }})
  
.matches('ShellOpen', function (session, args) {
    session.send('{"msg":"I will be glad to take you to the Shell Website. But I will be waiting here to serve your request ","category":"My News","type":"shellopen"}');
}) 
    .matches('My News', function (session, args) {
    session.send('{"msg":"Have a look at the top stories ","category":"My News","type":"news"}');
}) .matches('ShellNews', function (session, args) {
    session.send('{"msg":"Have a look at the top stories ","category":"My News","type":"Shell news"}');
}) 
.matches('International news', function (session, args) {
    session.send('{"msg":"Have a look at the top international stories ","category":"My News","type":"International news"}');
}) 
.matches('ITNews', function (session, args) {
    session.send('{"msg":"Here is the latest IT news","category":"My News","type":"IT news"}');
}) 
    .matches('Other query', function (session, args) {
    session.send('{"msg":"Would you please specify your question?","category":"Resolve Now","type":"message"}');
}).matches('Workspace', function (session, args) {
    session.send('{"msg":"Okay John! Find all your work items here","category":"My workspace","type":"workspace"}');
})
.matches('MostUsedApps', function (session, args) {
    session.send('{"msg":"Find your most used applications here","category":"My workspace","type":"mostused"}');
})
.matches('TravelDate', function (session, args) {
    session.send('{"msg":"A ticket for your request has been raised","category":"Request Now","type":"message"}');
})
    .matches('UserInput1', function (session, args) {

    if (session.message.text.match('My computer starts slowly')) {

        session.send('{"msg":"If your computer is slow to start up, you may wish to have a look at these links for advice on ways to improve your computer performance.","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"Optimise system performance","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-gb/help/15055/windows-7-optimize-windows-better-performance#optimize-windows-better-performance=windows-7"}');
        session.send('{"msg":"Refresh the operating system","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-gb/help/17085/windows-8-restore-refresh-reset-pc"}');
        
        botIntraction.getRightAnswer(session.message.text,function(st,data){
        if(st){
            //console.log("In RA-->>", data);
            //session.send({status:false,data:data});
            //session.send('{"msg":data.title,"type":"Card","url":"#","summary":data.summary}');
        }
        else{
            
            //console.log("In RA else-->>", data);
            //console.log(typeof data);
            //session.send({status:true,data:data});
            for(var i=0;i<data.solutions.length;i++){
            session.send('{"msg":"'+ data.solutions[0].title +'","category":"Resolve Now","type":"RACard","url":"#","summary":"'+data.solutions[0].title+'","doc_id":"'+data.solutions[i].id+'" }');
            }
        }
        //session.end();
    });
        
        
        
        
    }
    if (session.message.text.match('My computer is very slow when browsing over the internet')) {

        session.send('{"msg":"If your computer is slow when browsing the Internet, you may wish to have a look at these links for advice","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"Delete temporary Internet Files","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-sg/help/260897/how-to-delete-the-contents-of-the-temporary-internet-files-folder"}');
        session.send('{"msg":"Internet connection is slow","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-us/help/15091/windows-7-why-internet-connection-so-slow"}');

    }
    setTimeout(function () {
        session.send('{"msg":"Was I able to help?","category":"Resolve Now","type":"boolean","Options": {"Option 1":"Yes", "Option 2":"No"}}');
    }, 5000);
}).matches('UserInput2', function (session, args) {
    if (session.message.text.match('[Y|y]es')) {
        session.send('{"msg":"I am glad I was able to help you with your issue. Have a great day!","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"I will be closing the ticket for the same.","category":"Resolve Now","type":"yesClose"}');
    }
    if (session.message.text.match('[N|n]o')) {
      
        session.send('{"msg":"It looks like my suggestions havent been helpful. I am trying to improve my knowledge.","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"We would like to ensure you received the support you expected and that your problem was solved or your questions answered.","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"Click to call","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-gb/help/15055/windows-7-optimize-windows-better-performance#optimize-windows-better-performance=windows-7"}');
        session.send('{"msg":"Click to chat","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-gb/help/15055/windows-7-optimize-windows-better-performance#optimize-windows-better-performance=windows-7"}');
        session.send('{"msg":"Schedule a callback","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-sg/help/260897/how-to-delete-the-contents-of-the-temporary-internet-files-folder"}');
        session.send('{"msg":"Update Ticket","category":"Resolve Now","type":"Card","url":"https://aneychatbot.azurewebsites.net/NewIncident.html"}');
      }
})

    .matches('Weather', function (session, args) {
    session.send('{"msg":"Have a look at the weather","category":"My News","type":"weather"}');
})
    .matches('conversationClosure', function (session, args) {
    session.send('{"msg":"It was nice talking to you.I am always happy to help.","category":"My News","type":"message"}');
})
  .matches('Reschedule', function (session, args) {
    // for reschedule show crrent week days
    session.userData.meetingAction='Reschedule';
    /*session.send('{"msg":"Please specify the day for which you want to reschedule meeting","category":"MyCalendar","type":"message"}');
    
    var today=new Date();
    var current_day=today.getDay();
     var mndy=new Date();
    mndy.setDate(today.getDate()-current_day+1);
      //session.send('{"msg":"Please choose","category":"My Calendar","type":"radioOption","Options": [{"Option":mndy}}');
     mndy=mndy.toString();
     mndy=mndy.substr(0,10);
     
     var tues=new Date();
    tues.setDate(today.getDate()-current_day+2);
    tues=tues.toString();
    tues=tues.substr(0,10);
    
    var wed=new Date();
    wed.setDate(today.getDate()-current_day+3);
     wed=wed.toString();
     
     wed=wed.substr(0,10);
     var thus=new Date();
     thus.setDate(today.getDate()-current_day+4);
     thus=thus.toString();
     
     thus=thus.substr(0,10);
     var fri=new Date();
     fri.setDate(today.getDate()-current_day+5);
     fri=fri.toString();
     
     fri=fri.substr(0,10);
     session.send('{"msg":"Please specify the day for which you want to reschedule meeting","category":"My Calendar", "type":"radioOption","Options": [{"Option":"'+mndy+'"}, {"Option":"'+tues+'"}, {"Option":"'+wed+'"}, {"Option":"'+thus+'"}, {"Option":"'+fri+'"}]}');*/
     session.send('{"msg":"I am still learning to handle the calendar.","category":"My Calendar","type":"message"}');
     session.send('{"msg":"I may help with this in near future but sorry for now.","category":"My Calendar","type":"message"}');
      //session.send('{"msg":"Please specify the day for which you want to reschedule meeting","category":"My Calendar", "type":"radioOption","Options": [{"Option":"mndy"}, {"Option":"tues"}, {"Option":wed}, {"Option":"thus"}, {"Option":"fri"}]}');
})
.matches('Cancel', function (session, args) {
    // for cancel show current week days
    session.userData.meetingAction='Cancel';
    session.send('{"msg":"Please specify the day for which you want to cancel meeting","category":"My Calendar","type":"message"}');
     var today=new Date();
    var current_day=today.getDay();
     var mndy=new Date();
    mndy.setDate(today.getDate()-current_day+1);
      //session.send('{"msg":"Please choose","category":"My Calendar","type":"radioOption","Options": [{"Option":mndy}}');
     mndy=mndy.toString();
     mndy=mndy.substr(0,10);
     
     var tues=new Date();
    tues.setDate(today.getDate()-current_day+2);
    tues=tues.toString();
    tues=tues.substr(0,10);
    
    var wed=new Date();
    wed.setDate(today.getDate()-current_day+3);
     wed=wed.toString();
     
     wed=wed.substr(0,10);
     var thus=new Date();
     thus.setDate(today.getDate()-current_day+4);
     thus=thus.toString();
     
     thus=thus.substr(0,10);
     var fri=new Date();
     fri.setDate(today.getDate()-current_day+5);
     fri=fri.toString();
     
     fri=fri.substr(0,10);
     session.send('{"msg":"Please specify the day for which you want to cancel meeting","category":"My Calendar", "type":"radioOption","Options": [{"Option":"'+mndy+'"}, {"Option":"'+tues+'"}, {"Option":"'+wed+'"}, {"Option":"'+thus+'"}, {"Option":"'+fri+'"}]}');
    
    
    
    
   // session.send('{"msg":"Please specify the day for which you want to cancel meeting","category":"MyCalendar","type":"message"}');
   // session.send('{"msg":"Please specify the day for which you want to reschedule meeting","category":"My Calendar", "type":"radioOption","Options": [{"Option":"Mon(27 Mar)"}, {"Option":"Tue(28 Mar)"}, {"Option":"Wed(29 Mar)"}, {"Option":"Thu(30 Mar)"}, {"Option":"Fri(31 Mar)"}]}');
    //session.send('{"msg":"Please specify the day for which you want to cancel meeting","category":"My Calendar", "type":"radioOption","Options": [{"Option":"Mon(27 Mar)","keyVal":"1"}, {"Option":"Tue(28 Mar)","keyVal":"2"}, {"Option":"Wed(29 Mar)","keyVal":"3"}, {"Option":"Thu(30 Mar)","keyVal":"4"}, {"Option":"Fri(31 Mar)","keyVal":"5"}]}');
})
.matches('Report Now', function (session, args) {
    session.send('{"msg":"Have a look at your service now reports","category":"Report Now","type":"report"}');
})


.matches('Printer issue',(session, args) => {

    session.send('{"msg":"Can you please specify what kind of issue do you have while printing?","category":"Resolve Now","type":"message"}');
    session.send('{"msg":"Please click on an option ","category":"Resolve Now","type":"message"}');
    session.send('{"msg":"Please click on an option","category":"Resolve Now","type":"radioOption","Options": [{"Option":"I need help installing a printer"}, {"Option":"My printer does not print at all"}, {"Option":"My printer has a paper jam"}, {"Option":"My printer need toner replacement"}]}');


serviceNow.addNewItem('incident',{"short_description": session.message.text},function (err, delivery) {
        if (!err) {
            session.send('{"msg":"Meanwhile I am raising a ticket for your concern.","category":"Resolve Now","type":"message","id":"'+delivery+'"}');
            session.send('{"msg":"Was I able to help?","category":"Resolve Now","type":"boolean","Options": {"Option 1":"Yes", "Option 2":"No"}}');
            //session.end();
        } else {
            //console.log("error!",err);
            session.send({ status: false, data: 'Unable to raise the incident' });
            //session.end();
        }

    });



})
.matches('RequestNow', function (session, args) {
    //console.log("In request now.............");
    //var requestEntity = builder.EntityRecognizer.findEntity(args.intent.entities, 'typeofrequest');
    //console.log(requestEntity);
    session.send('{"msg":"Which service request do you want to raise?","category":"Request Now","type":"request"}');
})

    .matches('UserInput3',(session, args) => {

    if (session.message.text.match('I need help installing a printer')) {

        session.send('{"msg":"Please follow the following steps to install a printer:","category":"Resolve Now","type":"Steps","Options": [{"Option":"Click the Start  button, and then, on the Start menu, click Devices and Printers."}, {"Option":"Click Add a printer."}, {"Option":"In the Add Printer wizard, click Add a network, wireless or Bluetooth printer."}, {"Option":"In the list of available printers, select the one you want to use, and then click Next. (If your computer is connected to a network, only printers listed in Active Directory for your domain are displayed in the list.)"}, {"Option":"If prompted, install the printer driver on your computer by clicking Install driver. Administrator permission required If you are prompted for an administrator password or confirmation, type the password or provide confirmation."}, {"Option":"Click the Start  button, and then, on the Start menu, click Devices and Printers."}, {"Option":"Complete the additional steps in the wizard, and then click Finish."}]}');

        setTimeout(function () {
            session.send('{"msg":"Are you able to print with the newly installed printer? ","category":"Resolve Now","type":"message"}');
            session.send('{"msg":"Are you able to print with the newly installed printer?","category":"Resolve Now","type":"radioOption","Options": [{"Option":"Yes I am able to print"}, {"Option":"No I am not able to print"}]}');
        }, 5000);
    }

    if (session.message.text.match('My printer does not print at all')) {
        session.send('{"msg":"Please check if you are connected to the network. You can do so by accessing the intranet page and see if you are able to access it","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"Please check if the printer is not offline. You can do so by clicking on start and then click Devices and Printers. Double click on the printer icon and see if it says printer: offline. You can turn the offline mode off by clicking display printer queue and then click Printer on the menu and uncheck use printer offline.","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"Please check if you are connected to the network. You can do so by accessing the intranet page and see if you are able to access it","category":"Resolve Now","type":"message"}');
    }
    if (session.message.text.match('My printer has a paper jam')) {
        session.send('{"msg":"Ok, got it! Unfortunately there is nothing much I could assist you with however I can connect you to someone who could assist you.Let me help you with the available options","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"We would like to ensure you received the support you expected and that your problem was solved or your questions answered.","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"Click to call","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-gb/help/15055/windows-7-optimize-windows-better-performance#optimize-windows-better-performance=windows-7"}');
        session.send('{"msg":"Click to chat","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-gb/help/15055/windows-7-optimize-windows-better-performance#optimize-windows-better-performance=windows-7"}');
        session.send('{"msg":"Schedule a callback","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-sg/help/260897/how-to-delete-the-contents-of-the-temporary-internet-files-folder"}');
        session.send('{"msg":"Update Ticket","category":"Resolve Now","type":"Card","url":"https://murex.in/NewIncident.html"}');

    }

    if (session.message.text.match('My printer need toner replacement')) {
        session.send('{"msg":"Ok, got it! Unfortunately there is nothing much I could assist you with however I can connect you to someone who could assist you.Let me help you with the available options","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"We would like to ensure you received the support you expected and that your problem was solved or your questions answered.","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"Click to call","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-gb/help/15055/windows-7-optimize-windows-better-performance#optimize-windows-better-performance=windows-7"}');
        session.send('{"msg":"Click to chat","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-gb/help/15055/windows-7-optimize-windows-better-performance#optimize-windows-better-performance=windows-7"}');
        session.send('{"msg":"Schedule a callback","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-sg/help/260897/how-to-delete-the-contents-of-the-temporary-internet-files-folder"}');
        session.send('{"msg":"Update Ticket","category":"Resolve Now","type":"Card","url":"https://murex.in/NewIncident.html"}');
    }
}).matches('AbleToPrint', function (session, args) {
    if (session.message.text.match('Yes I am able to print')) {
        session.send('{"msg":"I am glad I was able to help you with your issue. Have a great day.","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"I will be closing the ticket for the same.","category":"Resolve Now","type":"yesClose"}');
    }

    if (session.message.text.match('No I am not able to print')) {
        session.send('{"msg":"It looks like my suggestions havent been helpful. I am trying to improve my knowledge.","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"We would like to ensure you received the support you expected and that your problem was solved or your questions answered.","category":"Resolve Now","type":"message"}');
        session.send('{"msg":"Click to call","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-gb/help/15055/windows-7-optimize-windows-better-performance#optimize-windows-better-performance=windows-7"}');
        session.send('{"msg":"Click to chat","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-gb/help/15055/windows-7-optimize-windows-better-performance#optimize-windows-better-performance=windows-7"}');
        session.send('{"msg":"Schedule a callback","category":"Resolve Now","type":"Card","url":"https://support.microsoft.com/en-sg/help/260897/how-to-delete-the-contents-of-the-temporary-internet-files-folder"}');
        session.send('{"msg":"Update Ticket","category":"Resolve Now","type":"Card","url":"https://murex.in/NewIncident.html"}');
    }
})

.matches('DefaultHandle', function (session, args) {
     //console.log("In default handle now.............");
  defaultAction(session);
})

.matches('ultimatix', function (session, args) {
  session.send('{"msg":"Opening the application you asked for. I will be here to serve your requests.","category":"Request Now","type":"application","app":"https://www.ultimatix.net"}');
})

// .matches('Reschedule', function (session, args) {
//   session.send('{"msg":"Please specify the day for which you want to reshcedule meeting","category":"My Calendar","type":"radioOption","Options": [{"Option":"27 March"}, {"Option":"28 March"}, {"Option":"29 March"},{"Option":"30 March"} {"Option":"31 March"}]}');
    
// })

.matches('UpdateTicket', function (session, args) {
  session.send('{"msg":"Updating your ticket","category":"Request Now","type":"updateTicket"}');
})
.matches('tcs', function (session, args) {
  session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"Request Now","type":"application","app":"https://www.tcs.com/"}');
})
.matches('google', function (session, args) {
  session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request.","category":"Request Now","type":"application","app":"https://www.google.co.in/"}');
})
.matches('fresco', function (session, args) {
  session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"Request Now","type":"application","app":"fresco.me/"}');
})
.matches('Sap', function (session, args) {
  session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"Request Now","type":"application","app":"https://www.sap.com/index.html/"}');
})
.matches('Primavera', function (session, args) {
  session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"Request Now","type":"application","app":"https://www.oracle.com/applications/primavera/index.html/"}');
})
.matches('Exploration', function (session, args) {
  session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"Request Now","type":"application","app":"https://www.oracle.com/applications/primavera/index.html/"}');
})
.matches('Smartplant', function (session, args) {
  session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"Request Now","type":"application","app":"http://www.intergraph.com/products/ppm/smartplant/foundation/web_portal/default.aspx/"}');
})
.matches('ServiceNow', function (session, args) {
  session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"Request Now","type":"application","app":"https://dev20815.service-now.com/nav_to.do?uri=%2Fhome.do%3F/"}');
})
.matches('Outlook', function (session, args) {
  session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"Request Now","type":"application","app":"http://outlook.live.com//"}');
})
.matches('SystemInfoRequest', function (session, args) {
  session.send('{"msg":"Raising system request","category":"Request Now","type":"systeminfo"}');
})
.matches('MapDriveRequest', function (session, args) {
  session.send('{"msg":"Raising Map Network Drive request","category":"Request Now","type":"mapdrive"}');
})
.matches('HardwareRequest', function (session, args) {
  session.send('{"msg":"Please provide me the requirements","category":"Request Now","type":"hardwarereq"}');
})

.matches('orderLaptop', function (session, args) {
  session.send('{"msg":"Please provide me the requirements","category":"Request Now","type":"hardwarereq"}');
})

.matches('SkypeQuestion', function (session, args) {
  session.send('{"msg":"The ticket id for your last call about Skype is","category":"Request Now","type":"skypeques"}');
})



.matches('SoftwareRequest', function (session, args) {
    session.send('{"msg":"Following steps will help you in ordering the software of your choice:","category":"Resolve Now","type":"Steps","Options": [{"Option":"Visit the following link ***bisoftware.com***"}, {"Option":"Enter the name or category of the desired software in the search box and click the search icon"}, {"Option":"Select the software you want to purchase from the list of softwares and add it to your cart"},{"Option":"Click on the checkout button, enter you details and make payment"},{"Option":"You will receive the order confirmation status in your e-mail address"}]}');
  session.send('{"msg":"Some of the top selling softwares are displayed below","category":"Request Now","type":"softwarereq"}');
})
.matches('MSOffice', function (session, args) {
  var entity = builder.EntityRecognizer.findEntity(args.entities, 'softwaretype'); 
  //console.log('Entity',entity);
  session.send('{"msg":"The requirement has been recorded. Your software will be installed shortly.","category":"Request Now","type":"softwareinstall","software":"'+ entity.entity +'"}');
})
.matches('AdminRequest', function (session, args) {
  
  session.send('{"msg":"Admin Request","category":"Request Now","type":"adminreq"}');
})
.matches('AdminRequestType', function (session, args) {
  var entity = builder.EntityRecognizer.findEntity(args.entities, 'admintype'); 
  //console.log('Entity',entity);
  session.send('{"msg":"The requirement has been recorded.","category":"Request Now","type":"admintype","admin":"'+ entity.entity +'"}');
})
.matches('AccessRequest', function (session, args) {
  var entityType;
  var entity = builder.EntityRecognizer.findEntity(args.entities, 'accesstype'); 
  if(!entity){
      entityType = 'default';
  }else{
      entityType = entity.entity;
  }
  session.send('{"msg":"Access Request","category":"Request Now","type":"accessreq","accesstype":"'+ entityType +'"}');
})

.matches('FetchTicket', function (session, args) {
    
     var entity1 = builder.EntityRecognizer.findEntity(args.entities, 'task'); 
     //var entity2 = builder.EntityRecognizer.findEntity(args.entities, 'builtin.encyclopedia.architecture.structure'); 
     //console.log("1",entity1);
     //console.log("2",entity2);
     if(entity1){
     session.send('{"msg":"Fetching your ticket....","category":"Request Now","type":"incidentticket","ticket":"'+ entity1.entity +'"}');
    //  }else if(!entity2){
    //  session.send('{"msg":"Fetching you ticket....","category":"Request Now","type":"taskticket","ticket":'+ entity1.entity +'"}');    
     }
    //  else{
    //       session.send('{"msg":"Please enter your ticket ID","category":"Request Now","type":"ticket"}');
    //   }
     
  //session.send('{"msg":"Please tell me the date for your travel","category":"Request Now","type":"travel"}');
})

.matches('Travel', function (session, args) {
    
     var entity = builder.EntityRecognizer.findEntity(args.entities, 'builtin.geography.city'); 
     //console.log('ENtity',entity);
    
  session.send('{"msg":"Please tell me the date for your travel","category":"Request Now","type":"travel","city":"'+ entity.entity +'"}');
})

.matches('statictics', function (session, args) {
    session.send('{"msg":"These are the available reports about incident.","category":"Report Now","type":"statistics"}');
})
.matches('Office365Apps', function (session, args) {
    session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"My workspace","type":"office"}');
})
.matches('callabacktimeIntent', function (session, args) {
     var entity = builder.EntityRecognizer.findEntity(args.entities, 'builtin.datetime.time'); 
    session.send('{"msg":"Okay! You will recive a call back from us at","category":"Resolve Now","type":"callback","time":"'+ entity.entity +'"}');
})
.matches('Skype', function (session, args) {
     //var entity = builder.EntityRecognizer.findEntity(args.entities, 'builtin.datetime.time'); 
    session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"My workspace","type":"skype"}');
})

.matches('excel_office', function (session, args) {
     //var entity = builder.EntityRecognizer.findEntity(args.entities, 'builtin.datetime.time'); 
    session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"My workspace","type":"excel_office"}');
})
.matches('word_office', function (session, args) {
     //var entity = builder.EntityRecognizer.findEntity(args.entities, 'builtin.datetime.time'); 
    session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"My workspace","type":"word_office"}');
})
.matches('powerpoint_office', function (session, args) {
     //var entity = builder.EntityRecognizer.findEntity(args.entities, 'builtin.datetime.time'); 
    session.send('{"msg":"Taking you to your application, I will be waiting here to serve your request","category":"My workspace","type":"powerpoint_office"}');
})
// TODO
// .matches('Software Request', function (session, args) {
//     session.send('{"msg":"Following are the list of Softwares to meet your business needs","type":"radioOption","Options": [{"Option":"MS Office Professional Plus 2016"}, {"Option":"Adobe Acrobat DC Standard"}, {"Option":"Microsoft Office Project Standard"},{"Option":"Microsoft Visio Standard"}, {"Option":"Quick_View_Plus_13"}]}');
// })


    .onDefault(function (session,args) {
         //console.log("In default .............");
        defaultAction(session);
});

bot.dialog('/', intents);

function defaultAction(session) {
    
    session.send('{"msg":"I did not understand what you said. I can help you with the following options","category":"My News","type":"message"}');
    session.send('{"msg":"I did not understand what you said. I can help you with the following options","category":"My News","type":"radioOption","Options": [{"Option":"System Issues"}, {"Option":"Printer Issues"}, {"Option":"Reset My Password"}, {"Option":"Show me Incident Status"}]}');
    
}


function rightAnswerCall(res,queryString){
    
    //console.log("In right call-->");
    session.send('{"msg":"I have reached!!!!","type":"message"}');
    botIntraction.getRightAnswer(queryString,function(err,result){
		if(!err){
			res.send({"status":true,data:result});
			res.end();
		}else{
			res.send({"status":true,data:"Unable to get the report."});
			res.end();
		}
	});
    
    
}
