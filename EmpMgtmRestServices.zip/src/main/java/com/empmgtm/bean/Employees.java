package com.empmgtm.bean;


public class Employees {


	private String empId;  
	private String fName;  
	private String lName;  
	private String address;
	private String emailAddress;
	private String phoneNumber;
	private String password;
	private String city;
	private String state;
	private String country;
	private String empRole;  
	private String department;  
	private String empStatus;
	
	
	public Employees(){
	}
	
	public Employees(String empId, String fName, String lName, String emailAddress, String phoneNumber, String empRole, String department) {
		super();
		this.empId = empId;
		this.fName = fName;
		this.lName = lName;
		this.emailAddress = emailAddress;
		this.phoneNumber = phoneNumber;
		this.empRole=empRole;
		this.department=department;
	}
	
	
	public String getEmpId() {
		return empId;
	}


	public void setEmpId(String empId) {
		this.empId = empId;
	}


	public String getfName() {
		return fName;
	}


	public void setfName(String fName) {
		this.fName = fName;
	}


	public String getlName() {
		return lName;
	}


	public void setlName(String lName) {
		this.lName = lName;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getEmailAddress() {
		return emailAddress;
	}


	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getEmpRole() {
		return empRole;
	}


	public void setEmpRole(String empRole) {
		this.empRole = empRole;
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}


	public String getEmpStatus() {
		return empStatus;
	}


	public void setEmpStatus(String empStatus) {
		this.empStatus = empStatus;
	}


	

	

}
