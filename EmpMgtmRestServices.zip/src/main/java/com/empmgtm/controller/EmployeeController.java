package com.empmgtm.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.empmgtm.bean.Employees;
import com.empmgtm.service.EmployeeService;

@RestController
public class EmployeeController {

	
@Autowired
EmployeeService employeesService;  

	

@RequestMapping(value = "/emp/{empId}", method = RequestMethod.GET,headers="Accept=application/json")
public Employees findEployee(@PathVariable String empId)throws Exception  {  
 return employeesService.findEmployee(empId);  
 }  



@RequestMapping(value = "/empList", method = RequestMethod.GET,headers="Accept=application/json")
public Map<Integer, Employees> getEmployeeList()throws Exception  {  
 return employeesService.getEmployeeList();  
 }  

}
