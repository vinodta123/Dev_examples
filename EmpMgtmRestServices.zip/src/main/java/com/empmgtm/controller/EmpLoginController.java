package com.empmgtm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.empmgtm.bean.EmpLoginResponse;
import com.empmgtm.service.EmpLoginService;

@RestController
public class EmpLoginController {

	
@Autowired
EmpLoginService empLoginService;  

	

@RequestMapping(value = "/empLogin/{empId}/{empPassword}", method = RequestMethod.GET,headers="Accept=application/json")
public EmpLoginResponse	 getEmpLogin(@PathVariable String empId, @PathVariable String empPassword)throws Exception  {  
	return empLoginService.getEmpLogin(empId,empPassword);  
 }  



}
