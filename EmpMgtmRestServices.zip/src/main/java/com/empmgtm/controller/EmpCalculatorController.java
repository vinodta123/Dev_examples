package com.empmgtm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.empmgtm.bean.EmpLoginResponse;
import com.empmgtm.service.EmpLoginService;

@RestController
public class EmpCalculatorController {

		
/**
 * 
 * @param value1
 * @param value2
 * @return
 * @throws Exception
 */
@RequestMapping(value = "/getAdd/{value1}/{value2}", method = RequestMethod.GET,headers="Accept=application/json")
public int	getAdd(@PathVariable int value1, @PathVariable int value2)throws Exception  {  

	return value1 + value2;
 } 

/**
 * 
 * @param value1
 * @param value2
 * @return
 * @throws Exception
 */
@RequestMapping(value = "/getSubtract/{value1}/{value2}", method = RequestMethod.GET,headers="Accept=application/json")
public int	getSubtract(@PathVariable int value1, @PathVariable int value2)throws Exception  {  

	return value1 - value2;
 }  

/**
 * 
 * @param value1
 * @param value2
 * @return
 * @throws Exception
 */
@RequestMapping(value = "/getMultiply/{value1}/{value2}", method = RequestMethod.GET,headers="Accept=application/json")
public int	getMultiply(@PathVariable int value1, @PathVariable int value2)throws Exception  {  

	return value1 * value2;
 }  

/***
 * 
 * @param value1
 * @param value2
 * @return
 * @throws Exception
 */
@RequestMapping(value = "/getDivide/{value1}/{value2}", method = RequestMethod.GET,headers="Accept=application/json")
public int	getDivide(@PathVariable int value1, @PathVariable int value2)throws Exception  {  

	return value1 /value2;
 }  



}
