package com.empmgtm.service;

import com.empmgtm.bean.EmpLoginResponse;

public interface EmpLoginService {

	public EmpLoginResponse getEmpLogin(String empId, String empPassword);

	
}
