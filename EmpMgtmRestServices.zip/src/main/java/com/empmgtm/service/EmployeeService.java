package com.empmgtm.service;

import java.util.Map;

import com.empmgtm.bean.Employees;

public interface EmployeeService {

	public Employees findEmployee(String empId);
	public Map<Integer, Employees> getEmployeeList();
	
}
