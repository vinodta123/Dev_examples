package com.empmgtm.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.empmgtm.bean.EmpLoginResponse;

@Service("EmpLoginService")
public class EmpLoginServiceImpl implements EmpLoginService{

	static Map<Integer, EmpLoginResponse> empLoginResponse = new HashMap<Integer, EmpLoginResponse>(); 
	
	public EmpLoginServiceImpl() {
		
		empLoginResponse.put(0, new EmpLoginResponse("1001", "admin","vinod","Sharma","vinod@yahoo.com","76543212345")); 
		empLoginResponse.put(1, new EmpLoginResponse("1002", "vinod","vinod","Sharma","vinod@gmail.com","9675676657345")); 
		empLoginResponse.put(2, new EmpLoginResponse("1003", "vipin", "vipin","gupta","vipin@yahoo.com","76543212345"));  
		empLoginResponse.put(3, new EmpLoginResponse("1004", "raja", "Raja","sharma","vinod@yahoo.com","78678686868"));  
		empLoginResponse.put(4, new EmpLoginResponse("1005", "admin", "kamla","singh","kamal@yahoo.com","7475376345347"));  
		empLoginResponse.put(5, new EmpLoginResponse("1006", "deepa", "Deepa","Sharma","Deepa@yahoo.com","9877637747"));  
		empLoginResponse.put(6, new EmpLoginResponse("1007", "carlos", "Carlos","phin","Carlos@yahoo.com","65632626633"));  
		empLoginResponse.put(7, new EmpLoginResponse("1008", "mithali", "Mithali","gupta","vinod@yahoo.com","436463663623"));  
		empLoginResponse.put(8, new EmpLoginResponse("1009", "sanjeev", "Sanjeev","mittal","mittal@yahoo.com","97888768"));  
		empLoginResponse.put(9, new EmpLoginResponse("1010", "ashish", "Ashish","Magla","Ashish@yahoo.com","76543212345"));  
		empLoginResponse.put(10, new EmpLoginResponse("1011", "ajay", "Ajay","Sharma","Ajay@yahoo.com","87543212345"));   
			
	}

	/**
	 * 
	 * @param employeeId
	 * @return
	 */
	public EmpLoginResponse getEmpLogin(String empId, String empPassword){  
		EmpLoginResponse employeeobj=null;
		for (int i = 0; i <empLoginResponse.size(); i++) {
			if(empLoginResponse.get(i).getEmpId().equalsIgnoreCase(empId) && empLoginResponse.get(i).getPassword().equalsIgnoreCase(empPassword)){
				employeeobj =empLoginResponse.get(i);
				break;
			}
		}
		if(employeeobj==null){
			employeeobj=new EmpLoginResponse();
			employeeobj.setStatus("Failure");
			employeeobj.setErrorMessage("Employee Id and password doesnot match!.");
			employeeobj.setErrorCode("401");
		}else{
			employeeobj.setStatus("Sucessful");
			employeeobj.setErrorMessage("Ok");
			employeeobj.setErrorCode("200");
		}
		
//		System.out.println("EmpLoginServiceImpl-- employeeobj.getStatus()-->"+employeeobj.getStatus());
		 return employeeobj;  

	}  
	
}
	
