package com.empmgtm.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.empmgtm.bean.EmpLoginResponse;
import com.empmgtm.bean.Employees;

@Service("EmployeeService")
public class EmployeeServiceImpl implements EmployeeService{

	 Map<Integer, Employees> employeeList = new HashMap<Integer, Employees>(); 
	
	public EmployeeServiceImpl() {
		
		
		employeeList.put(0, new Employees("1001", "vinod","Sharma","vinod@yahoo.com","76543212345","Architect","IT")); 
		employeeList.put(1, new Employees("1002",  "vinod","Sharma","vinod@gmail.com","9675676657345","Architect","IT")); 
		employeeList.put(2, new Employees("1003",  "vipin","gupta","vipin@yahoo.com","76543212345","Manager","IT"));  
		employeeList.put(3, new Employees("1004",  "Raja","sharma","vinod@yahoo.com","78678686868","Analyst","Finance"));  
		employeeList.put(4, new Employees("1005",  "kamla","singh","kamal@yahoo.com","7475376345347","Architect","IT"));  
		employeeList.put(5, new Employees("1006",  "Deepa","Sharma","Deepa@yahoo.com","9877637747","Analyst","IT"));  
		employeeList.put(6, new Employees("1007",  "Carlos","phin","Carlos@yahoo.com","65632626633","Architect","Finance"));  
		employeeList.put(7, new Employees("1008",  "Mithali","gupta","vinod@yahoo.com","436463663623","Analyst","Finance"));  
		employeeList.put(8, new Employees("1009",  "Sanjeev","mittal","mittal@yahoo.com","97888768","Manager","IT"));  
		employeeList.put(9, new Employees("1010",  "Ashish","Magla","Ashish@yahoo.com","76543212345","Manager","IT"));  
		employeeList.put(10, new Employees("1011", "Ajay","Sharma","Ajay@yahoo.com","87543212345","Develper","IT"));  
		
	}

	/**
	 * 
	 * @param employeeId
	 * @return
	 */
	public Employees findEmployee(String employeeId) {  
		Employees employeeobj=null;
	
		for (int i = 0; i < employeeList.size(); i++) {
			if(employeeList.get(i).getEmpId().equalsIgnoreCase(employeeId)){
				employeeobj=(Employees)employeeList.get(i);
				break;
			}
		}
		if(employeeobj==null){
			employeeobj = new Employees();
			employeeobj.setEmpStatus("not Found");
		}
		 return employeeobj;

	}  

	
	
/**
 * 
 */
	public Map<Integer, Employees> getEmployeeList(){	
		return employeeList;
	}
}
