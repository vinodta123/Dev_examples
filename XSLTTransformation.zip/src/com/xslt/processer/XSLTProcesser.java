package com.xslt.processer;

import java.io.FileOutputStream;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;


public class XSLTProcesser{

	public XSLTProcesser() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			
			
			// BOOKING Seat
				//XSLTProcesser.processTransformation("src/resources/","seatPurchase.xsl","Purchased Seats_Final.xml", "SeatPurchase.html");
						
			// BOOKING CONFIRMATION
			XSLTProcesser.processTransformation("src/resources/","bookingConf_split_playment.xsl","Split_payment_GW8EGE.xml","bookingConf.html");
			
			//refund-request CONFRIMATION
			//XSLTProcesser.processTransformation("src/resources/","refund-request.xsl","Send_RefendRequest_REFREQ.xml", "refund-request.html");	
			
			// refund-acknowledgement
			//XSLTProcesser.processTransformation("src/resources/","refund-acknowledgement.xsl","Send_RefendRecepit_REFACK.xml", "refund-acknowledgement.html");
	
			// BOOKING UPGRADE
			//XSLTProcesser.processTransformation("src/resources/","BookingUpgrade.xsl","BookConf.xml", "BookingUpgrade.html");
	
			// BOOKING BookingAmendment
			//XSLTProcesser.processTransformation("src/resources/","BookingAmendment.xsl","BookConf.xml", "BookingAmendment.html");
	
				// BOOKING cancellation
				//XSLTProcesser.processTransformation("src/resources/","BKGCNX_email.xslt","bookingCancellation.xml", "bookingCancellation.html");
		
			//OCI
			//XSLTProcesser.processTransformation("src/resources/","OCI.xsl","OLCI_Final.xml", "OCI_output.html");	
			
				
		}catch(TransformerException ex){
			ex.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param path
	 * @param xsl
	 * @param xml
	 * @param htmlresult
	 * @throws TransformerException
	 */
	public static  void processTransformation(String path, String xsl,String xml, String htmlresult) throws TransformerException {
		try {
			TransformerFactory tFactory = TransformerFactory.newInstance();

			Transformer transformer = tFactory.newTransformer(new StreamSource(path+xsl));

			transformer.transform(new StreamSource(path+xml),
					new StreamResult(new FileOutputStream(path+htmlresult)));
			System.out.println("transform dane--->");
		} catch (Exception tce) {
			tce.printStackTrace();
		}
	}
	

}
