package com.test.users.webservices;

import org.springframework.oxm.Marshaller;
import org.springframework.ws.server.endpoint.AbstractMarshallingPayloadEndpoint;

import com.test.users.beans.UserResponse;
import com.test.users.handler.GetUsersListResponseHandler;
/**
 * End Point class which is invoked when there is a Get GetUser List Endpoint Request.
 * 
 * @author vinod
 *
 */
public class GetUsersListEndpoint  extends AbstractMarshallingPayloadEndpoint  {
	
	private GetUsersListResponseHandler getUsersListResponseHandler;
	private final org.apache.commons.logging.Log logger = org.apache.commons.logging.LogFactory
			.getLog(getClass());

	
	/**
	 * Constructor which sets the marshaler and 
	 * GetScheduleAvailabilityResponseHandler instances
	 * @param marshaller
	 * @param getScheduleAvailabilityResponseHandler
	 */
    public GetUsersListEndpoint(Marshaller marshaller, 
    		GetUsersListResponseHandler getUsersListResponseHandler) {
        super(marshaller);
		this.getUsersListResponseHandler = getUsersListResponseHandler;
    }
    
	
    /**
     * Overridden method which implements logic for GetScheduleAvailability
     */
	protected Object invokeInternal(Object request) throws Exception {
		UserResponse object=null;
		// delegates call to handler
		try {
		 object = getUsersListResponseHandler.getUsersListResponse(request);
		/*String an=null;
		an.charAt(3);*/
		} catch (Exception e) {
			object = new UserResponse();
			System.out.println(""+e.getStackTrace());
			logger.error(e);
		}
		return object;
	}

}
