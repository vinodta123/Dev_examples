package com.test.users.util;

/**
 * 
 * @author n432743
 *
 */
public class ServiceConstants {
	
	
	public static final String DXSIPROXY_ERROR_CODE = "VCU10002";
	public static final String UNEXPECTED_SERVICE_ERROR_CODE = "VCU10001";
	public static final String SVC_EMPTY_STRING = "";

				
}
