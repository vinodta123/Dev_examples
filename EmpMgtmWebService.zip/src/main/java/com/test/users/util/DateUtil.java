package com.test.users.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class DateUtil {

	public DateUtil() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date localTime = new Date();
		new DateUtil().getlocalToGMTDate(localTime);
		new DateUtil().getlocalToGMTCal();
	}

	public void getlocalToGMTDate(Date localTime) {
		// creating DateFormat for converting time from local timezone to GMT
		DateFormat converter = new SimpleDateFormat("dd/MM/yyyy:HH:mm:ss");
		// getting GMT timezone, you can get any timezone e.g. UTC
		converter.setTimeZone(TimeZone.getTimeZone("IST"));
		System.out.println("local time : " + localTime);
		System.out.println("time in IST : " + converter.format(localTime));
	} 

	
	
	 
	 public void getlocalToGMTCal() {
		 Calendar cal = Calendar.getInstance();   // GregorianCalendar
		 System.out.println("Cal local time : " + cal.getTime());
		 
		int offset= TimeZone.getTimeZone("IST").getOffset(cal.getTimeInMillis());
	      // print current time zone
	      String name=cal.getTimeZone().getDisplayName();
	      System.out.println("Current Time Zone:" + name );
	      TimeZone tz = TimeZone.getTimeZone("IST");

	      // set the time zone with the given time zone value 
	      // and print it
	      cal.setTimeZone(tz);
	      System.out.println("offset-->"+offset);

		 GregorianCalendar ist= new GregorianCalendar(TimeZone.getTimeZone("IST"));
		 ist.setTimeInMillis(cal.getTimeInMillis());
		 ist.add(Calendar.MILLISECOND,offset);
/*		 Calendar cal2 = Calendar.getInstance(TimeZone.getTimeZone("IST"));   // GregorianCalendar
		 cal2.setTimeZone(TimeZone.getTimeZone("IST"));*/
		System.out.println("Cal Time in IST : " + ist.getTime());
		}
	 
	
}
