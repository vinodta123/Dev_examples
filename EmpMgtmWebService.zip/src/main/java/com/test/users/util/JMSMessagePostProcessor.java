package com.test.users.util;

import javax.jms.JMSException;
import javax.jms.Message;

import org.springframework.jms.core.MessagePostProcessor;

/**
 * This class is used to set the correlation id
 * in the message.
 * 
 * @author Vinod Sharma
 *
 */
public class JMSMessagePostProcessor implements MessagePostProcessor {

    private String correlationID;

    public JMSMessagePostProcessor(String corID) {
        correlationID = corID;
    }

    public JMSMessagePostProcessor() {
    }

    public Message postProcessMessage(Message msg) throws JMSException {
        msg.setJMSCorrelationID(correlationID);
        return msg;
    }

}
