package com.test.users.dao;

import com.test.users.beans.UserRequest;
import com.test.users.beans.UserResponse;


/**
 * 
 * @author n432743
 *
 */
public interface UsersDao {

	/**
	 * 
	 * @return getUserList
	 */
	public UserResponse getUserList(UserRequest getUsersRequest)throws Exception;
	
	public String getXMLResponse(String inputRequest)throws Exception;
	
}
