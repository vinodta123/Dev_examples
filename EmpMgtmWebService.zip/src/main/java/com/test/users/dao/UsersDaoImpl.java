package com.test.users.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.test.users.beans.Address;
import com.test.users.beans.ObjectFactory;
import com.test.users.beans.UserDetails;
import com.test.users.beans.UserRequest;
import com.test.users.beans.UserResponse;





/**
 * 
 * @author n432743
 *
 */
public class UsersDaoImpl implements UsersDao{

	private ObjectFactory objectFactory=null;
	private static Map<String, String> keyAndResources = null;
    private static Map<String, String> keyAndDelay = null;
	
	public void setObjectFactory(ObjectFactory objectFactory) {
		this.objectFactory = objectFactory;
	}


	/**
	 * Default Constructor.
	 */
	public UsersDaoImpl()  {
		
	   
	}
	

	/**
	 * 
	 * @return  List<Users>
	 */
	public UserResponse getUserList(UserRequest getUsersRequest) throws Exception{
		UserResponse getUsersListResponse=objectFactory.createUserResponse();
			UserDetails getUsers=new UserDetails();
			UserDetails getUsers2=new UserDetails();
			Address add = new Address();
			add.setCity("Delhi");
			add.setFlatNo("345");
			add.setPin("TW3PTR");
			add.setState("Delhi");
			add.setStreet("Cleven Garden");
			
			
			getUsers.setAddress(add);
			getUsers.setFName("Vinod");
			getUsers.setLName("Sharma");
			getUsers.setId("1");
			getUsers.setPhoneNo("123456789");
			
			
			getUsers2.setAddress(add);
			getUsers2.setFName("Raj");
			getUsers2.setLName("Sharma");
			getUsers2.setId("2");
			getUsers2.setPhoneNo("987654321");
			//usersList.add
			getUsersListResponse.getUserDetails().add(getUsers);
			getUsersListResponse.getUserDetails().add(getUsers2);	
			
		return getUsersListResponse;
	}
	
	
	/**
	 * 
	 * @param inputRequest
	 * @return
	 * @throws Exception
	 */
	public String getXMLResponse(String inputRequest) throws Exception{
        String reply = null;
        String replyDelay = "0";
        boolean flag =false;
        if (keyAndResources == null || inputRequest.contains("REFRESH_STUBS")) {
            System.out.println("==============AM ABOUT TO LOAD RESOURCES=============");
            loadResources();
       }
        Set<String> keySet = keyAndResources.keySet();
        try 
        {
            for (Iterator<String> iterator = keySet.iterator(); iterator.hasNext();) 
            {	
                String stringMatcher = (String) iterator.next();
                //System.out.println("Request Node here:    "+stringMatcher);
                if(inputRequest.trim().contains(stringMatcher))
                {
                    reply = keyAndResources.get(stringMatcher);
                    replyDelay=keyAndDelay.get(stringMatcher);
                    flag=true;
                    break;
                }
            }
            if(!flag){
            	System.out.println("==============NO STUBS FOUND1 AND FLAG IS:   =============="+flag);
                reply = constructErrorMessage("STUB10001",inputRequest);
            }
            try {
                //System.out.println("ReplyDelay here:   "+replyDelay);
                Thread.sleep(Integer.parseInt(replyDelay));
                //System.out.println("After thread sleep");
            } catch (InterruptedException e) {
                System.out.println("============EXCEPTION IN THREAD SLEEP EXECUTION=============");
                e.printStackTrace();
                Thread.currentThread().interrupt(); // Restore the interrupted status
            }
        } catch (Exception e) {
            System.out.println("============THROWING EXCEPTION PROCESSLOCALSTUBS START================");
            e.printStackTrace();
            System.out.println("============THROWING EXCEPTION PROCESSLOCALSTUBS END================");
        }
        if (reply == null) {
            //System.out.println("==============NO STUBS FOUND2==============");
            reply = constructErrorMessage("STUB10002", inputRequest);
        }
        return reply;
    }

    public void loadResources() {
        try {
            keyAndResources = new HashMap<String, String>();
            keyAndDelay = new HashMap<String, String>();
            //responseFileNames=new HashMap<String, String>();
           // String rootDir = System.getProperty("resources");
            Properties properties = new Properties();
            //properties.load(new FileInputStream(new File(rootDir+"responseStubs.properties")));
            //properties.load(new FileInputStream(new File("responseStubs.properties")));
            properties.load(getClass().getClassLoader().getResourceAsStream("responseStubs.properties"));
            
            Enumeration<Object> keys = properties.keys();
            while (keys.hasMoreElements()) {
                String key = (String) keys.nextElement();
                String file = properties.getProperty(key);
                String responseMatcher[] = file.split(":");
                String matchingValue = responseMatcher[0];
                String responseFileName = file.split(":")[1];
                String responseDelay = file.split(":")[2];
                //String responseXML = getFileAsString(new File(rootDir + responseFileName));
               InputStream inpu= getClass().getClassLoader().getResourceAsStream(responseFileName);
                String responseXML = getFileAsString(inpu);
                keyAndResources.put(matchingValue, responseXML);
                keyAndDelay.put(matchingValue, responseDelay);
            }
        } catch (Exception e) {
            System.out.println("==============EXCEPTION WHILE LOADING RESOURCES==============");
            e.printStackTrace();
        }
       // System.out.println("Key values are " + keyAndResources);
       // System.out.println("keyAndDelay Delays are " + keyAndDelay);
    }

    
    /**
     * 
     * @param file
     * @return
     */
    public static String getFileAsString(InputStream fileInput) {
        StringBuffer sb = new StringBuffer();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(fileInput));
            String line;
    		while ((line = br.readLine()) != null) {
    			sb.append(line);
    		}
        } catch (IOException e) {
    		e.printStackTrace();
    	} finally {
    		if (fileInput != null) {
    			try {
    				fileInput.close();
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
    		}
    		if (br != null) {
    			try {
    				br.close();
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
    		}
    	}
        return sb.toString();
    }

/**
 * 
 * @param errorCode
 * @param errorMessage
 * @return
 */
    private static String constructErrorMessage(String errorCode,
            String errorMessage) {
        StringBuffer stuboErrorMessage = new StringBuffer(
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"
                        + "<soapenv:Header/>"
                        + "<soapenv:Body>"
                        + "<soapenv:Fault>"
                        + "<faultcode> "
                        + errorCode
                        + "</faultcode>"
                        + "<faultstring>"
                        + errorMessage
                        + "</faultstring>"
                        + "</soapenv:Fault>"
                        + "</soapenv:Body> " + "</soapenv:Envelope>");
        return stuboErrorMessage.toString();
    }	
	
    /*public static void main(String[] args) {
    	// read this file into InputStream
    	InputStream inputStream = null;
    	try {
	
    		inputStream = new FileInputStream("C:/Users/n432743/wls10.3.6/mydomain/resources/LHR_Air_ExtendedAvailability_Response.xml");

    		String rs= UsersDaoImpl.getFileAsString(inputStream);
    
    	} catch (IOException e) {
    		e.printStackTrace();
    	}

    }*/
	
}
