package com.test.users.handler;

import com.test.users.beans.ObjectFactory;
import com.test.users.beans.UserRequest;
import com.test.users.beans.UserResponse;
import com.test.users.dao.UsersDao;



/**
 * This is a helper class for all the end point in managing the response. This
 * class invokes the DXSI data service and gets the respective response messages
 * 
 * Before invoking DXSI, HTTP headers has been set in the pay load.values are used to open the connection with Amadeus in ALSB.
 * 
 * @author n427244
 */
public class GetUsersListResponseHandler {


	private ObjectFactory objectFactory=null;
	
	public void setObjectFactory(ObjectFactory objectFactory) {
		this.objectFactory = objectFactory;
	}
	
	private UsersDao usersDao;
	
	
	public GetUsersListResponseHandler( UsersDao usersDao){
		this.usersDao=usersDao;
	}
		
	


	/**
	 * 
	 * @param request
	 * @return
	 */
	public UserResponse getUsersListResponse(
	           Object request) throws Exception {
		//initialises the JAXBElement with the instance of GetScheduleAvailabilityResponse.
		UserResponse jaxbResponseElement=(UserResponse)objectFactory.createUserResponse();
       	// casts the object to GetScheduleAvailabilityRequest
		UserRequest getUsersRequest = (UserRequest) request;
		jaxbResponseElement=usersDao.getUserList(getUsersRequest);
		return jaxbResponseElement;
	}
	
	
	/**
	 * 
	 * @param request
	 * @return
	 */
	public String getXMLResponse(String str) throws Exception {
		return usersDao.getXMLResponse(str);
	
	}	
	

}
