package com.test.users.exception;



import com.test.users.beans.ObjectFactory;
import com.test.users.beans.UserResponse;
import com.test.users.util.ServiceConstants;

/**
 * Builds the error information in the customised format and sets in the
 * response.
 * 
 * @author n427244
 * 
 */
public class GetUserListErrorResponse {
	/**
	 * This method will be called from the catch block of invoke internal method
	 * of every end point class
	 * 
	 * @param exceptionMessage
	 *            Exception
	 * @param operationName
	 *            String
	 * @return Object GetUserListErrorResponse
	 * 
	 */
	public Object buildErrorResponse(Exception exceptionMessage,
			String operationName) {
		if (null != operationName) {
			return createGetUserListErrorResponse(exceptionMessage);
		}
		return null;
	}

	/**
	 * This method is used to create the GetScheduledAvailability error response
	 * 
	 * @param exceptionMessage
	 *            Exception
	 * 
	 * @return GetScheduledAvailabilityResponse getScheduledAvailabilityResponse
	 * 
	 */
	private UserResponse createGetUserListErrorResponse(
			Exception exceptionMessage) {
		ObjectFactory objFactory = new ObjectFactory();
		UserResponse getScheduledAvailabilityResponse = objFactory.createUserResponse();
		return getScheduledAvailabilityResponse;
	}

}
