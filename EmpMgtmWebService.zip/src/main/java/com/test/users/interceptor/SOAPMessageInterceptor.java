package com.test.users.interceptor;

import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.interceptor.EndpointInterceptorAdapter;




public class SOAPMessageInterceptor extends EndpointInterceptorAdapter {

  
    /**
     * Message interception so we can get access to the header details.
     */
    @Override
    public boolean handleRequest(MessageContext messageContext, Object endpoint)
            throws Exception {
     

        // First we need to get hold of the name of the service. Therefore, we
        // need to get hold of the request element in the incoming request and
        // then strip off the trailing 'Request' part (if present) - we should
        // then end up with the service name.
        return super.handleRequest(messageContext, endpoint);
    }

 
    /**
     * We need to clear the stack on the NDC
     */
    @Override
    public boolean handleResponse(MessageContext messageContext, Object endpoint)
            throws Exception {
    	
        return super.handleResponse(messageContext, endpoint);
    }
}
