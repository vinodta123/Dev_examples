package com.test.jms.mdp;


import java.io.IOException;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
//Import the classes to use JNDI.


public class JMSClientServlet extends HttpServlet  {
	private JmsTemplate jmsTemplate;
	
	public void setJmsTemplate(JmsTemplate setjmsTemplate) {
				this.jmsTemplate = setjmsTemplate;
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {
        	
        	System.out.println("==============Entry in do Post method ==============");
        	
        	final  String  messgeSend = "LHR";
            
        	System.out.println("Sending Request Message: " +messgeSend);
            
        	jmsTemplate.send(new MessageCreator() {      
            	public Message createMessage(Session session) throws JMSException {  
            		Message message = session.createTextMessage(messgeSend);    
            		return message;    }  
            	}); 
      
        	Message messages = jmsTemplate.receive(); 
            Object responseMessage = ((ObjectMessage) messages).getObject(); 
        
            
            System.out.println("Read Response Message:--> " + responseMessage.toString());
            
           
            System.out.println("finished-------");

        } catch (Exception jmse) {
            System.out.println("Exception occurred : " + jmse.toString());
            jmse.printStackTrace();
        }
    }
	

}
