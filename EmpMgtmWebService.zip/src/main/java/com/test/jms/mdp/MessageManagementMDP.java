package com.test.jms.mdp;



import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.SessionAwareMessageListener;

import com.test.users.handler.GetUsersListResponseHandler;
import com.test.users.util.JMSMessagePostProcessor;



/**
 * This class will listen then parse 
 * the request message and call the respective DAO class to get the
 * response message and post back the response message to the response queue. 
 * @author Vinod Sharma
 * 
 */

public class MessageManagementMDP implements SessionAwareMessageListener{

	private JmsTemplate jmsTemplate;
	private GetUsersListResponseHandler getUsersListResponseHandler;
	
	/**
	 * Constructor setting up the jmsTemplate
	 * @param jmsTemplate
	 * @throws Exception
	 */

	public MessageManagementMDP(JmsTemplate jmsTemplate,GetUsersListResponseHandler getUsersListResponseHandler)
	throws Exception {
		this.jmsTemplate = jmsTemplate;
		this.getUsersListResponseHandler = getUsersListResponseHandler;
		
	}

	/**
	 * This method invokes to read the request message text and pass it to the
	 * DAO class to get the response message and post the response message to
	 * the response queue.
	 * 
	 * @param message
	 *            Message
	 * @param session
	 *            Session
	 * 
	 */


	public void onMessage(Message message, Session session) throws JMSException {

		Destination replyToQueue = null;
		String correlationID = null;
		Object responseMessage; 
		JMSMessagePostProcessor messagePostProcessor=null;
		String res=null;
		try {
			TextMessage textMessage = (TextMessage) message;
			correlationID = textMessage.getJMSCorrelationID();
			replyToQueue = textMessage.getJMSReplyTo();
			String requestMessage = textMessage.getText();
			
			//System.out.println("Reqeust is picked by sever in onMessage()-->"+requestMessage);
			
			messagePostProcessor = new JMSMessagePostProcessor(correlationID);
		
			res =getUsersListResponseHandler.getXMLResponse(requestMessage);
			responseMessage=res;
	
			jmsTemplate.convertAndSend(replyToQueue, responseMessage,
					messagePostProcessor);
			System.out.println("Response is sent back to Queue-->");
			//System.out.println("Response is sent back to Queue-->"+res);
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

	




}
