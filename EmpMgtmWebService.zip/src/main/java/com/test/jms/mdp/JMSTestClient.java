package com.test.jms.mdp;

import java.util.Hashtable;

import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;


public class JMSTestClient {
	
	
	
	public static void main(String[] args)

			  {
		
		try{
			    int 					limitMessage       	=10;
			    String  				messageID           = null;
			    String  				outString           = null;
			    String  				ConnName            = "EMP_MGMT_CONNECTION";
			    String  			   	QueueName           = "EMP_MGMT_QUEUE";
			    QueueSession           	session    			= null;
			    QueueConnection        	connection		 	= null;
			    Context                	contexts       		= null;
			    QueueConnectionFactory 	connectionFactory   = null;
			    Queue                  	inQueue    			= null;
			    boolean 			   	transacted          = false;
			    
			    /* This is for xml file.
			     * FileReader fr = new FileReader(new File("c:/myMsgm2.xml"));
			    StringWriter sw = new StringWriter();
			    IOUtil.copyCompletely(fr, sw);
			    outString = sw.toString();
			    */
			    outString = "LHR";
			    System.out.println("input : "+outString);
			    Hashtable ht = new Hashtable();
				ht.put("weblogic.jndi.replicateBindings", "false");
				ht.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
				//ht.put(Context.PROVIDER_URL, "t3://10.38.105.113:7001");
				ht.put(Context.PROVIDER_URL, "t3://localhost:7001");
				
				contexts = new InitialContext(ht);

				connectionFactory = (QueueConnectionFactory)contexts.lookup(ConnName);
			    inQueue = (Queue)contexts.lookup(QueueName);
			    
			    connection = connectionFactory.createQueueConnection();
			    connection.start();
			    
			    session = connection.createQueueSession( transacted, Session.CLIENT_ACKNOWLEDGE);
			    QueueReceiver queueReceiver =null;
			    QueueSender queueSender = null;
			   
			    long start_time = System.currentTimeMillis();


			    for (int i = 0; i <limitMessage; i++) {
			    	
			            queueSender = session.createSender(inQueue);
					    TextMessage outMessage = session.createTextMessage(outString);
					    Queue tempQueue = session.createTemporaryQueue();
					    outMessage.setJMSReplyTo(tempQueue);
					    queueSender.send(outMessage);
					    messageID = outMessage.getJMSMessageID();
					    
					    //System.out.println("Message ID : "+messageID);
					   // String selector = "JMSCorrelationID = '"+messageID+"'";
					    
					    queueReceiver = session. createReceiver(tempQueue);
					    Message inMessage = queueReceiver.receive();
					   //System.out.println("inMessage type : "+inMessage.getJMSType());
					  // System.out.println("inMessage : "+inMessage);
					   
					    
					    if ( inMessage instanceof TextMessage ){
					    	String replyString = ((TextMessage) inMessage).getText();
					    	System.out.println("Read Response message--> : "+i+"--"+ replyString);
					    }
					    
				}
			    //sw.close();
			    queueReceiver.close();
			    queueSender.close();
			    session.close();
			    session = null;
			    connection.close();
			    connection = null;
			    long end_time = System.currentTimeMillis();

			    long difference = end_time-start_time;
			    
			    System.out.println("Total time is taken by JMS Process for --"+"limitMessage-->"+ difference);
			    
			    
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
