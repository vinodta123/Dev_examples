/**
 * 
 */

/**
 * @author sharmv4
 *
 */
public class StuckThreadExample {

	/**
	 * 
	 */
	public StuckThreadExample() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			 
		try{
			System.out.println("start thread Time-->"+System.nanoTime());
			  for(int i=0;i<100;i++){
				 Thread.sleep(650000);
				System.out.println("Number is -->"+i+"<--end thread Time i-->"+System.nanoTime());
			  }
			 } catch (Exception e){System.out.println("error-->"+e);}
		
	}

}
