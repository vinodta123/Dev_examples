/**
 * 
 */
package com.selenium.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @author sharmv4
 *
 */
public class FirstSeleniumTest {


	
    private void shouldAskGoogleForWebDriver() {
        WebDriver driver = new FirefoxDriver();
        driver.get("https://www.google.co.uk");
        WebElement element = driver.findElement(By.name("q"));
        element.sendKeys("Cheese!");
        element.submit();
        assertEquals("Google", driver.getTitle());
        driver.close();
    }
	
	
    private void shouldAskLocalVirginAtlantic() {
        WebDriver driver = new FirefoxDriver();
        driver.get("http://vaadev1.vaa.vtg.local/gb/en.html");
        
        //driver.get("http://10.215.73.165/gb/en.html");
        
        //WebElement element = driver.findElement(By.name("q"));
        //element.sendKeys("Cheese!");
        //element.submit();
         assertEquals("virgin atlantic", driver.getTitle());
        driver.close();
    }
	
	@Test
	public void mainTest() {
		shouldAskLocalVirginAtlantic();
	}
}
