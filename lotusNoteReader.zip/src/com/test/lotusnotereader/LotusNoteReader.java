package com.test.lotusnotereader;
import lotus.domino.*;
public class LotusNoteReader  {
	
	public static void main(String[] args) {
	try {
		//Session session = NotesFactory.createSession("LONAPP02", "Pawan Tiwari", "migrate");
		Session session = NotesFactory.createSession("LONTMP01:1352", "asharmv4", "Chat@123");
		String p = session.getPlatform();
		System.out.println("Platform = " + p);
		
		Database db = session.getDatabase(null, "IT/ITBIBLE.nsf");
		System.out.println(session.getUserName());
		System.out.println(db.getSize());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		}
}