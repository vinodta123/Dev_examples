package com.beingjavaguys.services;

import java.util.List;

import com.beingjavaguys.models.User;
/**
 * 
 *
 */
public interface DataService {
	public List<User> getUserList();
}
