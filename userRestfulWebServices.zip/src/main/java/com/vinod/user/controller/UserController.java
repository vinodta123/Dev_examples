package com.vinod.user.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vinod.user.bean.Users;
import com.vinod.user.service.UserService;

@RestController
public class UserController {

	
@Autowired
UserService userService;  

	

@RequestMapping(value = "/user/{id}", method = RequestMethod.GET,headers="Accept=application/json")
public Users findUser(@PathVariable long id)throws Exception  {  
 return userService.findUser(id);  
 }  



@RequestMapping(value = "/userList", method = RequestMethod.GET,headers="Accept=application/json")
public Map<Integer, Users> getUserList()throws Exception  {  
 return userService.getUserList();  
 }  

}
