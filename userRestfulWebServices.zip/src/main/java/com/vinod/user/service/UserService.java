package com.vinod.user.service;

import java.util.Map;

import com.vinod.user.bean.Users;

public interface UserService {

	public Users findUser(long userId);
	public Map<Integer, Users> getUserList();
	
}
