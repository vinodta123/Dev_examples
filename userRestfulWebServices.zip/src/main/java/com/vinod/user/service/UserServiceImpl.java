package com.vinod.user.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.vinod.user.bean.Country;
import com.vinod.user.bean.Users;
import org.springframework.stereotype.Service;

@Service("UserService")
public class UserServiceImpl implements UserService{

	 Map<Integer, Users> userList = new HashMap<Integer, Users>(); 
	
	public UserServiceImpl() {
		
		userList.put(1, new Users(101, "vinod","Sharma","vinod@yahoo.com","76543212345"));  
		userList.put(2, new Users(102, "vipin","fggf","vipin@yahoo.com","76543212345"));  
		userList.put(3, new Users(103, "Raj","gdfgdg","vinod@yahoo.com","78678686868"));  
		userList.put(4, new Users(104, "kamla","dgdgdg","Raj@yahoo.com","7475376345347"));  
		userList.put(5, new Users(105, "Deepa","jhfghj","vinod@yahoo.com","77637747"));  
		userList.put(6, new Users(106, "Carlos","tyry","Deepa@yahoo.com","632626633"));  
		userList.put(7, new Users(107, "Mithel","weffsg","vinod@yahoo.com","436463663623"));  
		userList.put(8, new Users(108, "Deepa","ngffh","Mithel@yahoo.com","97888768"));  
		userList.put(9, new Users(109, "Deep","Sharma","Deep@yahoo.com","76543212345"));  
		userList.put(10, new Users(1010, "vinod","Sharma","vinod@yahoo.com","76543212345"));  
			
	}

	/**
	 * 
	 * @param employeeId
	 * @return
	 */
	public Users findUser(long userId) {  
		Users userobj=null;
	
		for (int i = 0; i < userList.size(); i++) {
			if(userId==userList.get(i).getUserId()){
				userobj=(Users)userList.get(i);
				break;
			}
		}
		 return userobj;  

	}  

	
	
	/**
	 * 
	 * @return characters
	 */
	public Map<Integer, Users> getUserList(){	
		return userList;
	}
}
