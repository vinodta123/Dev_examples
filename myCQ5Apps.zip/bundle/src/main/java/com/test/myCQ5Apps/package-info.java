@Version("1.0.0")
package com.test.myCQ5Apps;

import aQute.bnd.annotation.Version;