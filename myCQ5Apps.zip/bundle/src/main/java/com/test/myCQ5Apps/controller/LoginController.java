package com.test.myCQ5Apps.controller;

import java.io.IOException;
import java.rmi.ServerException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
//import org.apache.sling.commons.osgi.OsgiUtil;
import org.apache.sling.jcr.api.SlingRepository;

import com.test.myCQ5Apps.service.LoginUser;
import com.test.myCQ5Apps.service.impl.LoginUserImpl;

@SlingServlet(paths = { "/bin/LoginController"}, methods = {"POST"}, metatype = true)
public class LoginController extends org.apache.sling.api.servlets.SlingAllMethodsServlet {

	

	//@Reference
	//private SlingRepository repository;

	//public void bindRepository(SlingRepository repository) {
	//	this.repository = repository;	
	//}
	
	//@Reference
	//private ServletResolver 	;

	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServerException, IOException {
		String redirect = null;
		LoginUser loginUser=null;
		//Servlet servlet =null;
		ResourceResolver ress=null;
		String msg=null;
		try {
			// Get the submitted form data that is sent from the
			String loginid = request.getParameter("username");
			String password = request.getParameter("password");
			loginUser =new LoginUserImpl();
		
				if(loginUser.checkLogin(loginid,password)){
					redirect = "/content/login/loginSucessful.html?username="+loginid;
				}else{
					msg= "Loginid or Password invalid";
					redirect = "/content/login.html?invalidLogin="+msg;
				}
			//redirect = "login.html";
			//servlet= servletResolver.resolveServlet(request.getResource(), redirect);
			//servlet.service(request, response);
			//RequestDispatcher dis=request.getRequestDispatcher(arg0)getServletContext().getRequestDispatcher(redirect);
		    //dis.forward(request, response);
		   //	ComponentRequestDispatcher cc=request.getRequestDispatcher("/abs/path/to/content");
			String paths=request.getResource().getPath();
			//ress =request.getResourceResolver();
			//Resource resource = ress.getResource(redirect);
			//request.getRequestDispatcher(redirect).forward(request, response);
			//RequestDispatcherOptions opts = new RequestDispatcherOptions();
			//opts.put("invalidLogin", "vinod");
		   // RequestDispatcher dispatcher =request.getRequestDispatcher(redirect, opts);
		   // if(dispatcher != null) {
		    //	 dispatcher.forward(request, response);
		   //}
			
			response.sendRedirect(redirect);			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServerException, IOException {
		String redirect = null;
		try {
					redirect = "/content/login.html";

			response.sendRedirect(redirect);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
