package com.test.myCQ5Apps.service;

public interface LoginUser {
	
	public boolean checkLogin(String userName,String password);

}
