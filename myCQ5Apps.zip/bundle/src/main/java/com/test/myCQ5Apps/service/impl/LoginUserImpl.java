package com.test.myCQ5Apps.service.impl;

import javax.jcr.Repository;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import com.test.myCQ5Apps.service.LoginUser;

/**
 * One implementation of the {@link LoginUser}. Note that
 * the repository is injected, not retrieved.
 */
@Service
@Component(metatype = false)
public class LoginUserImpl implements LoginUser {

	@Reference
	private SlingRepository repository;

	public String getRepositoryName() {
		return repository.getDescriptor(Repository.REP_NAME_DESC);
	}

	
	public boolean checkLogin(String userName, String password) {
		boolean loginStatus = false;
		if (userName != null && password != null) {
			if(userName.equalsIgnoreCase("admin") && password.equalsIgnoreCase("admin") ) {
				loginStatus = true;
			}		
		}
		return loginStatus;
	}
}
