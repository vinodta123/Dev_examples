package com.javahonk;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;


public class CoherenceCheck {
	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		 
	      String key0 = "coherenceKey0";
	      String value0 = "The value of coherenceKey0 is Vinod Sharma";
	      String key1 = "coherenceKey1";
	      String value1 = "The value of coherenceKey1 is Tanvi Sharma and other dependents";
	      
	      
	      CacheFactory.ensureCluster();
	      NamedCache cache = CacheFactory.getCache("coherence-data");
	 
	      if(null==(String)cache.get(key0)){
	    	  cache.put(key0, value0);
	    	  System.out.println("added key0 in coherence cache");
	      }else{
	    	  System.out.println("No values added in coherence cache");
	    		 	  
	      }
	      
	      if(null==(String)cache.get(key1)){
	    	  cache.put(key1, value1);
	    	  System.out.println("added  key1 in coherence cache");
	      }else{
	    	  System.out.println("No values added in coherence cache");
	    		 	  
	      }
	      System.out.println("key0--->"+(String)cache.get(key0));
	      
	      System.out.println("key1--->"+(String)cache.get(key1));
	 
	      CacheFactory.shutdown();
	   }
}
